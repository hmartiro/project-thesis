///////////////////////////////////////////////////////////
// MessageDialog.cpp
//
// Project:				CommonLib
// Author:				MMAGCHHE
// Date of Creation:	16-Dec-2010 09:40:00
//
// See header file for description.
//
// Copyright � 2010, maxon motor ag.
// All rights reserved.
///////////////////////////////////////////////////////////
#include <Ui/MmcMessageDialog.h>

//***************
//MmcMessageDialog implementation
//***************

int MmcMessageDialog(EMessageType p_messageType, CStdString p_message, CStdString p_reason, CStdString p_advice, CStdString p_question, CStdString p_title)
{
}
