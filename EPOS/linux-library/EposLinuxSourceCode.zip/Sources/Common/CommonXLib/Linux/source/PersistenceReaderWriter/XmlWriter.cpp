#include <PersistenceReaderWriter/XmlReader.h>
#include <PersistenceReaderWriter/XmlWriter.h>

CXmlWriter::CXmlWriter(void):
	m_pXmlParser(0),
	m_oExternalXmlParser(FALSE)
{
	//m_pOutputFile = 0;

	CreateXmlParser();
}

CXmlWriter::~CXmlWriter(void)
{
	DeleteXmlParser();
}

BOOL CXmlWriter::CreateXmlParser()
{
	BOOL oResult = FALSE;

	DeleteXmlParser();
	if(!m_pXmlParser)
	{
		m_pXmlParser = new XML_PARSER();
		m_oExternalXmlParser = FALSE;
		oResult = TRUE;
	}

	return oResult;
}

BOOL CXmlWriter::DeleteXmlParser()
{
	BOOL oResult = FALSE;

	if(m_pXmlParser)
	{
		if(!m_oExternalXmlParser)
		{
			delete m_pXmlParser;
		}
		m_pXmlParser = NULL;
		oResult = TRUE;
	}

	return oResult;
}

BOOL CXmlWriter::WriteStartElement(CStdString p_Name)
{
	BOOL oResult = TRUE;

	if(m_pXmlParser)
	{
		//Start of Element
		if(oResult && !m_pXmlParser->Add_LastChildNode(p_Name)) oResult = FALSE;
	}

	return oResult;
}

BOOL CXmlWriter::WriteString(CStdString p_String)
{
	BOOL oResult = TRUE;
	
	if(m_pXmlParser)
	{
		//Element Value
		if(oResult && !m_pXmlParser->Set_TextValue(p_String)) oResult = FALSE;
	}
	
	return oResult;
}

BOOL CXmlWriter::WriteFullEndElement()
{
	BOOL oResult = TRUE;

	if(m_pXmlParser)
	{
		//End of Element
		if(!m_pXmlParser->Is_Root())
		{
			//Add Empty Text
			if(m_pXmlParser->Get_Child_Count() == 0)
			{
				if(oResult && !m_pXmlParser->Add_LastChildText(_T(""))) oResult = FALSE;
				if(oResult && !m_pXmlParser->Go_to_Parent()) oResult = FALSE;
			}
			
			//Go to Parent
			if(oResult && !m_pXmlParser->Go_to_Parent()) oResult = FALSE;
		}
	}

	return oResult;
}
	
BOOL CXmlWriter::WriteElement(CStdString p_Name, CStdString p_String)
{
	BOOL oResult = TRUE;

	if(oResult && !WriteStartElement(p_Name)) oResult = FALSE;
	if(oResult && !WriteString(p_String)) oResult = FALSE;
	if(oResult && !WriteFullEndElement()) oResult = FALSE;

	return oResult;
}
