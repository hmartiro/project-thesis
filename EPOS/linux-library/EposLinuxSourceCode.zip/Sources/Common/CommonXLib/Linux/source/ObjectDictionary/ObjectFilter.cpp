// ObjectFilter.cpp: Implementierung der Klasse CObjectFilter.
//
//////////////////////////////////////////////////////////////////////
#include <Classes/MmcDataConversion.h>
#include <PersistenceReaderWriter/XmlWriter.h>
#include <PersistenceReaderWriter/XmlReader.h>
#include <ObjectDictionary/ObjectFilter.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

CObjectFilter::CObjectFilter()
{
    m_oInternalObjectsVisible = FALSE;
	m_oServiceModeActive = FALSE;
    Reset();
}

CObjectFilter::CObjectFilter(CObjectFilter& objectFilter)
{
    *this = objectFilter;
}

CObjectFilter::~CObjectFilter()
{
}

void CObjectFilter::Reset()
{
    m_oEmpty = TRUE;
    m_VisibleStructuredObjectIndex.clear();
    m_VisibleObjectIndex.clear();
    m_VisibleObjectSubIndex.clear();
}

CObjectFilter& CObjectFilter::operator=(CObjectFilter &other)
{
    if(this != &other)
    {
        Reset();
        m_oEmpty = other.m_oEmpty;
        m_Name = other.m_Name;
        m_oServiceModeActive = other.m_oServiceModeActive;
        m_Description = other.m_Description;
        m_VisibleStructuredObjectIndex.insert(m_VisibleStructuredObjectIndex.begin(),other.m_VisibleStructuredObjectIndex.begin(),other.m_VisibleStructuredObjectIndex.end());
        m_VisibleObjectIndex.insert(m_VisibleObjectIndex.begin(),other.m_VisibleObjectIndex.begin(), other.m_VisibleObjectIndex.end());
		m_VisibleObjectSubIndex.insert(m_VisibleObjectSubIndex.begin(),other.m_VisibleObjectSubIndex.begin(),other.m_VisibleObjectSubIndex.end());
    }
    return *this;
}

void CObjectFilter::AddVisibleStructuredObject(WORD usIndex)
{
    m_oEmpty = FALSE;
    m_VisibleStructuredObjectIndex.push_back(usIndex);
}

void CObjectFilter::AddVisibleObject(WORD usIndex, BYTE ubSubIndex)
{
    m_oEmpty = FALSE;
    m_VisibleObjectIndex.push_back(usIndex);
    m_VisibleObjectSubIndex.push_back(ubSubIndex);
}

void CObjectFilter::AddVisibleStructuredObject(CStdString strIndex)
{
    CMmcDataConversion dataConversion;
    WORD wIndex;

    if(dataConversion.HexWordStr2Word(strIndex, &wIndex, FALSE))
    {
        AddVisibleStructuredObject(wIndex);
    }
}

void CObjectFilter::AddVisibleObject(CStdString strIndex, CStdString strSubIndex)
{
    CMmcDataConversion dataConversion;
    WORD wIndex;
    BYTE bSubIndex;

    if(dataConversion.HexWordStr2Word(strIndex, &wIndex, FALSE))
    {
        if(dataConversion.HexByteStr2Byte(strSubIndex, &bSubIndex, FALSE))
        {
            AddVisibleObject(wIndex, bSubIndex);
        }
    }
}

CStdString CObjectFilter::GetName()
{
    return m_Name;
}

void CObjectFilter::SetName(CStdString name)
{
    m_oEmpty = FALSE;
    m_Name = name;
}

void CObjectFilter::SetDescription(CStdString description)
{
    m_Description = description;
}

BOOL CObjectFilter::IsEmpty()
{
    return m_oEmpty;
}

BOOL CObjectFilter::IsVisible(CStdString objectName, WORD usIndex)
{
    if(IsObjectNameVisible(objectName))
    {
        if(!m_oEmpty)
        {
            for(size_t i=0;i<m_VisibleStructuredObjectIndex.size();i++)
            {
                if(m_VisibleStructuredObjectIndex[i] == usIndex) return TRUE;
            }
            return FALSE;
        }
        else
        {
            return TRUE;
        }
    }

    return FALSE;
}

BOOL CObjectFilter::IsVisibleObjectExisting(WORD usIndex, BYTE ubSubIndex)
{
    for(size_t i=0;i<m_VisibleObjectIndex.size();i++)
    {
        if((m_VisibleObjectIndex[i] == usIndex) && (m_VisibleObjectSubIndex[i] == ubSubIndex)) return TRUE;
    }

    return FALSE;
}

BOOL CObjectFilter::IsVisible(CStdString objectName, WORD usIndex, BYTE ubSubIndex)
{
    if(IsObjectNameVisible(objectName))
    {
        if(!m_oEmpty)
        {
            for(size_t i=0;i<m_VisibleObjectIndex.size();i++)
            {
                if((m_VisibleObjectIndex[i] == usIndex) && (m_VisibleObjectSubIndex[i] == ubSubIndex)) return TRUE;
            }
            return FALSE;
        }
        else
        {
            return TRUE;
        }
    }

    return FALSE;
}

BOOL CObjectFilter::DeleteVisibleObject(WORD usIndex, BYTE ubSubIndex)
{
	for(std::vector<unsigned short>::iterator it=m_VisibleObjectIndex.begin(); it!=m_VisibleObjectIndex.end(); it++)
	{
		if((*it) == usIndex)
		{
			for(CStdByteArray::iterator its=m_VisibleObjectSubIndex.begin(); its!=m_VisibleObjectSubIndex.end(); its++)
			{
				if((*its) == ubSubIndex)
				{
					m_VisibleObjectIndex.erase(it);
					m_VisibleObjectSubIndex.erase(its);
					return TRUE;
				}
			}
			break;
		}
	}

    return FALSE;
}

BOOL CObjectFilter::DeleteAllVisibleObjects()
{
    m_VisibleStructuredObjectIndex.clear();
    m_VisibleObjectIndex.clear();
    m_VisibleObjectSubIndex.clear();

    return TRUE;
}

BOOL CObjectFilter::SetInternalObjectFilter(BOOL p_oActive)
{
	BOOL oResult = TRUE;

	m_oInternalObjectsVisible = !p_oActive;

	return oResult;
}

void CObjectFilter::SetServiceModeActive(BOOL active)
{
    m_oServiceModeActive = active;
}

BOOL CObjectFilter::IsObjectNameVisible(CStdString objectName)
{
    CStdString invisibleSubString = "Internal";

    if(!m_oServiceModeActive && !m_oInternalObjectsVisible)
    {
        if(objectName.GetLength() >= invisibleSubString.GetLength())
        {
            if(invisibleSubString.CompareNoCase(objectName.Left(invisibleSubString.GetLength())) == 0)
            {
                return FALSE;
            }
        }
    }

    return TRUE;
}

BOOL CObjectFilter::LoadObjectFilterSchema(CStdString* pXmlData)
{
    if(pXmlData)
    {
        Reset();
        if(Load_XML_From_Buffer(pXmlData))
        {
            return TRUE;
        }
    }

    return FALSE;
}

void CObjectFilter::Parse_XML_Document()
{
    BOOL moreVisibleObjects;
    CStdString strIndex, strSubIndex;

    //ObjectEntry
    if(Is_Tag(_T("<ObjectFilter>")))
    {
        //Name
        if(Is_Having_Attribute(_T("Name")))
        {
            m_Name = Get_Attribute_Value();
			m_oEmpty = FALSE;
        }

        //Description
        if(Is_Having_Attribute(_T("Description")))
        {
            m_Description = Get_Attribute_Value();
        }

        //VisibleStructuredObjects
        if(Go_to_Child(_T("VisibleStructuredObject")))
        {
            moreVisibleObjects = TRUE;
            while(moreVisibleObjects)
            {
                //Index
                if(Is_Having_Attribute(_T("Index")))
                    AddVisibleStructuredObject(Get_Attribute_Value());

                if(!Go_Forward(_T("VisibleStructuredObject")))
                {
                    moreVisibleObjects = FALSE;
                }
            }
            Go_to_Parent();
        }

        //VisibleObjects
        if(Go_to_Child(_T("VisibleObject")))
        {
            moreVisibleObjects = TRUE;
            while(moreVisibleObjects)
            {
                //Index
                if(Is_Having_Attribute(_T("Index")))
                {
                    strIndex = Get_Attribute_Value();

                    //SubIndex
                    if(Is_Having_Attribute(_T("SubIndex")))
                    {
                        strSubIndex = Get_Attribute_Value();
                        AddVisibleObject(strIndex, strSubIndex);
                    }
                }

                if(!Go_Forward(_T("VisibleObject")))
                {
                    moreVisibleObjects = FALSE;
                }
            }
            Go_to_Parent();
        }
    }
}

BOOL CObjectFilter::StoreObjectFilterSchema(CStdString* pXmlData)
{
    XML_PARSER xmlParser;

    if(pXmlData)
    {
        xmlParser.Reset_XML_Document();

		//Root
		xmlParser.Add_FirstChildNode(_T("ObjectFilter"));
		xmlParser.IncTabLevel();

		//Attributes
		xmlParser.Set_Attribute(_T("Name"), m_Name);
		xmlParser.Set_Attribute(_T("Description"), m_Description);

		//VisibleStructuredObjects
		for(size_t i = 0; i < m_VisibleStructuredObjectIndex.size(); i++)
		{
			xmlParser.AddNewLineTab();
			xmlParser.Add_FirstChildNode(_T("VisibleStructuredObject"));
			xmlParser.Set_Attribute(_T("Index"), GetIndexStr(m_VisibleStructuredObjectIndex[i]));
			xmlParser.Go_to_Parent();
		}

		//VisibleObjects
		for(size_t i = 0;( i < m_VisibleObjectIndex.size()) && (i < m_VisibleObjectSubIndex.size()); i++)
		{
			xmlParser.AddNewLineTab();
			xmlParser.Add_FirstChildNode(_T("VisibleObject"));
			xmlParser.Set_Attribute(_T("Index"), GetIndexStr(m_VisibleObjectIndex[i]));
			xmlParser.Set_Attribute(_T("SubIndex"), GetSubIndexStr(m_VisibleObjectSubIndex[i]));
			xmlParser.Go_to_Parent();
		}

		//Root End
		xmlParser.DecTabLevel();
		xmlParser.AddNewLineTab();

//        xmlParser.Save_XML_Document("C:\\ObjectFilter.xml");
		return xmlParser.Get_XML_Document(pXmlData);
    }

    return FALSE;
}

CStdString CObjectFilter::GetIndexStr(WORD wIndex)
{
    CStdString strResult;

    strResult.Format("0x%.4X", wIndex);
    return strResult;
}

CStdString CObjectFilter::GetSubIndexStr(BYTE bSubIndex)
{
    CStdString strResult;

    strResult.Format("0x%.2X", bSubIndex);
    return strResult;
}

BOOL CObjectFilter::ReadFrom(CXmlReader* p_pXmlReader, int lCount)
{
    BOOL oResult = FALSE;

    if(p_pXmlReader)
    {
        Reset();

        //Start Element
        if(p_pXmlReader->ReadStartElement(_T("ObjectFilter"), lCount))
        {
            oResult = p_pXmlReader->ReadElement(_T("Name"), 0, m_Name);
            if(oResult && !p_pXmlReader->ReadElement(_T("Description"), 0, m_Description)) oResult = FALSE;

            //INA 2008.11.06: Until further notice deactivated
            //if(oResult && !ReadStructuredObjectFilterSchemaFrom(p_pXmlReader)) oResult = FALSE;
            if(oResult && !ReadVisibleObjectFilterSchemaFrom(p_pXmlReader)) oResult = FALSE;

            //End Element
            p_pXmlReader->ReadEndElement();
        }
    }

    return oResult;
}

BOOL CObjectFilter::WriteTo(CXmlWriter* p_pXmlWriter)
{
    BOOL oResult = FALSE;
    CStdString filterName;

    if(p_pXmlWriter)
    {
        oResult = TRUE;

        //Start Element "ObjectFilter"
        if(p_pXmlWriter->WriteStartElement("ObjectFilter"))
        {
            if(oResult && !p_pXmlWriter->WriteElement("Name", m_Name)) oResult = FALSE;
            if(oResult && !p_pXmlWriter->WriteElement("Description", m_Description)) oResult = FALSE;

            //INA 2008.11.06: Until further notice deactivated
            //if(oResult && !WriteStructuredObjectFilterSchemaTo(p_pXmlWriter)) oResult = FALSE;
            if(oResult && !WriteVisibleObjectFilterSchemaTo(p_pXmlWriter)) oResult = FALSE;

            //End Element "ObjectFilter"
            p_pXmlWriter->WriteFullEndElement();
        }
    }

    return oResult;
}

BOOL CObjectFilter::WriteStructuredObjectFilterSchemaTo(CXmlWriter* p_pXmlWriter)
{
    BOOL oResult = FALSE;
    CMmcDataConversion dataConversion;
    CStdString strIndex = "";

    if(p_pXmlWriter)
    {
        oResult = TRUE;

        for(size_t i = 0; i < m_VisibleStructuredObjectIndex.size(); i++)
        {
            //Start Element "Structured object"
            if(oResult && !p_pXmlWriter->WriteStartElement(_T("StructuredObject"))) oResult = FALSE;

            dataConversion.Word2HexWordStr(m_VisibleStructuredObjectIndex[i], &strIndex);
            if(oResult && !p_pXmlWriter->WriteElement("Index", strIndex)) oResult = FALSE;

            //End Element "Structured object"
            if(oResult && !p_pXmlWriter->WriteFullEndElement()) oResult = FALSE;
        }
    }

    return oResult;
}

BOOL CObjectFilter::ReadStructuredObjectFilterSchemaFrom(CXmlReader* p_pXmlReader)
{
    BOOL oAllObjectFiltersRead = FALSE;
    BOOL oResult = FALSE;
    CStdString strIndex = "";
    int lCount = 0;

    if(p_pXmlReader)
    {
        oResult = TRUE;

        while(!oAllObjectFiltersRead)
        {
            if(p_pXmlReader->ReadStartElement(_T("StructuredObject"), lCount))
            {
                if(oResult && !p_pXmlReader->ReadElement(_T("Index"), 0, strIndex)) oResult = FALSE;
                AddVisibleStructuredObject(strIndex);

                //End Element
                p_pXmlReader->ReadEndElement();
            }
            else
            {
                oAllObjectFiltersRead = TRUE;
            }

            lCount++;
        }
    }

    return oResult;
}

BOOL CObjectFilter::ReadVisibleObjectFilterSchemaFrom(CXmlReader* p_pXmlReader)
{
    BOOL oAllObjectFiltersRead = FALSE;
    BOOL oResult = FALSE;
    CStdString strIndex = "";
    CStdString strSubIndex = "";
    int lCount = 0;

    if(p_pXmlReader)
    {
        oResult = TRUE;

        while(!oAllObjectFiltersRead)
        {
            if(p_pXmlReader->ReadStartElement(_T("VisibleObject"), lCount++))
            {
                if(oResult && !p_pXmlReader->ReadElement(_T("Index"), 0, strIndex)) oResult = FALSE;
                if(oResult && !p_pXmlReader->ReadElement(_T("SubIndex"), 0, strSubIndex)) oResult = FALSE;
                AddVisibleObject(strIndex, strSubIndex);

                //End Element
                p_pXmlReader->ReadEndElement();
            }
            else
            {
                oAllObjectFiltersRead = TRUE;
            }
        }
    }

    return oResult;
}

BOOL CObjectFilter::WriteVisibleObjectFilterSchemaTo(CXmlWriter* p_pXmlWriter)
{
    BOOL oResult = FALSE;
    CMmcDataConversion dataConversion;
    CStdString strIndex = "";
    CStdString strSubIndex = "";

    if(p_pXmlWriter)
    {
        oResult = TRUE;

        for(size_t i = 0; i < m_VisibleObjectIndex.size(); i++)
        {
            //Start Element "Visible object"
            if(oResult && !p_pXmlWriter->WriteStartElement(_T("VisibleObject"))) oResult = FALSE;

            dataConversion.Word2HexWordStr(m_VisibleObjectIndex[i], &strIndex);
            if(oResult && !p_pXmlWriter->WriteElement("Index", strIndex)) oResult = FALSE;

            dataConversion.UChar2HexUCharStr(m_VisibleObjectSubIndex[i], &strSubIndex);
            if(oResult && !p_pXmlWriter->WriteElement("SubIndex", strSubIndex)) oResult = FALSE;

            //End Element "Visible object"
            if(oResult && !p_pXmlWriter->WriteFullEndElement()) oResult = FALSE;
        }
    }

    return oResult;
}

