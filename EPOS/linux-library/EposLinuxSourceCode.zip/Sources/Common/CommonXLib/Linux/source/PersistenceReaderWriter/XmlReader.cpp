#include <PersistenceReaderWriter/XmlReader.h>
#include <memory.h>
#include <stdlib.h>

CXmlReader::CXmlReader(void):
    m_pXmlParser(0),
	m_oExternalXmlParser(FALSE)
{
	CreateXmlParser();
}

CXmlReader::~CXmlReader(void)
{
	DeleteXmlParser();
}

bool CXmlReader::CreateXmlParser()
{
	bool oResult = FALSE;

	DeleteXmlParser();
	if(!m_pXmlParser)
	{
		m_pXmlParser = new XML_PARSER();
		m_oExternalXmlParser = FALSE;
		oResult = TRUE;
	}

	return oResult;
}

bool CXmlReader::DeleteXmlParser()
{
	bool oResult = FALSE;

	if(m_pXmlParser)
	{
		if(!m_oExternalXmlParser)
		{
			delete m_pXmlParser;
		}
		m_pXmlParser = NULL;
		oResult = TRUE;
	}

	return oResult;
}

bool CXmlReader::GetXmlParser(XML_PARSER*& p_rpXmlParser)
{
    bool oResult(FALSE);

	if(m_pXmlParser)
	{
		p_rpXmlParser = m_pXmlParser;
		oResult = TRUE;
	}

    return oResult;
}

bool CXmlReader::Load(CStdString p_FileName)
{
	CStdString bstrDocument;
    bool oResult(FALSE);

    if(m_pXmlParser)
	{
		m_pXmlParser->Reset_XML_Document();

		oResult = m_pXmlParser->Load_XML_Document(p_FileName);
	}

    return oResult;
}

bool CXmlReader::RemoveEncoding(char* p_pDataBuffer, int p_lLen, char*& p_rpRemovedDataBuffer, int& p_rlRemovedLen)
{
    CStdString header = _T("<?xml version=\"1.0\"?>");
    CStdString data = _T("");
    bool oResult(FALSE);

    if(p_pDataBuffer)
    {
        //Init Data
        data = p_pDataBuffer;

        //Remove
        int lStartIndex = data.Find("<?");
        int lEndIndex = data.Find("?>");
        if((lStartIndex != -1) && (lEndIndex != -1) && (lEndIndex > lStartIndex))
        {
            data.Delete(0, lEndIndex + strlen("?>"));
            data.Insert(0, header);
        }

        //Add to new DataBuffer
        p_rlRemovedLen = data.GetLength()+1;
        p_rpRemovedDataBuffer = (char*)malloc(p_rlRemovedLen);
        memset(p_rpRemovedDataBuffer, 0, p_rlRemovedLen);
        memcpy(p_rpRemovedDataBuffer, data.GetBuffer(), p_rlRemovedLen-1);
        data.ReleaseBuffer();
        oResult = TRUE;
    }

    return oResult;
}

bool CXmlReader::ReadStartDocument()
{
    bool oResult(TRUE);

    if(m_pXmlParser)
	{
		m_pXmlParser->Go_to_Root();
	}
    return oResult;
}

bool CXmlReader::ReadStartElement(CStdString p_Name, int p_lElementIndex)
{
    bool oResult(FALSE);

    if(m_pXmlParser)
	{
		if(m_pXmlParser->Go_to_Child(p_Name))
		{
			oResult = TRUE;
			for(int i=0;i<p_lElementIndex;i++)
			{
				if(!m_pXmlParser->Go_Forward(p_Name))
				{
					oResult = FALSE;
					m_pXmlParser->Go_to_Parent();
					break;
				}
			}
		}
	}

    return oResult;
}

bool CXmlReader::ReadString(CStdString& p_rString)
{
    bool oResult(TRUE);

    if(m_pXmlParser)
	{
		p_rString = m_pXmlParser->Get_TextValue();
	}

    return oResult;
}

bool CXmlReader::ReadAttributeString(CStdString p_Name, CStdString& p_rString)
{
    bool oResult(FALSE);

    if(m_pXmlParser)
	{
		if(m_pXmlParser->Is_Having_Attribute(p_Name))
		{
			p_rString = m_pXmlParser->Get_Attribute_Value();
			oResult = TRUE;
		}
	}

    return oResult;
}

bool CXmlReader::ReadAttributeHexValue(CStdString p_Name, __int64& p_rllValue)
{
    bool oResult(FALSE);
    CStdString valueString(_T(""));

    if(m_pXmlParser)
    {
        if(m_pXmlParser->Is_Having_Attribute(p_Name))
        {
            __int64 lValue(0);
            valueString = m_pXmlParser->Get_Attribute_Value();

            lValue = strtol(valueString, 0 , 16);
            p_rllValue = (__int64)lValue;
            oResult = TRUE;
        }
    }

    return oResult;
}

bool CXmlReader::ReadEndElement()
{
    bool oResult(FALSE);

    if(m_pXmlParser)
	{
		if(m_pXmlParser->Go_to_Parent())
		{
			oResult = TRUE;
		}
	}

    return oResult;
}

bool CXmlReader::ReadElement(CStdString p_Name, int p_lElementIndex, CStdString& p_rString)
{
    bool oResult(FALSE);

    if(ReadStartElement(p_Name, p_lElementIndex))
    {
        oResult = ReadString(p_rString);
        ReadEndElement();
    }

    return oResult;
}

bool CXmlReader::GetByteValue(CStdString p_ValueString, BYTE& p_rucValue)
{
    __int64 llValue(0);
    bool oResult(TRUE);

    llValue = atoi(p_ValueString);
    p_rucValue = (BYTE)llValue;

    return oResult;
}

bool CXmlReader::GetUInt16Value(CStdString p_ValueString, WORD& p_rusValue)
{
    __int64 llValue(0);
    bool oResult(TRUE);

    llValue = atoi(p_ValueString);
    p_rusValue = (WORD)llValue;

    return oResult;
}

bool CXmlReader::GetUInt32Value(CStdString p_ValueString, DWORD& p_rulValue)
{
    __int64 llValue(0);
    bool oResult(TRUE);

    llValue = atoi(p_ValueString);
    p_rulValue = (DWORD)llValue;

    return oResult;
}

bool CXmlReader::GetInt32Value(CStdString p_ValueString, int& p_rlValue)
{
    __int64 llValue(0);
    bool oResult(TRUE);

    llValue = atoi(p_ValueString);
    p_rlValue = (int)llValue;

    return oResult;
}

bool CXmlReader::GetInt64Value(CStdString p_ValueString, __int64& p_rlValue)
{
    __int64 llValue(0);
    bool oResult(TRUE);

    llValue = atoi(p_ValueString);
    p_rlValue = llValue;

    return oResult;
}

bool CXmlReader::GetBoolValue(CStdString p_ValueString, bool& p_roValue)
{
    p_roValue = (p_ValueString.CompareNoCase("TRUE") == 0 );

    return !p_ValueString.IsEmpty();
}

bool CXmlReader::GetFloatValue(CStdString p_ValueString, float& p_rfValue)
{
    double ffValue(0);
    bool oResult(TRUE);

    ffValue = atof(p_ValueString);
    p_rfValue = (float)ffValue;

    return oResult;
}
