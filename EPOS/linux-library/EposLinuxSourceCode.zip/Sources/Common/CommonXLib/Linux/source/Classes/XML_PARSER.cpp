#include <Classes/XML_PARSER.h>
#include <Xml/rapidxml_print.hpp>
#include <iostream>
#include <sstream>
#include <fstream>

using namespace rapidxml;

XML_PARSER::XML_PARSER()
{
	// Init our members
	//
	m_pCurrentNode = 0;
	m_pCurrentAttribute = 0;

	// -- Errors Init --
	//
	lasterror = "";

	tabLevel = 0;
}

XML_PARSER::~XML_PARSER()
{       // Free ressource
        //
        this->Reset_XML_Document();
}

bool XML_PARSER::Load_XML_Document(CStdString strFileName)
{       lasterror = "";

        // Reset Document
        this->Reset_XML_Document();

        std::ifstream file;

        file.open(strFileName);

        if( file.is_open() )
        {
        	std::string content;
        	file >> content;

        	CStdString source = content;

        	bool result = Load_XML_From_Buffer(&source);

        	file.close();

        	return result;
        }

		return false;
}

bool XML_PARSER::Load_XML_From_Buffer(CStdString* pSource)
{
	if( pSource != 0 )
	{
		m_Doc.parse<parse_full>(pSource->GetBuffer());

		m_pCurrentNode = m_Doc.first_node();

		pSource->ReleaseBuffer();

		return true;
	}

	return false;
}

bool XML_PARSER::Get_XML_Document(CStdString* pStrXml)
{
	std::stringstream ss;

	ss << m_Doc.first_node();

	*pStrXml = ss.str();

	return false;
}

CStdString XML_PARSER::Get_CurrentTag()
{
	CStdString stCurrentTag;
	
	if( m_pCurrentNode != 0 )
		stCurrentTag = m_pCurrentNode->name();
	
	return stCurrentTag;
}

bool XML_PARSER::Is_Tag(CStdString aTag)
{ return this->Get_CurrentTag() == aTag; }

bool XML_PARSER::Is_Root()
{   
	return ( m_pCurrentNode != 0 && m_pCurrentNode == m_Doc.first_node());		
}

CStdString XML_PARSER::Get_TextValue()
{ 
	CStdString strValue;

	if( m_pCurrentNode != 0 )
	{
		node_type type = m_pCurrentNode->type();

		if( type == node_element )
			strValue = m_pCurrentNode->value();
		else
		{
			xml_node<>* first_node = m_pCurrentNode->first_node();
			
			for (xml_node<> *child = first_node; child; child = child->next_sibling())			
			{
				if( type == node_element )
				{
					strValue = m_pCurrentNode->value();
					break;
				}
			}
		}
	}

	return strValue;
}

int XML_PARSER::Get_Attribute_Count()
{
	xml_attribute<char>* attributes = m_pCurrentNode->first_attribute();
	xml_attribute<char>* attribute = attributes;
	int count = 0;
	while(attribute!=0)
	{
		count++;
		attribute = attributes->next_attribute();
	}

	return count;

}

CStdString XML_PARSER::Get_Attribute_Value(int index)
{  lasterror = "XML_PARSER::Get_Attribute_Value(int) failed";

	if(index < 0 || index > this->Get_Attribute_Count())
		return "";

	lasterror = "";

	xml_attribute<char>* attributes = m_pCurrentNode->first_attribute();
	xml_attribute<char>* attribute = attributes;
	int count = 0;
	while(attribute!=0)
	{
		if( count == index )
			return attribute->value();

		count++;
		attribute = attributes->next_attribute();
	}

	return "";
}

bool XML_PARSER::Is_Having_Attribute(CStdString Name)
{
	// Create the CString Name Object
	//
	xml_attribute<char>* attributes = m_pCurrentNode->first_attribute();

	m_pCurrentAttribute = attributes;

   	while(m_pCurrentAttribute!=0)
   	{
   		if( Name == m_pCurrentAttribute->value() )
   			return true;

   		m_pCurrentAttribute = attributes->next_attribute();
   	}

   return false;
}

CStdString XML_PARSER::Get_Attribute_Value()
{  // Assume Success
   //
   lasterror = "";

   if(m_pCurrentAttribute != 0)
         return m_pCurrentAttribute->value();

   // We can't retrieve a Attribute values
   //
   lasterror = "XML_PARSER::Get_Attribute_Value()  : Can't Retrieve an Attribute";
   return lasterror;
}

bool XML_PARSER::Add_LastChildText(CStdString data)
{    
	if( m_pCurrentNode == 0 )
		Go_to_Root();
	
	xml_node<>* pLastChild = m_Doc.allocate_node(node_element, this->Get_CurrentTag().c_str());
	
	if( m_pCurrentNode == 0 )
		Go_to_Root();

	m_pCurrentNode->append_node(pLastChild);

	m_pCurrentNode = pLastChild;

	this->Set_TextValue(data);
	
    return false;
}

bool XML_PARSER::Add_LastChildNode(CStdString Name)
{
	xml_node<>* pLastChild = m_Doc.allocate_node(node_element, Name.c_str());
	
	if( m_pCurrentNode == 0 )
		Go_to_Root();

	m_pCurrentNode->append_node(pLastChild);

	m_pCurrentNode = pLastChild;

	return false;
}

int XML_PARSER::Get_Child_Count()
{
	int lCount = 0;

	if( m_pCurrentNode == 0 )
		Go_to_Root();

	xml_node<>* first_node = m_pCurrentNode->first_node();
			
	for (xml_node<> *child = first_node; child; child = child->next_sibling())			
	{
		lCount++;
	}

	return lCount;
}

bool XML_PARSER::Add_FirstChildNode(CStdString Name)
{
    // If no child then use Add_LastChildNode or CurrentElement node not set yet
    //
    if(m_pCurrentNode != 0)
    { 
		if( Get_Child_Count()==0 )
			return this->Add_LastChildNode(Name);
    }
    else
      return (this->Add_LastChildNode(Name));

    xml_node<>* pLastChild = m_Doc.allocate_node(node_element, this->Get_CurrentTag().c_str());
	
	if( m_pCurrentNode == 0 )
		Go_to_Root();

	m_pCurrentNode->insert_node(m_pCurrentNode->first_node(), pLastChild);

	return true;
}

bool XML_PARSER::Set_Attribute(CStdString AttribName,CStdString AttribValue)
{
	if( m_pCurrentNode == 0 )
		Go_to_Root();

	m_pCurrentNode->append_attribute(m_Doc.allocate_attribute(AttribName.c_str(), AttribValue.c_str()));

    return true;
}

bool XML_PARSER::Set_TextValue(CStdString TextValue)
{
	if( m_pCurrentNode != 0 )
	{
		node_type type = m_pCurrentNode->type();

		if( type == node_element )
			m_pCurrentNode->value(TextValue.c_str());
		else
		{
			xml_node<>* first_node = m_pCurrentNode->first_node();
			
			for (xml_node<> *child = first_node; child; child = child->next_sibling())			
			{
				type = child->type();

				if( type == node_element )
				{
					m_pCurrentNode->value(TextValue.c_str());
					break;
				}
			}
		}
	}
        
	return true;
}

void XML_PARSER::Reset_XML_Document()
{
	m_Doc.remove_all_nodes();
	m_Doc.remove_all_attributes();
}

void XML_PARSER::Go_to_Root()
{
	m_pCurrentNode = m_Doc.first_node();
}

bool XML_PARSER::Go_to_Parent()
{       // Parent node
        
	if( m_pCurrentNode != 0 )
		m_pCurrentNode = m_pCurrentNode->parent();
	else
		Go_to_Root();

    return true;
}

bool XML_PARSER::Go_to_Child(CStdString NodeName)
{
	if( m_pCurrentNode == 0 )
		Go_to_Root();

	xml_node<>* first_node = m_pCurrentNode->first_node();
			
	for (xml_node<> *child = first_node; child; child = child->next_sibling())			
	{
		if( NodeName == child->name() )
		{
			m_pCurrentNode = child;

			return true;
		}
	}
        
	return false;
}

// Go to a Node attached at the same Node than the Current Node (Forward sens)
//
bool XML_PARSER::Go_Forward(CStdString NodeName)
{        
	if( m_pCurrentNode == 0 )
		Go_to_Root();

	xml_node<>* sibling = m_pCurrentNode->next_sibling();

	if( sibling != 0 )
		m_pCurrentNode = sibling;

    return sibling != 0;
}

void XML_PARSER::IncTabLevel()
{
	tabLevel++;
}

void XML_PARSER::DecTabLevel()
{
	tabLevel--;
}

bool XML_PARSER::AddNewLineTab()
{	
	CStdString strText = "\n";

	if( m_pCurrentNode == 0 )
		Go_to_Root();
	
	node_type type = m_pCurrentNode->type();

	if(type==node_element)
	{
		if(tabLevel > 0)
			for(int i=0;i<tabLevel;i++) strText += L"\t";
		
		return Add_LastChildNode(strText);
	}

	return false;
}

