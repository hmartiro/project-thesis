#pragma once

#include <StdString.h>
#include <MmcTypeDefinition.h>
#include "../Classes/XML_PARSER.h"

class CXmlReader;

class CXmlWriter
{
public:
	CXmlWriter(void);
	~CXmlWriter(void);

	BOOL WriteStartElement(CStdString p_Name);
	BOOL WriteElement(CStdString p_Name, CStdString p_String);
	BOOL WriteFullEndElement();
	BOOL WriteString(CStdString p_String);
	
private:
	BOOL CreateXmlParser();
	BOOL DeleteXmlParser();

	BOOL GetUInt32String(DWORD p_ulValue,CStdString& p_rValueString);
	BOOL GetInt32String(DWORD p_lValue,CStdString& p_rValueString);
	BOOL GetBoolString(BOOL p_oValue,CStdString& p_rValueString);
	BOOL GetFloatString(float p_fValue,CStdString& p_rValueString);

private:
	XML_PARSER* m_pXmlParser;
	BOOL m_oExternalXmlParser;
};
