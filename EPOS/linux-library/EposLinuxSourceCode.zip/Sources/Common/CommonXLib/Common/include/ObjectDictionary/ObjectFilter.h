// ObjectFilter.h: Schnittstelle f�r die Klasse CObjectFilter.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_OBJECTFILTER_H__491B4DA7_AB9C_11D7_A273_00A02436C4EF__INCLUDED_)
#define AFX_OBJECTFILTER_H__491B4DA7_AB9C_11D7_A273_00A02436C4EF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <StdString.h>
#include <MmcTypeDefinition.h>
#include "../Classes/XML_PARSER.h"

class CXmlReader;
class CXmlWriter;

class CObjectFilter: public XML_PARSER
{
public:
    //Persistence
    BOOL ReadFrom(CXmlReader* p_pXmlReader, int lCount);
    BOOL WriteTo(CXmlWriter* p_pXmlWriter);

    BOOL SetInternalObjectFilter(BOOL p_oActive);
	void SetServiceModeActive(BOOL active);
    void Serialize(CArchive& ar);
    BOOL IsVisible(CStdString objectName, WORD index);
    BOOL IsVisible(CStdString objectName, WORD index, BYTE subIndex);
    BOOL IsVisibleObjectExisting(WORD index, BYTE subIndex);

    BOOL IsEmpty();
    void SetName(CStdString name);
    void SetDescription(CStdString description);
    CStdString GetName();
    CObjectFilter();
    CObjectFilter(CObjectFilter& objectFilter);
    virtual ~CObjectFilter();

    void Reset();
    BOOL LoadObjectFilterSchema(CStdString* pXmlData);
    BOOL StoreObjectFilterSchema(CStdString* pXmlData);

    CObjectFilter& operator=(CObjectFilter &other);
    void AddVisibleStructuredObject(WORD index);
    void AddVisibleObject(WORD index, BYTE subIndex);
    BOOL DeleteVisibleObject(WORD index, BYTE subIndex);
    BOOL DeleteAllVisibleObjects();

private:
    CStdString GetIndexStr(WORD wIndex);
    CStdString GetSubIndexStr(BYTE bSubIndex);

    void Parse_XML_Document();
    BOOL IsObjectNameVisible(CStdString objectName);
    void AddVisibleStructuredObject(CStdString strIndex);
    void AddVisibleObject(CStdString strIndex, CStdString strSubIndex);

    //Persistence
    BOOL ReadStructuredObjectFilterSchemaFrom(CXmlReader* p_pXmlReader);
    BOOL ReadVisibleObjectFilterSchemaFrom(CXmlReader* p_pXmlReader);
    BOOL WriteVisibleObjectFilterSchemaTo(CXmlWriter* p_pXmlWriter);
    BOOL WriteStructuredObjectFilterSchemaTo(CXmlWriter* p_pXmlWriter);

private:
    BOOL m_oEmpty;
    BOOL m_oServiceModeActive;
	BOOL m_oInternalObjectsVisible;
    CStdString m_Name;
    CStdString m_Description;

    //Not filtered structured object
    std::vector<unsigned short> m_VisibleStructuredObjectIndex;

    //Not filtered objects
    std::vector<unsigned short> m_VisibleObjectIndex;
    std::vector<unsigned char> m_VisibleObjectSubIndex;
};

#endif // !defined(AFX_OBJECTFILTER_H__491B4DA7_AB9C_11D7_A273_00A02436C4EF__INCLUDED_)
