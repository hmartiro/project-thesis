#pragma once

#include <ObjectDictionary/ObjectEntryBase.h>

class CObjectEntryIterator
{
public:
	CObjectEntryIterator(void);
	~CObjectEntryIterator(void);

	//Initialisation
	BOOL InitBaseList(tObjectEntryList* p_pObjectEntryBaseList);
	BOOL InitList(tObjectEntryList* p_pObjectEntryList);
	
	//Iteration
	BOOL First();
	BOOL Next();
	CObjectEntryBase* Current();
	BOOL IsFinished();

private:
	BOOL FirstInObjectEntryList();
	BOOL FirstInObjectEntryBaseList();
	BOOL NextInObjectEntryList();
	BOOL NextInObjectEntryBaseList();
	CObjectEntryBase* CurrentInObjectEntryList();
	CObjectEntryBase* CurrentInObjectEntryBaseList();
	
	BOOL Reset();
	BOOL DeleteSubObjectEntryIterator();

private:
	//List
	tObjectEntryList* m_pObjectEntryBaseList;
	tObjectEntryList* m_pObjectEntryList;
	
	//Current Position
	tObjectEntryList::iterator m_ListPosition;
	tObjectEntryList::iterator m_ListBasePosition;
	CObjectEntryIterator* m_pSubObjectEntryIterator;
};
