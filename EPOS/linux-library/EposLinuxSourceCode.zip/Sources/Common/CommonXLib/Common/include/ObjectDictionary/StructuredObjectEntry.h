// StructuredObjectEntry.h: Schnittstelle f�r die Klasse CStructuredObjectEntry.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_StructuredObjectEntry_H__0253E5E9_6B67_11D7_A23D_00A02436C4EF__INCLUDED_)
#define AFX_StructuredObjectEntry_H__0253E5E9_6B67_11D7_A23D_00A02436C4EF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <ObjectDictionary/ObjectEntryBase.h>

class CObjectEntryIterator;
class XML_PARSER;

class CStructuredObjectEntry : public CObjectEntryBase  
{	
public:
	CStructuredObjectEntry();
	virtual ~CStructuredObjectEntry();

	void Init() {m_strClassType=_T("CStructuredObjectEntry");}

	//ObjectFilter
	virtual BOOL InitObjectFilter(CObjectFilter* pObjectFilter);

    //Common
	virtual CObjectEntryBase* Clone();
	virtual CStructuredObjectEntry& operator=(CStructuredObjectEntry& other);
	virtual BOOL Reset();
	virtual BOOL ResetValue();

	//Object
	BOOL AddObject(CObjectEntryBase* pObject);
	BOOL SetFirstSubObjectEntryValues(CObjectEntryBase* pObjectEntry);

	//Information
	CObjectEntryBase* SearchObject(WORD index, WORD subIndex);
	int GetNumberOfSubObjects();

	//Xml
	virtual void Serialize(CArchive &ar);

	BOOL StoreObjectDictionarySchema(XML_PARSER* pXmlParser);
	void Parse_XML_Document(XML_PARSER* pXmlParser);

	//Iteration
	CObjectEntryIterator* CreateObjectEntryIterator();

private:
	BOOL DeleteObjectEntryList();

private:
	tObjectEntryList m_ObjectEntryList;
};

#endif // !defined(AFX_StructuredObjectEntry_H__0253E5E9_6B67_11D7_A23D_00A02436C4EF__INCLUDED_)
