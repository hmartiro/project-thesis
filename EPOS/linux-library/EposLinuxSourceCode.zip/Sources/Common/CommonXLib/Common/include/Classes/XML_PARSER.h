#if !defined(XML_PARSER_H)
#define XML_PARSER_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <vector>
#include <StdString.h>
#include <Xml/rapidxml.hpp>

class XML_PARSER
{
public:
   XML_PARSER();                                                  // C'tor
   virtual ~XML_PARSER();                                         // D'tor

   void		Reset_XML_Document();											// Clear the XML Document
   bool		Add_FirstChildNode(CStdString Name);							// Add a new CHILD NODE at the Begining of Current Node
   void		IncTabLevel();
   void		DecTabLevel();
   bool		AddNewLineTab();
   bool		Get_XML_Document(CStdString* pBstrXml);                         // Get the XML Representation of the entire document
   bool		Load_XML_From_Buffer(CStdString* pSource);
   bool		Is_Tag(CStdString aTag);										// Return true if it's equal to the Current Tag
   bool		Add_LastChildNode(CStdString Name);								// Add a new CHILD NODE at the End of Current Node
   bool		Set_Attribute(CStdString AttribName,CStdString AttribValue);    // Set an attribute to the Current Node
   bool		Go_to_Parent();													// Go to the parent node of the current node
   bool		Is_Having_Attribute(CStdString Name);							// Return true if current node have the specified attribute defined
   CStdString Get_Attribute_Value(int index);								// Return the attribute value selected by "Is_Having_Attribute()"
   CStdString Get_Attribute_Value();										// Return the attribute value selected by "Is_Having_Attribute()"
   bool		Go_to_Child(CStdString NodeName);								// Go to a Direct Child Node
   bool		Go_Forward(CStdString NodeName);								// Go to a next Node at the same Node than the Current
   bool		Load_XML_Document(CStdString strFileName);						// Load an XML Document from File
   void		Go_to_Root();													// Go to the Root node
   CStdString Get_TextValue();												// Get the Text Value when it's a TEXT or CDATA node
   bool		Set_TextValue(CStdString TextValue);							// Set a Text to the Current Node
   bool		Is_Root();														// Test if a Tag is the Root
   int		Get_Child_Count();												// Return the number of childs for the current node
   bool		Add_LastChildText(CStdString text);								// Add a new Text Section at the End of Current Node
   CStdString Get_CurrentTag();											// Get the Current Tag value  (with "<>")
   int		Get_Attribute_Count();		                                    // Return the number of attributes for the current node

private:
	void CheckError();
  
private:
	rapidxml::xml_document<> m_Doc;
	rapidxml::xml_node<>*	 m_pCurrentNode;
	rapidxml::xml_attribute<char>*	 m_pCurrentAttribute;

	// Error Status String
	//
	CStdString lasterror;

	int tabLevel;
};

#endif

