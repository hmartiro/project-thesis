#pragma once

#include <StdString.h>
#include <MmcTypeDefinition.h>
#include "../Classes/XML_PARSER.h"

class CXmlReader
{
public:
    CXmlReader(void);
    ~CXmlReader(void);

	bool Load(CStdString p_FileName);
	bool ReadStartElement(CStdString p_Name, int p_lElementIndex);
	bool ReadEndElement();
    bool ReadElement(CStdString p_Name, int p_lElementIndex, CStdString& p_rString);
	bool ReadStartDocument();
	bool ReadAttributeString(CStdString p_Name, CStdString& p_rString);
	bool ReadAttributeHexValue(CStdString p_Name, __int64& p_rllValue);
	bool GetXmlParser(XML_PARSER*& p_rpXmlParser);
	bool ReadString(CStdString& p_rString);
	
private:
	bool CreateXmlParser();
	bool DeleteXmlParser();

    //bool ReadXmlDataFromFile(CFile* p_pFile, BSTR* p_pXmlData);
    bool RemoveEncoding(char* p_pDataBuffer, int p_lLen, char*& p_rpRemovedDataBuffer, int& p_rlRemovedLen);

    bool GetByteValue(CStdString p_ValueString, BYTE& p_rucValue);
    bool GetUInt16Value(CStdString p_ValueString, WORD& p_rusValue);
    bool GetUInt32Value(CStdString p_ValueString, DWORD& p_rulValue);
    bool GetInt32Value(CStdString p_ValueString, int& p_rlValue);
    bool GetInt64Value(CStdString p_ValueString, __int64& p_rlValue);
    bool GetBoolValue(CStdString p_ValueString, bool& p_roValue);
    bool GetFloatValue(CStdString p_ValueString, float& p_rfValue);

private:
	XML_PARSER* m_pXmlParser;
	bool		m_oExternalXmlParser;
	CStdString	m_strFileName;
};
