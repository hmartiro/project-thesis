#pragma once

#include <ObjectDictionary/ObjectEntryBase.h>

class CObjectEntryBaseIterator
{
public:
	CObjectEntryBaseIterator(void);
	~CObjectEntryBaseIterator(void);

	//Initialisation
	BOOL InitBaseList(tObjectEntryList* p_pObjectEntryBaseList);
	
	//Iteration
	BOOL First();
	BOOL Next();
	CObjectEntryBase* Current();
	BOOL IsFinished();

private:
	BOOL Reset();

protected:
	//List
	tObjectEntryList* m_pObjectEntryBaseList;
		
	//Current Position
	tObjectEntryList::iterator m_ListPosition;
};
