// Command_VCS_Move.h: Schnittstelle f�r die Klasse CCommand_VCS_Move.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include <CommunicationModel/Common/CommunicationModelDefinitions.h>
#ifdef _MMC_VCS_MOVE

#include <CommunicationModel/CommonLayer/Classes/Commands/VirtualCommandSet/BaseClasses/Command_VCS.h>
#include "Command_VCS_Move_Definitions.h"

class CCommand_VCS_Move : public CCommand_VCS
{
public:
    CCommand_VCS_Move();
    CCommand_VCS_Move(DWORD p_ulCommandId);
    virtual ~CCommand_VCS_Move();

    BOOL InitCommand(DWORD p_ulCommandId);

    CCommand_VCS_Move& operator=(CCommand_VCS_Move& other);
    CCommandRoot*CloneCommand();

private:
    BOOL InitCommand_Configuration(DWORD p_ulCommandId);
    BOOL InitCommand_ConfigurationMotor(DWORD p_ulCommandId);
    BOOL InitCommand_ConfigurationSensor(DWORD p_ulCommandId);
    BOOL InitCommand_CurrentMode(DWORD p_ulCommandId);
    BOOL InitCommand_InputsOutputs(DWORD p_ulCommandId);
    BOOL InitCommand_MotionInfo(DWORD p_ulCommandId);
    BOOL InitCommand_PositionMode(DWORD p_ulCommandId);
    BOOL InitCommand_StateMachine(DWORD p_ulCommandId);
    BOOL InitCommand_VelocityMode(DWORD p_ulCommandId);
    BOOL InitCommand_FirmwareDownload(DWORD p_ulCommandId);

    void SetDefaultParameter_GetCurrentRegulatorGain();
    void SetDefaultParameter_GetVelocityRegulatorGain();
    void SetDefaultParameter_GetMaxFollowingError();
    void SetDefaultParameter_GetMaxProfileVelocity();
    void SetDefaultParameter_GetMaxAcceleration();
    void SetDefaultParameter_GetVelocityUnits();
    void SetDefaultParameter_SetCurrentRegulatorGain();
    void SetDefaultParameter_SetVelocityRegulatorGain();
    void SetDefaultParameter_SetMaxFollowingError();
    void SetDefaultParameter_SetMaxProfileVelocity();
    void SetDefaultParameter_SetMaxAcceleration();
    void SetDefaultParameter_SetVelocityUnits();

    void SetDefaultParameter_SetEncoderParameter();
    void SetDefaultParameter_GetEncoderParameter();
    void SetDefaultParameter_SetSensorType();
    void SetDefaultParameter_GetSensorType();
    void SetDefaultParameter_SetIncEncoderParameter();
    void SetDefaultParameter_GetIncEncoderParameter();
    void SetDefaultParameter_SetHallSensorParameter();
    void SetDefaultParameter_GetHallSensorParameter();
    void SetDefaultParameter_SetSsiAbsEncoderParameter();
    void SetDefaultParameter_GetSsiAbsEncoderParameter();

    void SetDefaultParameter_SetMotorParameter();
    void SetDefaultParameter_SetMotorType();
    void SetDefaultParameter_SetDcMotorParameter();
    void SetDefaultParameter_SetEcMotorParameter();
    void SetDefaultParameter_GetMotorType();
    void SetDefaultParameter_GetMotorParameter();
    void SetDefaultParameter_GetDcMotorParameter();
    void SetDefaultParameter_GetEcMotorParameter();

    //Current mode
    void SetDefaultParameter_GetCurrentMust();
    void SetDefaultParameter_SetCurrentMust();
    void SetDefaultParameter_ActivateAnalogCurrentSetpoint();
    void SetDefaultParameter_DeactivateAnalogCurrentSetpoint();
    void SetDefaultParameter_EnableAnalogCurrentSetpoint();
    void SetDefaultParameter_DisableAnalogCurrentSetpoint();

    //Input and output configuration
    void SetDefaultParameter_DigitalInputConfiguration();
    void SetDefaultParameter_DigitalOutputConfiguration();
    void SetDefaultParameter_AnalogInputConfiguration();
    void SetDefaultParameter_GetAllDigitalInputs();
    void SetDefaultParameter_GetAllDigitalOutputs();
    void SetDefaultParameter_GetAnalogInput();
    void SetDefaultParameter_SetAllDigitalOutputs();
    void SetDefaultParameter_SetAnalogOutput();

    //Motion info
    void SetDefaultParameter_GetCurrentIs();
    void SetDefaultParameter_GetMovementState();
    void SetDefaultParameter_GetPositionIs();
    void SetDefaultParameter_GetVelocityIs();

    //PM
    void SetDefaultParameter_GetPositionMust();
    void SetDefaultParameter_SetPositionMust();
    void SetDefaultParameter_ActivateAnalogPositionSetpoint();
    void SetDefaultParameter_DeactivateAnalogPositionSetpoint();
    void SetDefaultParameter_EnableAnalogPositionSetpoint();
    void SetDefaultParameter_DisableAnalogPositionSetpoint();

    void SetDefaultParameter_ClearFault();
    void SetDefaultParameter_GetState();
    void SetDefaultParameter_GetDisableState();
    void SetDefaultParameter_GetEnableState();
    void SetDefaultParameter_GetFaultState();
    void SetDefaultParameter_GetOperationMode();
    void SetDefaultParameter_GetQuickStopState();
    void SetDefaultParameter_SendNMTService();
    void SetDefaultParameter_SetState();
    void SetDefaultParameter_SetDisableState();
    void SetDefaultParameter_SetEnableState();
    void SetDefaultParameter_SetOperationMode();
    void SetDefaultParameter_SetQuickStopState();

    void SetDefaultParameter_GetVelocityMust();
    void SetDefaultParameter_SetVelocityMust();
    void SetDefaultParameter_ActivateAnalogVelocitySetpoint();
    void SetDefaultParameter_DeactivateAnalogVelocitySetpoint();
    void SetDefaultParameter_EnableAnalogVelocitySetpoint();
    void SetDefaultParameter_DisableAnalogVelocitySetpoint();

    void SetDefaultParameter_GetSerialNumber();
    void SetDefaultParameter_GetBaseSectorVersion();
};
#endif //_MMC_VCS_MOVE
