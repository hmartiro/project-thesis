// ErrorCode_Defintions.h: Schnittstelle f�r die Klasse CErrorCode_Defintions.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ErrorCode_Defintions_H__DD421E4C_9091_4F06_9358_CB291C3646E7__INCLUDED_)
#define AFX_ErrorCode_Defintions_H__DD421E4C_9091_4F06_9358_CB291C3646E7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/***********************************************************************************/
//0x1xxxxxxx	Allgemeine Fehler

//0x2xxxxxxx	Interface Layer
//0x21xxxxxx	Interface RS232
//0x22xxxxxx	Interface CAN

//0x3xxxxxxx	ProtocolStack Layer
//0x31xxxxxx	ProtocolStack EposRS232
//0x32xxxxxx	ProtocolStack CANopen

//0x4xxxxxxx	DeviceCommandSet Layer
//0x41xxxxxx	Device Epos (+ Fehler definiert in Epos Firmware 0x0xxxxxxx)

//0x5xxxxxxx	VirtualCommandSet Layer
//0x51xxxxxx	VirtualDevice
/************************************************************************************/

#define k_NoError       												0x00000000

//Allgemeine Fehler (0x1xxxxxxx)
#define k_Error_Internal    											0x10000001
#define k_Error_NullPointer     										0x10000002
#define k_Error_HandleNotValid      									0x10000003
#define k_Error_BadVirtualDeviceName    								0x10000004
#define k_Error_BadDeviceName   										0x10000005
#define k_Error_BadProtocolStackName    								0x10000006
#define k_Error_BadInterfaceName    									0x10000007
#define k_Error_BadPortName     										0x10000008
#define k_Error_LibraryNotLoaded										0x10000009
#define k_Error_ExecutingCommand										0x1000000A
#define k_Error_Timeout     											0x1000000B
#define k_Error_BadParameter											0x1000000C
#define k_Error_CommandAbortedByUser									0x1000000D
#define k_Error_BufferTooSmall      									0x1000000E
#define k_Error_NoCommunicationFound                                    0x1000000F
#define k_Error_FunctionNotSupported                                    0x10000010
#define k_Error_ParameterAlreadyUsed									0x10000011
#define k_Error_BadVirtualDeviceHandle  								0x10000012
#define k_Error_BadDeviceHandle 										0x10000013
#define k_Error_BadProtocolStackHandle  								0x10000014
#define k_Error_BadInterfaceHandle      								0x10000015
#define k_Error_BadPortHandle       									0x10000016
#define k_Error_BadAddressParameter                                     0x10000017
#define k_Error_BadVariableInfoFile                                     0x10000018
#define k_Error_VariableNameNotFound                                    0x10000019

//InterfaceLayer (0x2xxxxxxx)
#define k_Error_I_OpeningInterface  									0x20000001
#define k_Error_I_ClosingInterface  									0x20000002
#define k_Error_I_InterfaceNotOpen  									0x20000003
#define k_Error_I_OpeningPort											0x20000004
#define k_Error_I_ClosingPort											0x20000005
#define k_Error_I_PortNotOpen											0x20000006
#define k_Error_I_ResetPort     										0x20000007
#define k_Error_I_SetPortSettings   									0x20000008
#define k_Error_I_SetPortMode   										0x20000009
//Interface RS232 (0x21xxxxxx)
#define k_Error_RS232_WriteData 										0x21000001
#define k_Error_RS232_ReadData  										0x21000002
//Interface CAN (0x22xxxxxx)
#define k_Error_CAN_ReceiveCanFrame 									0x22000001
#define k_Error_CAN_TransmitCanFrame									0x22000002
//Interface USB (0x23xxxxxx)
#define k_Error_USB_WriteData   										0x23000001
#define k_Error_USB_ReadData											0x23000002
#define k_Error_USB_Rescan  											0x23000003
#define k_Error_USB_Reload  											0x23000004

//ProtocolStackLayer (0x3xxxxxxx)
//ProtocolStack MaxonSerialV1 (0x31xxxxxx)
#define k_Error_MaxonSerialV1_NegAckReceived							0x31000001
#define k_Error_MaxonSerialV1_BadCrcReceived							0x31000002
#define k_Error_MaxonSerialV1_BadDataSizeReceived   					0x31000003
//ProtocolStack CANopen (0x32xxxxxx)
#define k_Error_CANopen_SdoReceiveFrameNotReceived      				0x32000001
#define k_Error_CANopen_RequestedCanFrameNotReceived					0x32000002
#define k_Error_CANopen_CanFrameNotReceived     						0x32000003
//ProtocolStack EsamRS232 (0x33xxxxxx)
#define k_Error_InfoteamSerial_BadAckReceived                           0x33000001
#define k_Error_InfoteamSerial_RepAckReceived   				        0x33000002
#define k_Error_InfoteamSerial_BadCrcReceived                           0x33000003
#define k_Error_InfoteamSerial_BadDataSizeReceived  			        0x33000004
#define k_Error_InfoteamSerial_ChunkSizeTooHigh     					0x33000005
//ProtocolStack Epos2USB (0x34xxxxxx)
#define k_Error_MaxonSerialV2_Stuffing      							0x34000001
#define k_Error_MaxonSerialV2_Destuffing        						0x34000002
#define k_Error_MaxonSerialV2_BadCrcReceived    						0x34000003
#define k_Error_MaxonSerialV2_BadDataSizeReceived           			0x34000004
#define k_Error_MaxonSerialV2_BadDataSizeWritten    					0x34000005


//DeviceCommandSet Layer (0x4xxxxxxx)
//DeviceEpos (0x41xxxxxx + Fehler definiert in Epos Firmware 0x0xxxxxxx)
#define k_Error_DeviceEpos_Toggle										0x05030000
#define k_Error_DeviceEpos_SDOTimeOut   								0x05040000
#define k_Error_DeviceEpos_ClientServer 								0x05040001
#define k_Error_DeviceEpos_InvalidBlockSize     						0x05040002
#define k_Error_DeviceEpos_InvalidSequence      						0x05040003
#define k_Error_DeviceEpos_CrcErr       								0x05040004
#define k_Error_DeviceEpos_OutOfMemory  								0x05040005
#define k_Error_DeviceEpos_Access   									0x06010000
#define k_Error_DeviceEpos_WriteOnly    								0x06010001
#define k_Error_DeviceEpos_ReadOnly     								0x06010002
#define k_Error_DeviceEpos_ObjectNotExist   							0x06020000
#define k_Error_DeviceEpos_PDOMapping   								0x06040041
#define k_Error_DeviceEpos_PDOLength									0x06040042
#define k_Error_DeviceEpos_GeneralParameter 							0x06040043
#define k_Error_DeviceEpos_GeneralInternIncompatibility     			0x06040047
#define k_Error_DeviceEpos_Hardware     								0x06060000
#define k_Error_DeviceEpos_ServiceParameter     						0x06070010
#define k_Error_DeviceEpos_ServiceParameterToHigh   					0x06070012
#define k_Error_DeviceEpos_ServiceParameterToLow						0x06070013
#define k_Error_DeviceEpos_SubObject    								0x06090011
#define k_Error_DeviceEpos_ValueRange   								0x06090030
#define k_Error_DeviceEpos_ValueToHigh  								0x06090031
#define k_Error_DeviceEpos_ValueToLow   								0x06090032
#define k_Error_DeviceEpos_MaxLessMin   								0x06090036
#define k_Error_DeviceEpos_General      								0x08000000
#define k_Error_DeviceEpos_TransferOrStore  							0x08000020
#define k_Error_DeviceEpos_LocalControl     						    0x08000021
#define k_Error_DeviceEpos_WrongDevice      							0x08000022

#define k_Error_DeviceEpos_UnknownNetworkId								0x0A000001
#define k_Error_DeviceEpos_UnknownNodeId								0x0A000002

#define k_Error_DeviceEpos_CANId    									0x0F00FFB9
#define k_Error_DeviceEpos_ServiceMode  								0x0F00FFBC
#define k_Error_DeviceEpos_Password     								0x0F00FFBE
#define k_Error_DeviceEpos_IllegalCommand   							0x0F00FFBF
#define k_Error_DeviceEpos_WrongNMTState								0x0F00FFC0
#define k_Error_DeviceEsam2_SegmentedTransferRequired_InitDone          0x0F00FFC2
#define k_Error_DeviceEsam2_DataHistoryBufferOverrun			        0x0F010072

#define k_Error_DeviceEpos_CommAborted							        0x0FFFFFF1
#define k_Error_DeviceEpos_CommOverflow							        0x0FFFFFF2
#define k_Error_DeviceEpos_SegmentedComError					        0x0FFFFFF9
#define k_Error_DeviceEpos_WrongAxisNumber						        0x0FFFFFFA
#define k_Error_DeviceEpos_WrongCanDevice						        0x0FFFFFFB
#define k_Error_DeviceEpos_WrongCanPort							        0x0FFFFFFC
#define k_Error_DeviceEpos_WrongCallingParameter				        0x0FFFFFFD
#define k_Error_DeviceEpos_GeneralComError						        0x0FFFFFFE
#define k_Error_DeviceEpos_Timeout								        0x0FFFFFFF


//OldDeviceEpos (0x41xxxxxx + Fehler definiert in Epos Firmware 0x0xxxxxxx)
#define k_Error_OldDeviceEpos_DeviceOldMask 							0x0F000000
#define k_Error_OldDeviceEpos_ToggleErr     							0x0F00FFFF
#define k_Error_OldDeviceEpos_SdoTimeOut    							0x0F00FFFE
#define k_Error_OldDeviceEpos_CcsErr        							0x0F00FFFD
#define k_Error_OldDeviceEpos_InvalidBlockSize  						0x0F00FFFC
#define k_Error_OldDeviceEpos_InvalidSequenceNo         				0x0F00FFFB
#define k_Error_OldDeviceEpos_CrcErr        							0x0F00FFFA
#define k_Error_OldDeviceEpos_OutOfMemory   							0x0F00FFF9
#define k_Error_OldDeviceEpos_AccessErr     							0x0F00FFF8
#define k_Error_OldDeviceEpos_WriteOnly     							0x0F00FFF7
#define k_Error_OldDeviceEpos_ReadOnly      							0x0F00FFF6
#define k_Error_OldDeviceEpos_ObjNotExist   							0x0F00FFF5
#define k_Error_OldDeviceEpos_NoPdoObj      							0x0F00FFF4
#define k_Error_OldDeviceEpos_PdoLengthErr      						0x0F00FFF3
#define k_Error_OldDeviceEpos_GeneralParamErr   						0x0F00FFF2
#define k_Error_OldDeviceEpos_GeneralInternIncomp   					0x0F00FFF1
#define k_Error_OldDeviceEpos_HWErr     								0x0F00FFF0
#define k_Error_OldDeviceEpos_ServiceParamErr   						0x0F00FFEF
#define k_Error_OldDeviceEpos_ServiceParamTooHigh   					0x0F00FFEE
#define k_Error_OldDeviceEpos_ServiceParamTooLow    					0x0F00FFED
#define k_Error_OldDeviceEpos_SubIndxErr								0x0F00FFEC
#define k_Error_OldDeviceEpos_ValueRange								0x0F00FFEB
#define k_Error_OldDeviceEpos_ValTooHigh								0x0F00FFEA
#define k_Error_OldDeviceEpos_ValTooLow     							0x0F00FFE9
#define k_Error_OldDeviceEpos_MaxLessMin								0x0F00FFE8
#define k_Error_OldDeviceEpos_GeneralErr								0x0F00FFE7
#define k_Error_OldDeviceEpos_TransfOrStoreErr  						0x0F00FFE6
#define k_Error_OldDeviceEpos_LocalControlErr   						0x0F00FFE5
#define k_Error_OldDeviceEpos_WrongDeviceState      					0x0F00FFE4
#define k_Error_OldDeviceEpos_WrongNmtState     		    			0x0F00FFC0
#define k_Error_OldDeviceEpos_IllegalCommand							0x0F00FFBF
#define k_Error_OldDeviceEpos_ErrorPassword     						0x0F00FFBE
#define k_Error_OldDeviceEpos_ErrorLength       						0x0F00FFBD
#define k_Error_OldDeviceEpos_ErrorService      						0x0F00FFBC

#define k_Error_OldDeviceEpos_NoMoreSegments							0x0F00FFBB
#define k_Error_OldDeviceEpos_SdoAbort      							0x0F00FFBA
#define k_Error_OldDeviceEpos_ErrorCanId    							0x0F00FFB9
#define k_Error_OldDeviceEpos_ErrorAdress       						0x0F00FFB8
#define k_Error_OldDeviceEpos_SubIndexDoesNotExist      				0x0F00FFB7

//VirtualCommandSetLayer (0x5xxxxxxx)
//VirtualDevice (0x51xxxxxx)
#define k_Error_VirtualDevice_BadObjectSizeExpected                     0x51000001



#endif // !defined(AFX_ErrorCode_Defintions_H__DD421E4C_9091_4F06_9358_CB291C3646E7__INCLUDED_)
