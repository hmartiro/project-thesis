/////////////////////////////////////////////////////////////////////////
// DcsEsconDef.h
//
// Project:             Dtm
// Author:              Adrian Ineichen
// Date of Creation:    25.09.2010
//
// Contains all ESCON related definitions.
//
// Copyright � 2010, maxon motor ag.
// All rights reserved.
/////////////////////////////////////////////////////////////////////////

#if !defined(DCS_ESCON_DEF_H__20100517__INCLUDED_)
#define DCS_ESCON_DEF_H__20100517__INCLUDED_

#include <MmcTypeDefinition.h>

//Default ProtocolStack Settings
const DWORD     DEFAULT_TRANSFER_RATE_USB               = 1000000;
const DWORD     DEFAULT_TIMEOUT                         = 500;

//Object Dictionary Access Commands
const DWORD     ESCON_READ_OBJECT                       = 0x00020010;
const DWORD     ESCON_WRITE_OBJECT                      = 0x00020011;
const DWORD     ESCON_INITIATE_SEGMENT_READ             = 0x00020012;
const DWORD     ESCON_INITIATE_SEGMENT_WRITE            = 0x00020013;
const DWORD     ESCON_SEGMENT_READ                      = 0x00020014;
const DWORD     ESCON_SEGMENT_WRITE                     = 0x00020015;
const DWORD     ESCON_ABORT_SEGMENT_TRANSFER            = 0x00020016;

//RegulationTuning
const double    PI                                      = 3.14159265359;
const double    POSITION_GAIN_P_UNIT_FACTOR             = 100.53;
const double    POSITION_GAIN_I_UNIT_FACTOR             = 12.868;
const double    POSITION_GAIN_D_UNIT_FACTOR             = 12566.37;
const double    POSITION_FEED_FORWARD_FACTOR            = 15625;
const double    VELOCITY_GAIN_P_UNIT_FACTOR             = 50265.48;
const double    VELOCITY_GAIN_I_UNIT_FACTOR             = 201.062;
const double    VELOCITY_FEED_FORWARD_FACTOR            = 15625;

//DeviceCommandSet
#pragma pack(push, 1)
union UEsconControlByte
{
    struct SControlByte
    {
            BYTE    bLength         :6;
            BYTE    bToggle         :1;
            BYTE    bMoreSegments   :1;
    }structure;
    BYTE bValue;
};
#pragma pack(pop)

//Controlword
enum EControlword
{
    CW_ENABLE                           = 0x0001,
    CW_DIRECTION                        = 0x0002,
    CW_STOP                             = 0x0004,
    CW_FAULT_RESET                      = 0x0008
};

//Save/Restore parameters
enum EParametersControlword
{
    PCW_SAVE_ALL_PARAMETERS             = 0x01,
    PCW_RESTORE_NON_VOLATILE_MEMORY     = 0x02,
    PCW_RESTORE_DEFAULT_PARAMETERS      = 0x04
};

enum EStatusword
{
    SW_INIT                         = 0x0000,
    SW_DISABLE                      = 0x0001,
    SW_OFFSET                       = 0x0002,

    SW_STOP_STANDSTILL              = 0x1000,
    SW_STOP                         = 0x2000,
    SW_ENABLED                      = 0x4000,
    SW_FAULT                        = 0x8000
};

enum EDeviceComState
{
    DCS_DISCONNECTED,
    DCS_OFFLINE,
    DCS_DISABLED,
    DCS_ENABLED,
    DCS_ERROR,
    DCS_UNKNOWN
};

//Profile Position
const WORD      IMMEDIATE_ABS_POSITION                  = 0x003F;
const WORD      ABSOLUTE_POSITION                       = 0x001F;
const WORD      IMMEDIATE_REL_POSITION                  = 0x007F;
const WORD      RELATIVE_POSITION                       = 0x005F;

//Homing
const WORD      START_HOMING                            = 0x001F;
const WORD      STOP_HOMING                             = 0x011F;

//Profile Velocity
const WORD      MOVE_WITH_VELOCITY                      = 0x000F;

//General
const WORD      STOP_PROFILE                            = 0x010F;
const WORD      START_PROFILE                           = 0x000F;


//Object dictionary
const WORD      INDEX_DEVICE_NAME                               = 0x1000;
const BYTE      SUBINDEX_DEVICE_NAME                            = 0x00;

const WORD      INDEX_SERIAL_NUMBER                             = 0x1001;
const BYTE      SUBINDEX_SERIAL_NUMBER                          = 0x00;

const WORD      INDEX_VERSION                                   = 0x1002;
const BYTE      SUBINDEX_SOFTWARE_VERSION                       = 0x01;
const BYTE      SUBINDEX_HARDWARE_VERSION                       = 0x02;
const BYTE      SUBINDEX_APPLICATION_NUMBER                     = 0x03;
const BYTE      SUBINDEX_APPLICATION_VERSION                    = 0x04;

const WORD      INDEX_CONTROL_WORD                              = 0x2000;
const BYTE      SUBINDEX_CONTROL_WORD                           = 0x00;

const WORD      INDEX_STATUS_WORD                               = 0x2001;
const BYTE      SUBINDEX_STATUS_WORD                            = 0x00;

const WORD      INDEX_INFO_WORD                                 = 0x2002;
const BYTE      SUBINDEX_INFO_WORD                              = 0x00;

const WORD      INDEX_ERROR_REGISTER                            = 0x2003;
const BYTE      SUBINDEX_ERROR_REGISTER                         = 0x00;

const WORD      INDEX_ERROR_HISTORY                             = 0x2004;
const BYTE      SUBINDEX_NB_OF_ERRORS                           = 0x00;
const BYTE      SUBINDEX_ERROR_HISTORY1                         = 0x01;
const BYTE      SUBINDEX_ERROR_HISTORY2                         = 0x02;
const BYTE      SUBINDEX_ERROR_HISTORY3                         = 0x03;
const BYTE      SUBINDEX_ERROR_HISTORY4                         = 0x04;

const WORD      INDEX_SAVE_RESTORE_PARAMETERS                   = 0x2005;
const BYTE      SUBINDEX_PARAMETERS_CONTROL_WORD                = 0x01;
const BYTE      SUBINDEX_PARAMETERS_ERROR_CODE                  = 0x02;

const WORD      INDEX_VERIFY_CONFIGURATION                      = 0x2006;
const BYTE      SUBINDEX_CONFIGURATION_DATE                     = 0x01;
const BYTE      SUBINDEX_CONFIGURATION_TIME                     = 0x02;

const WORD      INDEX_CURRENT_ACTUAL_VALUE                      = 0x3000;
const BYTE      SUBINDEX_CURRENT_ACTUAL_VALUE                   = 0x00;

const WORD      INDEX_CURRENT_ACTUAL_VALUE_AVERAGED             = 0x3001;
const BYTE      SUBINDEX_CURRENT_ACTUAL_VALUE_AVERAGED          = 0x00;

const WORD      INDEX_VELOCITY_ACTUAL_VALUE                     = 0x3002;
const BYTE      SUBINDEX_VELOCITY_ACTUAL_VALUE                  = 0x00;

const WORD      INDEX_VELOCITY_ACTUAL_VALUE_AVERAGED            = 0x3003;
const BYTE      SUBINDEX_VELOCITY_ACTUAL_VALUE_AVERAGED         = 0x00;

const WORD      INDEX_VOLTAGE_ACTUAL_VALUE                      = 0x3004;
const BYTE      SUBINDEX_VOLTAGE_ACTUAL_VALUE                   = 0x00;

const WORD      INDEX_VOLTAGE_ACTUAL_VALUE_AVERAGED             = 0x3005;
const BYTE      SUBINDEX_VOLTAGE_ACTUAL_VALUE_AVERAGED          = 0x00;

const WORD      INDEX_PWM_INPUT                                 = 0x3006;
const BYTE      SUBINDEX_PWM_INPUT                              = 0x00;

const WORD      INDEX_HALLSENSOR_STATUS                         = 0x3007;
const BYTE      SUBINDEX_HALLSENSOR_STATUS                      = 0x00;
const BYTE      SUBINDEX_HALLSENSOR_PATTERN                     = 0x01;
const BYTE      SUBINDEX_COMMUTATION_STEP                       = 0x02;
const BYTE      SUBINDEX_POSITION_COUNTER_HALL                  = 0x03;
const BYTE      SUBINDEX_HALL_SENSOR_ERROR_COUNTER              = 0x04;

const WORD      INDEX_POSITION_COUNTER_ENCODER                  = 0x3008;
const BYTE      SUBINDEX_POSITION_COUNTER_ENCODER               = 0x00;

const WORD      INDEX_TACHO_FEEDBACK                            = 0x3009;
const BYTE      SUBINDEX_TACHO_FEEDBACK                         = 0x00;

const WORD      INDEX_OFFSET_CURRENT                            = 0x300A;
const BYTE      SUBINDEX_OFFSET_CURRENT_PHASE_U                 = 0x01;
const BYTE      SUBINDEX_OFFSET_CURRENT_PHASE_V                 = 0x02;
const BYTE      SUBINDEX_OFFSET_CURRENT_PHASE_W                 = 0x03;

const WORD      INDEX_ANALOG_INPUTS                             = 0x3010;
const BYTE      SUBINDEX_ANALOG_INPUTS                          = 0x00;
const BYTE      SUBINDEX_ANALOG_INPUT_1                         = 0x01;
const BYTE      SUBINDEX_ANALOG_INPUT_2                         = 0x02;
const BYTE      SUBINDEX_ANALOG_INPUT_POTENTIOMETER_1           = 0x03;
const BYTE      SUBINDEX_ANALOG_INPUT_POTENTIOMETER_2           = 0x04;
const BYTE      SUBINDEX_ANALOG_INPUT_POTENTIOMETER_3           = 0x05;
const BYTE      SUBINDEX_ANALOG_INPUT_POTENTIOMETER_4           = 0x06;

const WORD      INDEX_INTERNAL_ANALOG_INPUTS                    = 0x3011;
const BYTE      SUBINDEX_TEMPERATURE_POWER_STAGE                = 0x01;
const BYTE      SUBINDEX_EXTERNAL_SUPPLY_VOLTAGE                = 0x02;

const WORD      INDEX_CURRENT_SETTING_VALUE                     = 0x3020;
const BYTE      SUBINDEX_ANALOG_CURRENT_SETPOINT                = 0x01;
const BYTE      SUBINDEX_CURRENT_DEMAND_VALUE                   = 0x02;
const BYTE      SUBINDEX_CURRENT_SET_VALUE                      = 0x03;

const WORD      INDEX_SPEED_SETTING_VALUE                       = 0x3021;
const BYTE      SUBINDEX_ANALOG_SPEED_SETPOINT                  = 0x01;
const BYTE      SUBINDEX_SPEED_DEMAND_VALUE                     = 0x02;
const BYTE      SUBINDEX_SPEED_SET_VALUE                        = 0x03;

const WORD      INDEX_VOLTAGE_SETTING_VALUE                     = 0x3022;
const BYTE      SUBINDEX_ANALOG_VOLTAGE_SETPOINT                = 0x01;
const BYTE      SUBINDEX_VOLTAGE_DEMAND_VALUE                   = 0x02;
const BYTE      SUBINDEX_VOLTAGE_SET_VALUE                      = 0x03;

const WORD      INDEX_PWM_SETTING_VALUE                         = 0x3023;
const BYTE      SUBINDEX_ANALOG_PWM_SETPOINT                    = 0x01;
const BYTE      SUBINDEX_PWM_DEMAND_VALUE                       = 0x02;
const BYTE      SUBINDEX_PWM_SET_VALUE                          = 0x03;

const WORD      INDEX_OFFSET_ADJUST_SETTING_VALUES              = 0x3025;
const BYTE      SUBINDEX_ANALOG_OFFSET_ADJUST_SETPOINT          = 0x01;
const BYTE      SUBINDEX_ADJUST_OFFSET_DEMAND_VALUE             = 0x02;

const WORD      INDEX_SPEED_RAMP_SETTING_VALUES                 = 0x3026;
const BYTE      SUBINDEX_ANALOG_SPEED_RAMP                      = 0x01;
const BYTE      SUBINDEX_ACTUAL_SPEED_RAMP_ACCELERATION         = 0x02;
const BYTE      SUBINDEX_ACTUAL_SPEED_RAMP_DECELERATION         = 0x03;

const WORD      INDEX_VOLTAGE_RAMP_SETTING_VALUES               = 0x3027;
const BYTE      SUBINDEX_ANALOG_VOLTAGE_RAMP                    = 0x01;
const BYTE      SUBINDEX_ACTUAL_VOLTAGE_RAMP_ACCELERATION       = 0x02;
const BYTE      SUBINDEX_ACTUAL_VOLTAGE_RAMP_DECELERATION       = 0x03;

const WORD      INDEX_PWM_RAMP_SETTING_VALUES                   = 0x3028;
const BYTE      SUBINDEX_ANALOG_PWM_RAMP                        = 0x01;
const BYTE      SUBINDEX_ACTUAL_PWM_RAMP_ACCELERATION           = 0x02;
const BYTE      SUBINDEX_ACTUAL_PWM_RAMP_DECELERATION           = 0x03;

const WORD      INDEX_CURRENT_P_GAIN_SETTING_VALUE              = 0x3029;
const BYTE      SUBINDEX_ANALOG_CURRENT_P_GAIN                  = 0x01;
const BYTE      SUBINDEX_ACTUAL_CURRENT_P_GAIN                  = 0x02;

const WORD      INDEX_SPEED_P_GAIN_SETTING_VALUE                = 0x3030;
const BYTE      SUBINDEX_ANALOG_SPEED_P_GAIN                    = 0x01;
const BYTE      SUBINDEX_ACTUAL_SPEED_P_GAIN                    = 0x02;

const WORD      INDEX_VOLTAGE_P_GAIN_SETTING_VALUE              = 0x3031;
const BYTE      SUBINDEX_ANALOG_VOLTAGE_P_GAIN                  = 0x01;
const BYTE      SUBINDEX_ACTUAL_VOLTAGE_P_GAIN                  = 0x02;

const WORD      INDEX_SPEED_IxR_GAIN_SETTING_VALUE              = 0x3032;
const BYTE      SUBINDEX_ANALOG_SPEED_IxR_GAIN                  = 0x01;
const BYTE      SUBINDEX_ACTUAL_SPEED_IxR_GAIN                  = 0x02;

const WORD      INDEX_VOLTAGE_IxR_GAIN_SETTING_VALUE            = 0x3033;
const BYTE      SUBINDEX_ANALOG_VOLTAGE_IxR_GAIN                = 0x01;
const BYTE      SUBINDEX_ACTUAL_VOLTAGE_IxR_GAIN                = 0x02;

const WORD      INDEX_ANALOG_OUTPUTS                            = 0x3034;
const BYTE      SUBINDEX_ANALOG_OUTPUT_1                        = 0x01;
const BYTE      SUBINDEX_ANALOG_OUTPUT_2                        = 0x02;

const WORD      INDEX_OPERATION_MODE                            = 0x4000;
const BYTE      SUBINDEX_OPERATION_MODE                         = 0x00;

const WORD      INDEX_OPERATION_MODE_DISPLAY                    = 0x4001;
const BYTE      SUBINDEX_OPERATION_MODE_DISPLAY                 = 0x00;

const WORD      INDEX_SPEED_RAMP_CONFIGURATION                  = 0x4010;
const BYTE      SUBINDEX_SPEED_RAMP_TIME_ACCELERATION           = 0x01;
const BYTE      SUBINDEX_SPEED_RAMP_TIME_DECELERATION           = 0x02;
const BYTE      SUBINDEX_SPEED_RAMP_TIME_DECELERATION_STOP      = 0x03;

const WORD      INDEX_VOLTAGE_RAMP_CONFIGURATION                = 0x4011;
const BYTE      SUBINDEX_VOLTAGE_RAMP_TIME_ACCELERATION         = 0x01;
const BYTE      SUBINDEX_VOLTAGE_RAMP_TIME_DECELERATION         = 0x02;
const BYTE      SUBINDEX_VOLTAGE_RAMP_TIME_DECELERATION_STOP    = 0x03;

const WORD      INDEX_PWM_RAMP_CONFIGURATION                    = 0x4012;
const BYTE      SUBINDEX_PWM_RAMP_TIME_ACCELERATION             = 0x01;
const BYTE      SUBINDEX_PWM_RAMP_TIME_DECELERATION             = 0x02;
const BYTE      SUBINDEX_PWM_RAMP_TIME_DECELERATION_STOP        = 0x03;

const WORD      INDEX_DIGITAL_IO_CONFIGURATION                  = 0x4020;
const BYTE      SUBINDEX_DIGITAL_IO_CONFIGURATION               = 0x00;

const WORD      INDEX_DIGITAL_INPUTS_CONFIGURATION              = 0x4021;
const BYTE      SUBINDEX_DIGITAL_INPUTS_CONFIGURATION           = 0x00;

const WORD      INDEX_DIGITAL_INPUTS_FUNCTIONALITIES                    = 0x4022;
const BYTE      SUBINDEX_DIGITAL_INPUTS_FUNCTIONALITIES_STATE           = 0x01;
const BYTE      SUBINDEX_DIGITAL_INPUTS_FUNCTIONALITIES_EXECUTION_MASK  = 0x02;

const WORD      INDEX_DIGITAL_OUTPUTS_CONFIGURATION             = 0x4023;
const BYTE      SUBINDEX_DIGITAL_OUTPUTS_CONFIGURATION          = 0x00;

const WORD      INDEX_DIGITAL_OUTPUTS_FUNCTIONALITIES_STATE     = 0x4024;
const BYTE      SUBINDEX_DIGITAL_OUTPUTS_FUNCTIONALITIES_STATE  = 0x00;

const WORD      INDEX_SPEED_COMPERATOR                          = 0x4025;
const BYTE      SUBINDEX_SPEED_COMPERATOR_LOWER_LIMIT           = 0x01;
const BYTE      SUBINDEX_SPEED_COMPERATOR_UPPER_LIMIT           = 0x02;
const BYTE      SUBINDEX_SPEED_COMPERATOR_DEVIATION             = 0x03;
const BYTE      SUBINDEX_SPEED_COMPERATOR_CONFIGURATION         = 0x04;

const WORD      INDEX_ANALOG_INPUTS_CONFIGURATION               = 0x4030;
const BYTE      SUBINDEX_ANALOG_INPUTS_CONFIGURATION            = 0x00;

const WORD      INDEX_ANALOG_INPUTS_FUNCTIONALITIES_EXECUTION_MASK      = 0x4031;
const BYTE      SUBINDEX_ANALOG_INPUTS_FUNCTIONALITIES_EXECUTION_MASK   = 0x02;

const WORD      INDEX_ANALOG_OUTPUTS_CONFIGURATION              = 0x4032;
const BYTE      SUBINDEX_ANALOG_OUTPUTS_CONFIGURATION           = 0x00;

const WORD      INDEX_ANALOG_OUTPUT_1                           = 0x4033;
const BYTE      SUBINDEX_ANALOG_OUTPUT_1_SCALING                = 0x01;
const BYTE      SUBINDEX_ANALOG_OUTPUT_1_OFFSET                 = 0x02;
const BYTE      SUBINDEX_ANALOG_OUTPUT_1_FIXED_VALUE            = 0x03;

const WORD      INDEX_ANALOG_OUTPUT_2                           = 0x4034;
const BYTE      SUBINDEX_ANALOG_OUTPUT_2_SCALING                = 0x01;
const BYTE      SUBINDEX_ANALOG_OUTPUT_2_OFFSET                 = 0x02;
const BYTE      SUBINDEX_ANALOG_OUTPUT_2_FIXED_VALUE            = 0x03;

const WORD      INDEX_SETPOINT_CURRENT                          = 0x4040;
const BYTE      SUBINDEX_SETPOINT_CURRENT_SCALING               = 0x01;
const BYTE      SUBINDEX_SETPOINT_CURRENT_OFFSET                = 0x02;
const BYTE      SUBINDEX_SETPOINT_CURRENT_FIXED_VALUE_1         = 0x03;
const BYTE      SUBINDEX_SETPOINT_CURRENT_FIXED_VALUE_2         = 0x04;

const WORD      INDEX_SETPOINT_SPEED                            = 0x4041;
const BYTE      SUBINDEX_SETPOINT_SPEED_SCALING                 = 0x01;
const BYTE      SUBINDEX_SETPOINT_SPEED_OFFSET                  = 0x02;
const BYTE      SUBINDEX_SETPOINT_SPEED_FIXED_VALUE_1           = 0x03;
const BYTE      SUBINDEX_SETPOINT_SPEED_FIXED_VALUE_2           = 0x04;

const WORD      INDEX_SETPOINT_VOLTAGE                          = 0x4042;
const BYTE      SUBINDEX_SETPOINT_VOLTAGE_SCALING               = 0x01;
const BYTE      SUBINDEX_SETPOINT_VOLTAGE_OFFSET                = 0x02;
const BYTE      SUBINDEX_SETPOINT_VOLTAGE_FIXED_VALUE_1         = 0x03;
const BYTE      SUBINDEX_SETPOINT_VOLTAGE_FIXED_VALUE_2         = 0x04;
const BYTE      SUBINDEX_SETPOINT_VOLTAGE_LIMIT                 = 0x05;

const WORD      INDEX_SETPOINT_PWM                              = 0x4043;
const BYTE      SUBINDEX_SETPOINT_PWM_SCALING                   = 0x01;
const BYTE      SUBINDEX_SETPOINT_PWM_OFFSET                    = 0x02;
const BYTE      SUBINDEX_SETPOINT_PWM_FIXED_VALUE_1             = 0x03;
const BYTE      SUBINDEX_SETPOINT_PWM_FIXED_VALUE_2             = 0x04;

const WORD      INDEX_SETPOINT_OFFSET_ADJUST                    = 0x4044;
const BYTE      SUBINDEX_SETPOINT_OFFSET_ADJUST_SCALING         = 0x01;
const BYTE      SUBINDEX_SETPOINT_OFFSET_ADJUST_FIXED_VALUE     = 0x02;

const WORD      INDEX_SPEED_RAMP                                = 0x4045;
const BYTE      SUBINDEX_SPEED_RAMP_SCALING                     = 0x01;
const BYTE      SUBINDEX_SPEED_RAMP_OFFSET                      = 0x02;

const WORD      INDEX_VOLTAGE_RAMP                              = 0x4046;
const BYTE      SUBINDEX_VOLTAGE_RAMP_SCALING                   = 0x01;
const BYTE      SUBINDEX_VOLTAGE_RAMP_OFFSET                    = 0x02;

const WORD      INDEX_PWM_RAMP                                  = 0x4047;
const BYTE      SUBINDEX_PWM_RAMP_SCALING                       = 0x01;
const BYTE      SUBINDEX_PWM_RAMP_OFFSET                        = 0x02;

const WORD      INDEX_CURRENT_P_GAIN                            = 0x4048;
const BYTE      SUBINDEX_CURRENT_P_GAIN_SCALING                 = 0x01;
const BYTE      SUBINDEX_CURRENT_P_GAIN_OFFSET                  = 0x02;

const WORD      INDEX_SPEED_P_GAIN                              = 0x4049;
const BYTE      SUBINDEX_SPEED_P_GAIN_SCALING                   = 0x01;
const BYTE      SUBINDEX_SPEED_P_GAIN_OFFSET                    = 0x02;

const WORD      INDEX_VOLTAGE_P_GAIN                            = 0x4050;
const BYTE      SUBINDEX_VOLTAGE_P_GAIN_SCALING                 = 0x01;
const BYTE      SUBINDEX_VOLTAGE_P_GAIN_OFFSET                  = 0x02;

const WORD      INDEX_SPEED_IxR_GAIN                            = 0x4051;
const BYTE      SUBINDEX_SPEED_IxR_GAIN_SCALING                 = 0x01;
const BYTE      SUBINDEX_SPEED_IxR_GAIN_OFFSET                  = 0x02;

const WORD      INDEX_VOLTAGE_IxR_GAIN                          = 0x4052;
const BYTE      SUBINDEX_VOLTAGE_IxR_GAIN_SCALING               = 0x01;
const BYTE      SUBINDEX_VOLTAGE_IxR_GAIN_OFFSET                = 0x02;

const WORD      INDEX_CURRENT_REGULATOR_PARAMETER_SET           = 0x4100;
const BYTE      SUBINDEX_CURRENT_REGULATOR_P_GAIN               = 0x01;
const BYTE      SUBINDEX_CURRENT_REGULATOR_I_GAIN               = 0x02;
const BYTE      SUBINDEX_CURRENT_REGULATOR_FR_GAIN              = 0x02;

const WORD      INDEX_SPEED_REGULATOR_PARAMETER_SET             = 0x4101;
const BYTE      SUBINDEX_SPEED_REGULATOR_P_GAIN                 = 0x01;
const BYTE      SUBINDEX_SPEED_REGULATOR_I_GAIN                 = 0x02;
const BYTE      SUBINDEX_SPEED_REGULATOR_FR_GAIN                = 0x03;
const BYTE      SUBINDEX_SPEED_REGULATOR_IxR_GAIN               = 0x04;
const BYTE      SUBINDEX_SPEED_REGULATOR_IxR_TIME_CONSTANT      = 0x05;

const WORD      INDEX_VOLTAGE_REGULATOR_PARAMETER_SET           = 0x4101;
const BYTE      SUBINDEX_VOLTAGE_REGULATOR_P_GAIN               = 0x01;
const BYTE      SUBINDEX_VOLTAGE_REGULATOR_I_GAIN               = 0x02;
const BYTE      SUBINDEX_VOLTAGE_REGULATOR_FR_GAIN              = 0x03;
const BYTE      SUBINDEX_VOLTAGE_REGULATOR_IxR_GAIN             = 0x04;
const BYTE      SUBINDEX_VOLTAGE_REGULATOR_IxR_TIME_CONSTANT    = 0x05;

const WORD      INDEX_USB_FRAME_TIMEOUT                         = 0x4400;
const BYTE      SUBINDEX_USB_FRAME_TIMEOUT                      = 0x00;

const WORD      INDEX_SENSOR_CONFIGURATION                      = 0x4600;
const BYTE      SUBINDEX_ROTOR_ANGLE_FEEDBACK_SOURCE            = 0x01;
const BYTE      SUBINDEX_SPEED_FEEDBACK_SOURCE                  = 0x02;
const BYTE      SUBINDEX_ENCODER_PULSE_NUMBER                   = 0x03;
const BYTE      SUBINDEX_TACHO_CONSTANT                         = 0x04;
const BYTE      SUBINDEX_SENSOR_POLARITY                        = 0x05;
const BYTE      SUBINDEX_HALL_SENSOR_MAXIMUM_ERROR_COUNT        = 0x06;
const BYTE      SUBINDEX_HALL_SENSOR_AVERAGING_PERIOD           = 0x07;

const WORD      INDEX_SENSORLESS_CONFIGURATION                  = 0x4601;
const BYTE      SUBINDEX_BEMF_COMPARATOR_THRESHOLD              = 0x01;
const BYTE      SUBINDEX_ZERO_CROSSING_DETECTION_FILTER         = 0x02;
const BYTE      SUBINDEX_COMMUTATION_PHASE_ADJUST_FALLING       = 0x03;
const BYTE      SUBINDEX_COMMUTATION_PHASE_ADJUST_RISING        = 0x04;
const BYTE      SUBINDEX_STARTUP_CURRENT                        = 0x05;
const BYTE      SUBINDEX_ZERO_CROSSING_FOR_SENSORLESS_START     = 0x06;
const BYTE      SUBINDEX_ALIGN_TIME                             = 0x07;
const BYTE      SUBINDEX_RAMP_STEP_TIME                         = 0x08;
const BYTE      SUBINDEX_MAXIMUM_STARTUP_TRIALS                 = 0x09;

const WORD      INDEX_MOTOR_TYPE                                = 0x4800;
const BYTE      SUBINDEX_MOTOR_TYPE                             = 0x00;

const WORD      INDEX_MOTOR_DATA                                = 0x4801;
const BYTE      SUBINDEX_CONTINOUS_CURRENT_LIMIT                = 0x01;
const BYTE      SUBINDEX_PEAK_CURRENT_LIMIT                     = 0x02;
const BYTE      SUBINDEX_POLE_PAIR_NUMBER                       = 0x03;
const BYTE      SUBINDEX_MAXIMUM_SPEED                          = 0x04;
const BYTE      SUBINDEX_THERMAL_TIME_CONSTANT_WINDING          = 0x05;
const BYTE      SUBINDEX_WINDING_RESISTANCE                     = 0x06;
const BYTE      SUBINDEX_INDUCTANCE                             = 0x07;
const BYTE      SUBINDEX_SPEED_CONSTANT                         = 0x08;
const BYTE      SUBINDEX_ROTOR_INERTIA                          = 0x09;
const BYTE      SUBINDEX_STOP_STANDSTILL_CURRENT                = 0x10;

#endif // !defined(DCS_ESCON_DEF_H__20100517__INCLUDED_)
