// Command_DCS_Ddes.h: Schnittstelle f�r die Klasse CCommand_DCS_Ddes.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_Command_DCS_Ddes_H__9B23BC0A_DD33_499E_B6F6_116AF15BE465__INCLUDED_)
#define AFX_Command_DCS_Ddes_H__9B23BC0A_DD33_499E_B6F6_116AF15BE465__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <CommunicationModel/CommonLayer/Classes/Commands/DeviceCommandSet/BaseClasses/Command_DCS.h>

class CCommand_DCS_Ddes : public CCommand_DCS
{
public:
	CCommand_DCS_Ddes();
	CCommand_DCS_Ddes(DWORD dCommandId);
	virtual ~CCommand_DCS_Ddes();

	BOOL InitCommand(DWORD dCommandId);

	CCommand_DCS_Ddes& operator=(CCommand_DCS_Ddes& other);
	CCommandRoot* CloneCommand();

private:
	BOOL InitCommand_ObjectDictionary(DWORD dCommandId);

	//ObjectDictionary
	void SetDefaultParameter_WriteObject();
	void SetDefaultParameter_InitiateSegmentedWrite();
	void SetDefaultParameter_SegmentedWrite();
	void SetDefaultParameter_ReadObject();
	void SetDefaultParameter_InitiateSegmentedRead();
	void SetDefaultParameter_SegmentedRead();
	void SetDefaultParameter_AbortSegmentedTransfer();
};

#endif // !defined(AFX_Command_DCS_Ddes_H__9B23BC0A_DD33_499E_B6F6_116AF15BE465__INCLUDED_)
