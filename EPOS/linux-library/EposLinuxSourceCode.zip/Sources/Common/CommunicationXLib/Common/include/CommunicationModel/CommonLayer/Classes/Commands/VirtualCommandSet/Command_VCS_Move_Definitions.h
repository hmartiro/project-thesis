/***************************************************************************

    HEADER FILE:    Command_VCS_Move_Definitions.h

****************************************************************************

    COPYRIGHT (C)   2010 maxon motor control

    Written by:     Roland Odermatt
    System:         Visual C++
    File:           Command_VCS_Move_Definitions.h
    Date:           25.08.2010

****************************************************************************

    Task:

***************************************************************************/

#if !defined(Command_VCS_Move_Definitions_25082010)
#define Command_VCS_Move_Definitions_25082010

//Command Ids
//Configuration
    //Velocity Regulator
    const DWORD    MOVE_SET_SPEED_REGULATOR_GAIN                    = 0x00200010;
    const DWORD    MOVE_GET_SPEED_REGULATOR_GAIN                    = 0x00200011;

    //Current Regulator
    const DWORD    MOVE_SET_CURRENT_REGULATOR_GAIN                 = 0x00200015;
    const DWORD    MOVE_GET_CURRENT_REGULATOR_GAIN                 = 0x00200016;

    //Safety
    const DWORD    MOVE_SET_MAX_FOLLOWING_ERROR                    = 0x00200020;
    const DWORD    MOVE_GET_MAX_FOLLOWING_ERROR                    = 0x00200021;
    const DWORD    MOVE_SET_MAX_PROFILE_VELOCITY                   = 0x00200022;
    const DWORD    MOVE_GET_MAX_PROFILE_VELOCITY                   = 0x00200023;
    const DWORD    MOVE_SET_MAX_ACCELERATION                       = 0x00200024;
    const DWORD    MOVE_GET_MAX_ACCELERATION                       = 0x00200025;

    //Units
    const DWORD    MOVE_SET_VELOCITY_UNITS                         = 0x00200028;
    const DWORD    MOVE_GET_VELOCITY_UNITS                         = 0x00200029;

    //Motor
    const DWORD    MOVE_GET_MOTOR_PARAMETER                        = 0x00200030;
    const DWORD    MOVE_SET_MOTOR_PARAMETER                        = 0x00200031;
    const DWORD    MOVE_SET_MOTOR_TYPE                             = 0x00200032;
    const DWORD    MOVE_GET_MOTOR_TYPE                             = 0x00200033;
    const DWORD    MOVE_SET_DC_MOTOR_PARAMETER                     = 0x00200034;
    const DWORD    MOVE_GET_DC_MOTOR_PARAMETER                     = 0x00200035;
    const DWORD    MOVE_SET_EC_MOTOR_PARAMETER                     = 0x00200036;
    const DWORD    MOVE_GET_EC_MOTOR_PARAMETER                     = 0x00200037;

    //Sensor
    const DWORD    MOVE_SET_ENCODER_PARAMETER                      = 0x00200040;
    const DWORD    MOVE_GET_ENCODER_PARAMETER                      = 0x00200041;
    const DWORD    MOVE_SET_SENSOR_TYPE                            = 0x00200042;
    const DWORD    MOVE_GET_SENSOR_TYPE                            = 0x00200043;
    const DWORD    MOVE_SET_INC_ENCODER_PARAMETER                  = 0x00200044;
    const DWORD    MOVE_GET_INC_ENCODER_PARAMETER                  = 0x00200045;
    const DWORD    MOVE_SET_HALL_SENSOR_PARAMETER                  = 0x00200046;
    const DWORD    MOVE_GET_HALL_SENSOR_PARAMETER                  = 0x00200047;
    const DWORD    MOVE_SET_SSI_ABS_ENCODER_PARAMETER              = 0x00200048;
    const DWORD    MOVE_GET_SSI_ABS_ENCODER_PARAMETER              = 0x00200049;

//CurrentMode
    const DWORD    MOVE_GET_CURRENT_MUST                           = 0x00200050;
    const DWORD    MOVE_SET_CURRENT_MUST                           = 0x00200051;
    const DWORD    MOVE_ACTIVATE_ANALOG_CURRENT_SETPOINT           = 0x00200052;
    const DWORD    MOVE_DEACTIVATE_ANALOG_CURRENT_SETPOINT         = 0x00200053;
    const DWORD    MOVE_ENABLE_ANALOG_CURRENT_SETPOINT             = 0x00200054;
    const DWORD    MOVE_DISABLE_ANALOG_CURRENT_SETPOINT            = 0x00200055;

//MotionInfo
    const DWORD    MOVE_GET_CURRENT_IS                             = 0x00200100;
    const DWORD    MOVE_GET_MOVEMENT_STATE                         = 0x00200101;
    const DWORD    MOVE_GET_POSITION_IS                            = 0x00200102;
    const DWORD    MOVE_GET_VELOCITY_IS                            = 0x00200103;

//PositionMode
    const DWORD    MOVE_GET_POSITION_MUST                          = 0x00200110;
    const DWORD    MOVE_SET_POSITION_MUST                          = 0x00200111;
    const DWORD    MOVE_ACTIVATE_ANALOG_POSITION_SETPOINT          = 0x00200112;
    const DWORD    MOVE_DEACTIVATE_ANALOG_POSITION_SETPOINT        = 0x00200113;
    const DWORD    MOVE_ENABLE_ANALOG_POSITION_SETPOINT            = 0x00200114;
    const DWORD    MOVE_DISABLE_ANALOG_POSITION_SETPOINT           = 0x00200115;

//StateMachine
    const DWORD    MOVE_CLEAR_FAULT                                = 0x00200170;
    const DWORD    MOVE_GET_DISABLE_STATE                          = 0x00200171;
    const DWORD    MOVE_GET_ENABLE_STATE                           = 0x00200172;
    const DWORD    MOVE_GET_FAULT_STATE                            = 0x00200173;
    const DWORD    MOVE_GET_OPERATION_MODE                         = 0x00200174;
    const DWORD    MOVE_GET_QUICK_STOP_STATE                       = 0x00200175;
    const DWORD    MOVE_SET_DISABLE_STATE                          = 0x00200176;
    const DWORD    MOVE_SET_ENABLE_STATE                           = 0x00200177;
    const DWORD    MOVE_SET_OPERATION_MODE                         = 0x00200178;
    const DWORD    MOVE_SET_QUICK_STOP_STATE                       = 0x00200179;

//VelocityMode
    const DWORD    MOVE_GET_VELOCITY_MUST                          = 0x00200200;
    const DWORD    MOVE_SET_VELOCITY_MUST                          = 0x00200201;
    const DWORD    MOVE_ACTIVATE_ANALOG_VELOCITY_SETPOINT          = 0x00200202;
    const DWORD    MOVE_DEACTIVATE_ANALOG_VELOCITY_SETPOINT        = 0x00200203;
    const DWORD    MOVE_ENABLE_ANALOG_VELOCITY_SETPOINT            = 0x00200204;
    const DWORD    MOVE_DISABLE_ANALOG_VELOCITY_SETPOINT           = 0x00200205;

//FirmwareDownload
    const DWORD    MOVE_GET_BASE_SECTOR_VERSION                    = 0x00200220;
    const DWORD    MOVE_GET_SERIAL_NUMBER                          = 0x00200221;


#endif    //Command_VCS_Move_Definitions_25082010

