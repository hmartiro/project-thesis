// Command_DCS_Escon.h: Schnittstelle f�r die Klasse CCommand_DCS_Escon.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include <CommunicationModel/Common/CommunicationModelDefinitions.h>
#ifdef _MMC_DCS_ESCON

#include <CommunicationModel/CommonLayer/Classes/Commands/DeviceCommandSet/BaseClasses/Command_DCS.h>

class CCommand_DCS_Escon : public CCommand_DCS
{
public:
    CCommand_DCS_Escon();
    CCommand_DCS_Escon(DWORD dCommandId);
    virtual ~CCommand_DCS_Escon();

    BOOL InitCommand(DWORD dCommandId);

    CCommand_DCS_Escon& operator=(CCommand_DCS_Escon& other);
    CCommandRoot* CloneCommand();

private:
    BOOL InitCommand_ObjectDictionary(DWORD dCommandId);

    //ObjectDictionary
    void SetDefaultParameter_WriteObject();
    void SetDefaultParameter_InitiateSegmentedWrite();
    void SetDefaultParameter_SegmentedWrite();
    void SetDefaultParameter_ReadObject();
    void SetDefaultParameter_InitiateSegmentedRead();
    void SetDefaultParameter_SegmentedRead();
    void SetDefaultParameter_AbortSegmentedTransfer();
};
#endif //_MMC_DCS_ESCON
