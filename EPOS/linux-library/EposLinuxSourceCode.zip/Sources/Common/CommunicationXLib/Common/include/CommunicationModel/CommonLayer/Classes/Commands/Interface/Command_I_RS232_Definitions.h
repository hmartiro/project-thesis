/***************************************************************************

	HEADER FILE:		Command_I_RS232_Definitions.h

/***************************************************************************

	COPYRIGHT (C)	2005 maxon motor control

	Written by:			Odermatt Roland
	System:				Visual C++
	File:				Command_I_RS232_Definitions.h
	Date:				28.10.2005

****************************************************************************

	Task:

***************************************************************************/

#if !defined(Command_I_RS232_Definitions_28102005)
#define Command_I_RS232_Definitions_28102005

const DWORD RS232_WRITE_DATA			= 0x00000001;
const DWORD RS232_READ_DATA				= 0x00000002;

#endif	//Command_I_RS232_Definitions_28102005

