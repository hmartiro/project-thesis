// ErrorHandling.h: Schnittstelle f�r die Klasse CErrorHandling.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ERRORHANDLING_H__35065F20_2D36_4682_A442_3E76A0DD00E2__INCLUDED_)
#define AFX_ERRORHANDLING_H__35065F20_2D36_4682_A442_3E76A0DD00E2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ErrorInfo.h"
#include "Error.h"
#include "ErrorProducer.h"
#include "ErrorCode_Definitions.h"

class CErrorHandling
{
public:
	CErrorHandling();
	virtual ~CErrorHandling();

	static BOOL GetErrorDescription(DWORD dErrorCode, CStdString* pDescription);
	void GetError(DWORD dErrorCode, CErrorInfo* pErrorInfo);
	void InitErrorProducer(CErrorProducer* pErrorProducer);
	BOOL GetErrorProducerInfos(ELayer& p_rLayer, CStdString& p_rClassName, CStdString& p_rCommandName);

private:
	void DeleteErrorProducer();

	//General
	static BOOL GetErrorDescription_GeneralError(DWORD dErrorCode, CStdString *pDescription);

	//InterfaceLayer
	static BOOL GetErrorDescription_I(DWORD dErrorCode, CStdString *pDescription);
	static BOOL GetErrorDescription_I_RS232(DWORD dErrorCode, CStdString *pDescription);
	static BOOL GetErrorDescription_I_USB(DWORD dErrorCode, CStdString *pDescription);
	static BOOL GetErrorDescription_I_CAN(DWORD dErrorCode, CStdString *pDescription);

	//ProtocolStackLayer
	static BOOL GetErrorDescription_PS(DWORD dErrorCode, CStdString *pDescription);
	static BOOL GetErrorDescription_PS_MaxonSerialV1(DWORD dErrorCode, CStdString *pDescription);
	static BOOL GetErrorDescription_PS_InfoteamSerial(DWORD dErrorCode, CStdString *pDescription);
	static BOOL GetErrorDescription_PS_CANopen(DWORD dErrorCode, CStdString *pDescription);
	static BOOL GetErrorDescription_PS_MaxonSerialV2(DWORD dErrorCode, CStdString *pDescription);

	//DeviceCommandSetLayer
	static BOOL GetErrorDescription_DCS(DWORD dErrorCode, CStdString *pDescription);
	static BOOL GetErrorDescription_DCS_DeviceEpos(DWORD dErrorCode, CStdString *pDescription);
	static BOOL GetErrorDescription_DCS_OldDeviceEpos(DWORD dErrorCode, CStdString *pDescription);

	//VirtualDeviceLayer
	static BOOL GetErrorDescription_VCS(DWORD dErrorCode, CStdString *pDescription);
	static BOOL GetErrorDescription_VCS_VirtualDevice(DWORD dErrorCode, CStdString *pDescription);

private:
	CErrorProducer* m_pErrorProducer;
};

#endif // !defined(AFX_ERRORHANDLING_H__35065F20_2D36_4682_A442_3E76A0DD00E2__INCLUDED_)


