#pragma once

#include <MmcDefinitions.h>
#ifdef _MMC_I_HID

#include "../../../Ports/BaseClasses/PortBase.h"
#include <Thread/MmcCriticalSection.h>
#include <Storage/MmcUserSettings.h>

class CHidDeviceInfo;

typedef std::list<CHidDeviceInfo*> tHidDeviceInfoList;

class CHidDeviceInfoHandling
{
public:
    CHidDeviceInfoHandling(void);
    ~CHidDeviceInfoHandling(void);
    CHidDeviceInfoHandling& operator=(CHidDeviceInfoHandling& other);
    BOOL CopyDeviceInfos(CHidDeviceInfoHandling* pOther);

    //Singleton
    static CMmcCriticalSection* GetSyncInstance();

    //DeviceInfos
    BOOL InitDeviceInfos(tHidDeviceInfoList& p_rDeviceInfoList);
    BOOL UpdateDeviceInfos(tHidDeviceInfoList& p_rDeviceInfoList, tPortList& p_rOpenPortList);
    BOOL UpdatePortLocked(CStdString p_PortName, BOOL p_oLocked);
    BOOL GetPortNames(CStdStringArray& p_rPortNames);
    BOOL GetLocationId(CStdString p_PortName, CStdString& p_rDevicePath, DWORD& p_rulLocationId);
    BOOL UpdateLocationId(tHidDeviceInfoList& p_rDeviceInfoList, CStdString p_PortName);

    //Persistence
    BOOL DeleteFromRegistry();
    BOOL WriteToRegistry();
    BOOL ReadFromRegistry();
    BOOL UpdateRegistry(CStdString p_PortName, BOOL p_oLocked);

private:
    //Initialisation
    BOOL CreateRegistrySemaphore();
    BOOL DeleteRegistrySemaphore();

    //Update Devices
    BOOL UpdateRemovedDevices(tHidDeviceInfoList& p_rDeviceInfoList, tPortList& p_rOpenPortList);
    BOOL UpdateAddedDevices(tHidDeviceInfoList& p_rDeviceInfoList, tPortList& p_rOpenPortList);

    //DeviceInfos
    BOOL AddDeviceInfo(CStdString p_PortName, CStdString p_DevicePath, DWORD p_ulLocationId, CStdString p_SerialNumber);
    BOOL DeleteFromDeviceInfoList(CHidDeviceInfo& p_rDeviceInfo);

    //Port
    BOOL IsPortOpen(CHidDeviceInfo& p_rDeviceInfo, tPortList& p_rOpenPortList);
    BOOL IsPortLocked(CHidDeviceInfo& p_rDeviceInfo, CHidDeviceInfo*& p_rpLockedDeviceInfo);
    BOOL IsPortNameUsed(CStdString p_PortName, tHidDeviceInfoList& p_rDeviceInfoList);
    BOOL ReopenPort(CStdString p_PortName, tPortList& p_rOpenPortList);
    BOOL GetNextFreePortName(CStdString& p_rPortName);

    //List Handling
    BOOL IsPortExistingInList(CHidDeviceInfo& p_rDeviceInfo, tHidDeviceInfoList& p_rDeviceInfoList, CHidDeviceInfo*& p_rpExistingDeviceInfo);
    BOOL AddToDeviceInfoList(CHidDeviceInfo& p_rDeviceInfo);
    BOOL DeleteDeviceInfoList(tHidDeviceInfoList& p_rDeviceInfoList);
    BOOL CopyDeviceInfoList(tHidDeviceInfoList& p_rSourceDeviceInfoList, tHidDeviceInfoList& p_rTargetDeviceInfoList);
    BOOL SortPortNames(CStdStringArray& p_rPortNames);
    BOOL SortDeviceInfoListByPortName(tHidDeviceInfoList& p_rDeviceInfoList);
    BOOL SortDeviceInfoListByLocationId(tHidDeviceInfoList& p_rDeviceInfoList);
    BOOL FindDeviceInfo(CHidDeviceInfo& p_rDeviceInfo, tHidDeviceInfoList& p_rDeviceInfoList, int& p_rIndexFound);
    BOOL FindDeviceInfoByLocationId(CHidDeviceInfo& p_rDeviceInfo, tHidDeviceInfoList& p_rDeviceInfoList, int& p_rIndexFound);
    BOOL FindDeviceInfoByLocationId(CHidDeviceInfo& p_rDeviceInfo, tHidDeviceInfoList& p_rDeviceInfoList, CHidDeviceInfo*& p_rpFoundDeviceInfo);
    BOOL FindDeviceInfoBySerialNumber(CHidDeviceInfo& p_rDeviceInfo, tHidDeviceInfoList& p_rDeviceInfoList, int& p_rIndexFound);
    BOOL FindDeviceInfoBySerialNumber(CHidDeviceInfo& p_rDeviceInfo, tHidDeviceInfoList& p_rDeviceInfoList, CHidDeviceInfo*& p_rpFoundDeviceInfo);
    BOOL FindDeviceInfoByPortName(CStdString p_PortName, tHidDeviceInfoList& p_rDeviceInfoList, CHidDeviceInfo*& p_rpDeviceInfo);
    BOOL ResetDeviceInfoList();
    BOOL ResetLockedDeviceInfoList();

    //Registry
    BOOL ReadDeviceInfoFromRegistry(CMmcUserSettings* p_hKey, CHidDeviceInfo* p_pDeviceInfo, BOOL& p_roLocked);
    BOOL WriteDeviceInfoToRegistry(CMmcUserSettings* p_hKey, CStdString p_ValueName, CHidDeviceInfo* p_pDeviceInfo, BOOL p_oLocked);
    BOOL WriteLockedToRegistry(CMmcUserSettings* p_hKey, BOOL p_oLocked);
    BOOL DeleteTreeFromRegistry(CMmcUserSettings* p_hKey, CStdString p_SubKey);

	BOOL GetRegistryKey(CStdString& p_rRegistryKey);
	BOOL GetModuleVersion(CStdString& p_rVersion);
	BOOL GetApplicationInfo(CStdString& p_rApplicationName, CStdString& p_rVersion);
	CStdString ExtractApplicationName(CStdString p_FileName);

private:
    //Singleton
    static CMmcCriticalSection m_CriticalSection;
    CMmcSemaphore* m_pRegistrySemaphore;

    //DeviceInfo
    tHidDeviceInfoList m_DeviceInfoList;
    tHidDeviceInfoList m_LockedDeviceInfoList;
};
#endif //_MMC_I_HID
