// CANopenFrame.cpp: Implementierung der Klasse CCANopenFrame.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <malloc.h>
#include <memory.h>
#include "CANopenFrame.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

CCANopenFrame::CCANopenFrame()
{
	m_FrameBufferSize = sizeof(m_FrameBuffer);
	memset(&m_FrameBuffer,0,sizeof(m_FrameBuffer));
}

CCANopenFrame::~CCANopenFrame()
{
}

void CCANopenFrame::ResetFrame()
{
	memset(&m_FrameBuffer,0,sizeof(m_FrameBuffer));
	m_FrameBufferSize = sizeof(m_FrameBuffer);
}

void* CCANopenFrame::GetCobIdPointer()
{
	return (void*)&m_FrameBuffer.dId;
}

DWORD CCANopenFrame::GetCobIdSize()
{
	return (DWORD)sizeof(m_FrameBuffer.dId);
}

void* CCANopenFrame::GetRtrPointer()
{
	return (void*)&m_FrameBuffer.oRtr;
}

DWORD CCANopenFrame::GetRtrSize()
{
	return (DWORD)sizeof(m_FrameBuffer.oRtr);
}

void* CCANopenFrame::GetDlcPointer()
{
	return (void*)&m_FrameBuffer.wDlc;
}

DWORD CCANopenFrame::GetDlcSize()
{
	return (DWORD)sizeof(m_FrameBuffer.wDlc);
}

void* CCANopenFrame::GetCanDataPointer()
{
	return (void*)&m_FrameBuffer.nCanData;
}

DWORD CCANopenFrame::GetCanDataSize()
{
	return (DWORD)sizeof(m_FrameBuffer.nCanData);
}

BOOL CCANopenFrame::PrepareSendFrame_InitiateSDODownload(DWORD dCobId,BOOL oExpeditedTransfer,BOOL oSizeIndicated,BYTE uNonValidNbOfBytes,WORD wIndex,BYTE uSubIndex,void* pDataBuffer,DWORD dDataBufferLength)
{
	const int k_FrameSize = 8;
	const int k_CommandSpecifier = 1;
	const unsigned long k_MaxDataSize = 4;

	ResetFrame();
	if(pDataBuffer)
	{
		//Limit Values
		if(dDataBufferLength > k_MaxDataSize) dDataBufferLength = k_MaxDataSize;
		if(uNonValidNbOfBytes > k_MaxDataSize) uNonValidNbOfBytes = k_MaxDataSize;
		if(!oExpeditedTransfer || !oSizeIndicated) uNonValidNbOfBytes = 0;

		//Frame
		m_FrameBuffer.dId = dCobId;
		m_FrameBuffer.oRtr = FALSE;
		m_FrameBuffer.wDlc = k_FrameSize;

		m_FrameBuffer.nCanData.sInitiateSDODownload_SendFrame.ccs = k_CommandSpecifier;
		m_FrameBuffer.nCanData.sInitiateSDODownload_SendFrame.n = uNonValidNbOfBytes;
		m_FrameBuffer.nCanData.sInitiateSDODownload_SendFrame.e = oExpeditedTransfer;
		m_FrameBuffer.nCanData.sInitiateSDODownload_SendFrame.s = oSizeIndicated;
		m_FrameBuffer.nCanData.sInitiateSDODownload_SendFrame.index = wIndex;
		m_FrameBuffer.nCanData.sInitiateSDODownload_SendFrame.subIndex = uSubIndex;
		memcpy(m_FrameBuffer.nCanData.sInitiateSDODownload_SendFrame.data,pDataBuffer,dDataBufferLength);

		return TRUE;
	}

	return FALSE;
}

BOOL CCANopenFrame::PrepareSendFrame_AbortSDOTransfer(DWORD dCobId,WORD wIndex,BYTE uSubIndex,DWORD dAbortCode)
{
	const int k_FrameSize = 8;
	const int k_CommandSpecifier = 4;

	ResetFrame();

	//Frame
	m_FrameBuffer.dId = dCobId;
	m_FrameBuffer.oRtr = FALSE;
	m_FrameBuffer.wDlc = k_FrameSize;

	m_FrameBuffer.nCanData.sAbortTransfer_AbortFrame.cs = k_CommandSpecifier;
	m_FrameBuffer.nCanData.sAbortTransfer_AbortFrame.index = wIndex;
	m_FrameBuffer.nCanData.sAbortTransfer_AbortFrame.subIndex = uSubIndex;
	m_FrameBuffer.nCanData.sAbortTransfer_AbortFrame.abortCode = dAbortCode;

	return TRUE;
}

BOOL CCANopenFrame::PrepareSendFrame_DownloadSDOSegment(DWORD dCobId,BOOL oToggle,BYTE uNonValidNbOfBytes,BOOL oNoMoreSegments,void* pSegDataBuffer,DWORD dSegDataBufferLength)
{
	const int k_FrameSize = 8;
	const int k_CommandSpecifier = 0;
	const unsigned long k_MaxDataSize = 7;

	ResetFrame();
	if(pSegDataBuffer)
	{
		//Limit Values
		if(dSegDataBufferLength > k_MaxDataSize) dSegDataBufferLength = k_MaxDataSize;
		if(uNonValidNbOfBytes > k_MaxDataSize) uNonValidNbOfBytes = k_MaxDataSize;

		//Frame
		m_FrameBuffer.dId = dCobId;
		m_FrameBuffer.oRtr = FALSE;
		m_FrameBuffer.wDlc = k_FrameSize;

		m_FrameBuffer.nCanData.sDownloadSDOSegment_SendFrame.ccs = k_CommandSpecifier;
		m_FrameBuffer.nCanData.sDownloadSDOSegment_SendFrame.n = uNonValidNbOfBytes;
		m_FrameBuffer.nCanData.sDownloadSDOSegment_SendFrame.c = oNoMoreSegments;
		m_FrameBuffer.nCanData.sDownloadSDOSegment_SendFrame.t = oToggle;
		memcpy(m_FrameBuffer.nCanData.sDownloadSDOSegment_SendFrame.data,pSegDataBuffer,dSegDataBufferLength);

		return TRUE;
	}

	return FALSE;
}

BOOL CCANopenFrame::PrepareSendFrame_InitiateSDOUpload(DWORD dCobId,WORD wIndex,BYTE uSubIndex)
{
	const int k_FrameSize = 8;
	const int k_CommandSpecifier = 2;

	ResetFrame();

	//Frame
	m_FrameBuffer.dId = dCobId;
	m_FrameBuffer.oRtr = FALSE;
	m_FrameBuffer.wDlc = k_FrameSize;

	m_FrameBuffer.nCanData.sInitiateSDOUpload_SendFrame.ccs = k_CommandSpecifier;
	m_FrameBuffer.nCanData.sInitiateSDOUpload_SendFrame.index = wIndex;
	m_FrameBuffer.nCanData.sInitiateSDOUpload_SendFrame.subIndex = uSubIndex;
	return TRUE;
}

BOOL CCANopenFrame::PrepareSendFrame_UploadSDOSegment(DWORD dCobId,BOOL oToggle)
{
	const int k_FrameSize = 8;
	const int k_CommandSpecifier = 3;

	ResetFrame();

	//Frame
	m_FrameBuffer.dId = dCobId;
	m_FrameBuffer.oRtr = FALSE;
	m_FrameBuffer.wDlc = k_FrameSize;

	m_FrameBuffer.nCanData.sUploadSDOSegment_SendFrame.ccs = k_CommandSpecifier;
	m_FrameBuffer.nCanData.sUploadSDOSegment_SendFrame.t = oToggle;

	return TRUE;
}

BOOL CCANopenFrame::PrepareSendFrame_NetworkIndication(DWORD dCobId,WORD wTargetNetworkId,BYTE uTargetNodeId)
{
	const int k_FrameSize = 8;
	const int k_CommandSpecifier = 7;

	ResetFrame();

	//Frame
	m_FrameBuffer.dId = dCobId;
	m_FrameBuffer.oRtr = FALSE;
	m_FrameBuffer.wDlc = k_FrameSize;

	m_FrameBuffer.nCanData.sNetworkIndication_SendFrame.ccs = k_CommandSpecifier;
	m_FrameBuffer.nCanData.sNetworkIndication_SendFrame.r = 0;
	m_FrameBuffer.nCanData.sNetworkIndication_SendFrame.m1 = wTargetNetworkId;
	m_FrameBuffer.nCanData.sNetworkIndication_SendFrame.m2 = uTargetNodeId;
	m_FrameBuffer.nCanData.sNetworkIndication_SendFrame.reserved[0] = 0;
	m_FrameBuffer.nCanData.sNetworkIndication_SendFrame.reserved[1] = 0;
	m_FrameBuffer.nCanData.sNetworkIndication_SendFrame.reserved[2] = 0;
	m_FrameBuffer.nCanData.sNetworkIndication_SendFrame.reserved[3] = 0;

	return TRUE;
}

BOOL CCANopenFrame::PrepareSendFrame_SendNMTService(BYTE uCommandSpecifier,BYTE uNodeId)
{
	const int k_CobId = 0;
	const int k_FrameSize = 2;

	ResetFrame();

	//Frame
	m_FrameBuffer.dId = k_CobId;
	m_FrameBuffer.oRtr = FALSE;
	m_FrameBuffer.wDlc = k_FrameSize;

	m_FrameBuffer.nCanData.aDataByte[0] = uCommandSpecifier;
	m_FrameBuffer.nCanData.aDataByte[1] = uNodeId;

	return TRUE;
}

BOOL CCANopenFrame::PrepareSendFrame_SendCANFrame(DWORD dCobId,BYTE uLength,void* pDataBuffer,DWORD dDataBufferLength)
{
	const unsigned long k_MaxFrameSize = 8;

	ResetFrame();
	if(pDataBuffer)
	{
		//Limit Values
		if(dDataBufferLength > k_MaxFrameSize) dDataBufferLength = k_MaxFrameSize;

		//Frame
		m_FrameBuffer.dId = dCobId;
		m_FrameBuffer.oRtr = FALSE;
		m_FrameBuffer.wDlc = (WORD)dDataBufferLength;
		memcpy(m_FrameBuffer.nCanData.aDataByte,pDataBuffer,dDataBufferLength);

		return TRUE;
	}

	return FALSE;
}

BOOL CCANopenFrame::PrepareSendFrame_RequestCANFrame(DWORD dCobId,BYTE uLength)
{
	const int k_MaxFrameSize = 8;

	ResetFrame();

	//Limit Values
	if(uLength > k_MaxFrameSize) uLength = k_MaxFrameSize;

	//Frame
	m_FrameBuffer.dId = dCobId;
	m_FrameBuffer.oRtr = TRUE;
	m_FrameBuffer.wDlc = uLength;

	return TRUE;
}

BOOL CCANopenFrame::CopyReceivedData_InitiateSDODownload(DWORD* pdCobId,WORD* pwIndex,BYTE* puSubIndex,DWORD* pdAbortCode)
{
	const int k_CommandSpecifier = 3;
	const int k_AbortCommandSpecifier = 4;

	if(pdCobId && pwIndex && puSubIndex && pdAbortCode)
	{
		if(m_FrameBuffer.nCanData.sInitiateSDODownload_ReceiveFrame.scs == k_CommandSpecifier)
		{
			*pdCobId = m_FrameBuffer.dId;
			*pwIndex = m_FrameBuffer.nCanData.sInitiateSDODownload_ReceiveFrame.index;
			*puSubIndex = m_FrameBuffer.nCanData.sInitiateSDODownload_ReceiveFrame.subIndex;
			*pdAbortCode = 0;

			return TRUE;
		}
		else if(m_FrameBuffer.nCanData.sAbortTransfer_AbortFrame.cs == k_AbortCommandSpecifier)
		{
			*pdCobId = m_FrameBuffer.dId;
			*pwIndex = m_FrameBuffer.nCanData.sAbortTransfer_AbortFrame.index;
			*puSubIndex = m_FrameBuffer.nCanData.sAbortTransfer_AbortFrame.subIndex;
			*pdAbortCode = m_FrameBuffer.nCanData.sAbortTransfer_AbortFrame.abortCode;

			return TRUE;
		}
	}

	return FALSE;
}

BOOL CCANopenFrame::CopyReceivedData_DownloadSDOSegment(DWORD* pdCobId,BOOL* poToggle,DWORD* pdAbortCode)
{
	const int k_CommandSpecifier = 1;
	const int k_AbortCommandSpecifier = 4;

	if(pdCobId && poToggle && pdAbortCode)
	{
		if(m_FrameBuffer.nCanData.sDownloadSDOSegment_ReceiveFrame.scs == k_CommandSpecifier)
		{
			*pdCobId = m_FrameBuffer.dId;
			*poToggle = m_FrameBuffer.nCanData.sDownloadSDOSegment_ReceiveFrame.t;
			*pdAbortCode = 0;

			return TRUE;
		}
		else if(m_FrameBuffer.nCanData.sAbortTransfer_AbortFrame.cs == k_AbortCommandSpecifier)
		{
			*pdCobId = m_FrameBuffer.dId;
			*pdAbortCode = m_FrameBuffer.nCanData.sAbortTransfer_AbortFrame.abortCode;

			return TRUE;
		}
	}

	return FALSE;
}

BOOL CCANopenFrame::CopyReceivedData_InitiateSDOUpload(DWORD* pdCobId,BOOL* poExpeditedTransfer,BOOL* poSizeIndicated,BYTE* puNonValidNbOfBytes,WORD* pwIndex,BYTE* puSubIndex,void** ppDataBuffer,DWORD* pdDataBufferLength,DWORD* pdAbortCode)
{
	const int k_DataSize = 4;
	const int k_CommandSpecifier = 2;
	const int k_AbortCommandSpecifier = 4;

	if(pdCobId && poExpeditedTransfer && poSizeIndicated && puNonValidNbOfBytes && pwIndex && puSubIndex && ppDataBuffer && pdDataBufferLength && pdAbortCode)
	{
		if(m_FrameBuffer.nCanData.sInitiateSDOUpload_ReceiveFrame.scs == k_CommandSpecifier)
		{
			//Prepare DataBuffer
			*pdCobId = m_FrameBuffer.dId;
			*poExpeditedTransfer = m_FrameBuffer.nCanData.sInitiateSDOUpload_ReceiveFrame.e;
			*poSizeIndicated = m_FrameBuffer.nCanData.sInitiateSDOUpload_ReceiveFrame.s;
			*puNonValidNbOfBytes = m_FrameBuffer.nCanData.sInitiateSDOUpload_ReceiveFrame.n;
			*pwIndex = m_FrameBuffer.nCanData.sInitiateSDOUpload_ReceiveFrame.index;
			*puSubIndex = m_FrameBuffer.nCanData.sInitiateSDOUpload_ReceiveFrame.subIndex;

			*pdDataBufferLength = k_DataSize;
			*ppDataBuffer = malloc(*pdDataBufferLength);
			memcpy(*ppDataBuffer,m_FrameBuffer.nCanData.sInitiateSDOUpload_ReceiveFrame.data,*pdDataBufferLength);

			*pdAbortCode = 0;

			return TRUE;
		}
		else if(m_FrameBuffer.nCanData.sAbortTransfer_AbortFrame.cs == k_AbortCommandSpecifier)
		{
			*pdCobId = m_FrameBuffer.dId;
			*poExpeditedTransfer = FALSE;
			*poSizeIndicated = FALSE;
			*puNonValidNbOfBytes = 0;
			*pwIndex = 0;
			*puSubIndex = 0;

			*pdDataBufferLength = k_DataSize;
			*ppDataBuffer = malloc(*pdDataBufferLength);
			memset(*ppDataBuffer,0,*pdDataBufferLength);

			*pdAbortCode = m_FrameBuffer.nCanData.sAbortTransfer_AbortFrame.abortCode;

			return TRUE;
		}
	}

	return FALSE;
}

BOOL CCANopenFrame::CopyReceivedData_UploadSDOSegment(DWORD* pdCobId,BOOL* poToggle,BYTE* puNonValidNbOfBytes,BOOL* poNoMoreSegments,void** ppSegDataBuffer,DWORD* pdSegDataBufferLength,DWORD* pdAbortCode)
{
	const int k_DataSize = 7;
	const int k_CommandSpecifier = 0;
	const int k_AbortCommandSpecifier = 4;

	if(pdCobId && poToggle && puNonValidNbOfBytes && poNoMoreSegments && ppSegDataBuffer && pdSegDataBufferLength && pdAbortCode)
	{
		if(m_FrameBuffer.nCanData.sUploadSDOSegment_ReceiveFrame.scs == k_CommandSpecifier)
		{
			//Prepare DataBuffer
			*pdCobId = m_FrameBuffer.dId;
			*poToggle = m_FrameBuffer.nCanData.sUploadSDOSegment_ReceiveFrame.t;
			*puNonValidNbOfBytes = m_FrameBuffer.nCanData.sUploadSDOSegment_ReceiveFrame.n;
			*poNoMoreSegments = m_FrameBuffer.nCanData.sUploadSDOSegment_ReceiveFrame.c;

			*pdSegDataBufferLength = k_DataSize;
			*ppSegDataBuffer = malloc(*pdSegDataBufferLength);
			memcpy(*ppSegDataBuffer,m_FrameBuffer.nCanData.sUploadSDOSegment_ReceiveFrame.data,*pdSegDataBufferLength);

			*pdAbortCode = 0;

			return TRUE;
		}
		else if(m_FrameBuffer.nCanData.sAbortTransfer_AbortFrame.cs == k_AbortCommandSpecifier)
		{
			*pdCobId = m_FrameBuffer.dId;
			*poToggle = FALSE;
			*puNonValidNbOfBytes = 0;
			*poNoMoreSegments = TRUE;

			*pdSegDataBufferLength = k_DataSize;
			*ppSegDataBuffer = malloc(*pdSegDataBufferLength);
			memset(*ppSegDataBuffer,0,*pdSegDataBufferLength);

			*pdAbortCode = m_FrameBuffer.nCanData.sAbortTransfer_AbortFrame.abortCode;

			return TRUE;
		}
	}

	return FALSE;
}

BOOL CCANopenFrame::CopyReceivedData_NetworkIndication(DWORD* pdCobId,WORD* pwTargetNetworkId,BYTE* puTargetNodeId,DWORD* pdAbortCode)
{
	const int k_CommandSpecifier = 7;
	const int k_AbortCommandSpecifier = 4;

	if(pdCobId && pwTargetNetworkId && puTargetNodeId && pdAbortCode)
	{
		if(m_FrameBuffer.nCanData.sNetworkIndication_ReceiveFrame.scs == k_CommandSpecifier)
		{
			*pdCobId = m_FrameBuffer.dId;
			*pwTargetNetworkId = m_FrameBuffer.nCanData.sNetworkIndication_ReceiveFrame.m1;
			*puTargetNodeId = m_FrameBuffer.nCanData.sNetworkIndication_ReceiveFrame.m2;
			*pdAbortCode = 0;

			return TRUE;
		}
		else if(m_FrameBuffer.nCanData.sAbortTransfer_AbortFrame.cs == k_AbortCommandSpecifier)
		{
			*pdCobId = m_FrameBuffer.dId;
			*pwTargetNetworkId = 0;
			*puTargetNodeId = 0;
			*pdAbortCode = m_FrameBuffer.nCanData.sAbortTransfer_AbortFrame.abortCode;

			return TRUE;
		}
	}

	return FALSE;
}

BOOL CCANopenFrame::CopyReceivedData_RequestCANFrame(void** ppDataBuffer,DWORD* pdDataBufferLength)
{
	const unsigned long k_DataSize = 8;

	if(ppDataBuffer && pdDataBufferLength)
	{
		//Prepare DataBuffer
		*pdDataBufferLength = m_FrameBuffer.wDlc;
		if(*pdDataBufferLength > k_DataSize) *pdDataBufferLength = k_DataSize;
		*ppDataBuffer = malloc(*pdDataBufferLength);
		memcpy(*ppDataBuffer,m_FrameBuffer.nCanData.aDataByte,*pdDataBufferLength);

		return TRUE;
	}

	return FALSE;
}

BOOL CCANopenFrame::CopyReceivedData_ReceivedCANFrame(void** ppDataBuffer,DWORD* pdDataBufferLength)
{
	return CopyReceivedData_RequestCANFrame(ppDataBuffer,pdDataBufferLength);
}

DWORD CCANopenFrame::GetCobId()
{
	return m_FrameBuffer.dId;
}

BOOL CCANopenFrame::GetRtr()
{
	return (BOOL)m_FrameBuffer.oRtr;
}

BYTE CCANopenFrame::GetDlc()
{
	return (BYTE)m_FrameBuffer.wDlc;
}

void CCANopenFrame::SetCobId(DWORD dCobId)
{
	m_FrameBuffer.dId = dCobId;
}

BOOL CCANopenFrame::CheckReceivedCommandSpecifier(CCANopenFrame* pSendingFrame,CCANopenFrame* pReceivingFrame)
{
	const int k_CommandSpecifierRightShift = 5;

	const int k_InitiateSDODownload_Send = 1;
	const int k_InitiateSDODownload_Receive = 3;
	const int k_DownloadSDOSegment_Send = 0;
	const int k_DownloadSDOSegment_Receive = 1;
	const int k_InitiateSDOUpload_Send = 2;
	const int k_InitiateSDOUpload_Receive = 2;
	const int k_UploadSDOSegment_Send = 3;
	const int k_UploadSDOSegment_Receive = 0;
	const int k_NetworkIndication_Send = 7;
	const int k_NetworkIndication_Receive = 7;
	const int k_Abort = 4;
	
	BYTE sendCommandSpecifier;
	BYTE receiveCommandSpecifier;

	if(pSendingFrame && pReceivingFrame)
	{
		//Command Specifiers
		sendCommandSpecifier = pSendingFrame->m_FrameBuffer.nCanData.aDataByte[0] >> k_CommandSpecifierRightShift;
		receiveCommandSpecifier = pReceivingFrame->m_FrameBuffer.nCanData.aDataByte[0] >> k_CommandSpecifierRightShift;

		//Allow Abort
		if(receiveCommandSpecifier == k_Abort) return TRUE;

		//Check Combinations
		switch(sendCommandSpecifier)
		{
			case k_InitiateSDODownload_Send: return (receiveCommandSpecifier == k_InitiateSDODownload_Receive);
			case k_DownloadSDOSegment_Send: return (receiveCommandSpecifier == k_DownloadSDOSegment_Receive);
			case k_InitiateSDOUpload_Send: return (receiveCommandSpecifier == k_InitiateSDOUpload_Receive);
			case k_UploadSDOSegment_Send: return (receiveCommandSpecifier == k_UploadSDOSegment_Receive);
			case k_NetworkIndication_Send: return (receiveCommandSpecifier == k_NetworkIndication_Receive);
		}
	}

	return FALSE;
}

BOOL CCANopenFrame::CheckReceivedMultiplexor(CCANopenFrame* pSendingFrame,CCANopenFrame* pReceivingFrame)
{
	const int k_CommandSpecifierRightShift = 5;

	const int k_InitiateSDODownload_Send = 1;
	const int k_InitiateSDOUpload_Send = 2;

	BYTE sendCommandSpecifier;

	if(pSendingFrame && pReceivingFrame)
	{
		//Command Specifiers
		sendCommandSpecifier = pSendingFrame->m_FrameBuffer.nCanData.aDataByte[0] >> k_CommandSpecifierRightShift;

		//Check Index & SubIndex
		switch(sendCommandSpecifier)
		{
			case k_InitiateSDODownload_Send:
				{
					return ((pSendingFrame->m_FrameBuffer.nCanData.sInitiateSDODownload_SendFrame.index == pReceivingFrame->m_FrameBuffer.nCanData.sInitiateSDODownload_ReceiveFrame.index) &&
							(pSendingFrame->m_FrameBuffer.nCanData.sInitiateSDODownload_SendFrame.subIndex == pReceivingFrame->m_FrameBuffer.nCanData.sInitiateSDODownload_ReceiveFrame.subIndex));
				};

			case k_InitiateSDOUpload_Send:
				{
					return ((pSendingFrame->m_FrameBuffer.nCanData.sInitiateSDOUpload_SendFrame.index == pReceivingFrame->m_FrameBuffer.nCanData.sInitiateSDOUpload_ReceiveFrame.index) &&
							(pSendingFrame->m_FrameBuffer.nCanData.sInitiateSDOUpload_SendFrame.subIndex == pReceivingFrame->m_FrameBuffer.nCanData.sInitiateSDOUpload_ReceiveFrame.subIndex));
				};

			default: return TRUE;
		}
	}

	return FALSE;
}

BOOL CCANopenFrame::CheckReceivedTargetNetwork(CCANopenFrame* pSendingFrame,CCANopenFrame* pReceivingFrame)
{
	const int k_CommandSpecifierRightShift = 5;

	const int k_NetworkIndication_Send = 7;

	BYTE sendCommandSpecifier = 0;

	if(pSendingFrame && pReceivingFrame)
	{
		//Command Specifiers
		sendCommandSpecifier = pSendingFrame->m_FrameBuffer.nCanData.aDataByte[0] >> k_CommandSpecifierRightShift;

		//Check Index & SubIndex
		switch(sendCommandSpecifier)
		{
			case k_NetworkIndication_Send:
				{
					return ((pSendingFrame->m_FrameBuffer.nCanData.sNetworkIndication_SendFrame.m1 == pReceivingFrame->m_FrameBuffer.nCanData.sNetworkIndication_ReceiveFrame.m1) &&
							(pSendingFrame->m_FrameBuffer.nCanData.sNetworkIndication_SendFrame.m2 == pReceivingFrame->m_FrameBuffer.nCanData.sNetworkIndication_ReceiveFrame.m2));
				};

			default: return TRUE;
		}
	}

	return FALSE;
}
