// GatewayMaxonSerialV2ToHID.cpp: Implementierung der Klasse CGatewayMaxonSerialV2ToHID.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GatewayMaxonSerialV2ToHID.h"
#ifdef _MMC_PS_MAXON_SERIAL_V2
#ifdef _MMC_I_HID
#include <Process/MmcProcess.h>

#include <CommunicationModel/CommonLayer/Classes/Commands/Interface/Command_I_USB.h>
#include <CommunicationModel/CommonLayer/Classes/Commands/ProtocolStack/BaseClasses/Command_PS.h>
#include "../../../../Interface/BaseClasses/InterfaceManagerBase.h"

#include <CommunicationModel/CommonLayer/Classes/Commands/Command/LayerParameter/LayerParameterStack.h>
#include <CommunicationModel/CommonLayer/Classes/Commands/Command/LayerParameter/LayerParameterSet.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

CGatewayMaxonSerialV2ToHID::CGatewayMaxonSerialV2ToHID()
    : m_pCommand_WriteData(0)
    , m_pCommand_ReadData(0)
{
    InitCommands();
    InitErrorHandling();
}

CGatewayMaxonSerialV2ToHID::~CGatewayMaxonSerialV2ToHID()
{
    DeleteCommands();
}

void CGatewayMaxonSerialV2ToHID::DeleteCommands()
{
    if(m_pCommand_ReadData)
    {
        delete m_pCommand_ReadData;
        m_pCommand_ReadData = 0;
    }

    if(m_pCommand_WriteData)
    {
        delete m_pCommand_WriteData;
        m_pCommand_WriteData = 0;
    }
}

void CGatewayMaxonSerialV2ToHID::InitCommands()
{
    DeleteCommands();

    //Init Command WriteData
    m_pCommand_WriteData = new CCommand_I_USB();
    m_pCommand_WriteData->InitCommand(USB_WRITE_DATA);

    //Init Command ReadData
    m_pCommand_ReadData = new CCommand_I_USB();
    m_pCommand_ReadData->InitCommand(USB_READ_DATA);
}

BOOL CGatewayMaxonSerialV2ToHID::Process_ProcessProtocol(CCommand_PS* p_pCommand, CInterfaceManagerBase* p_pInterfaceManager, HANDLE p_hI_Handle, HANDLE p_hTransactionHandle)
{
    const DWORD MAX_RETRY(2);

    //*Constants PS*
    const int PARAMETER_INDEX_OP_CODE(0);
    const int PARAMETER_INDEX_LEN(1);
    const int PARAMETER_INDEX_DATA(2);
    const int PARAMETER_INDEX_CRC(3);
    const int PARAMETER_INDEX_KEEP_LOCK(4);
    const int RETURN_PARAMETER_INDEX_OP_CODE(0);
    const int RETURN_PARAMETER_INDEX_LEN(1);
    const int RETURN_PARAMETER_INDEX_DATA(2);
    const int RETURN_PARAMETER_INDEX_CRC(3);

    //*Variables PS*
    //Parameter
    BYTE uOpCode(0);
    BYTE uLen(0);
    void* pDataBuffer(0);
    DWORD dDataBufferLength(0);
    WORD wCrc(0);
    BYTE ubKeepLock(0);

    //ReturnParameter
    BYTE uRetOpCode(0);
    BYTE uRetLen(0);
    void* pRetDataBuffer(0);
    DWORD dRetDataBufferLength(0);
    WORD wRetCrc(0);

    //Retry
    BOOL oExecuteRetry(0);
    DWORD dRetryCount(0);

    //SendFrame
    BOOL oSendResult(0);
    CErrorInfo sendErrorInfo;

    //ReceiveFrame
    BOOL oReceiveResult(0);
    CErrorInfo receiveErrorInfo;

    BOOL oResult(0);
    CErrorInfo errorInfo;
    DWORD dTimeout;

    if(p_pCommand && p_pInterfaceManager)
    {
        //Lock CriticalSection
        if(!IsLocked(p_pCommand))
        {
            if(!Lock(p_pCommand)) return 0;
        }

        //Prepare DataBuffer
        dDataBufferLength = p_pCommand->GetParameterLength(PARAMETER_INDEX_DATA);
        if(dDataBufferLength > 0) pDataBuffer = malloc(dDataBufferLength);

        //Prepare Return DataBuffer
        dRetDataBufferLength = p_pCommand->GetReturnParameterLength(RETURN_PARAMETER_INDEX_DATA);
        if(dRetDataBufferLength > 0) pRetDataBuffer = malloc(dRetDataBufferLength);

        //Get PS Parameter Data
        p_pCommand->GetParameterData(PARAMETER_INDEX_OP_CODE, &uOpCode, sizeof(uOpCode));
        p_pCommand->GetParameterData(PARAMETER_INDEX_LEN, &uLen, sizeof(uLen));
        p_pCommand->GetParameterData(PARAMETER_INDEX_DATA, pDataBuffer, dDataBufferLength);
        p_pCommand->GetParameterData(PARAMETER_INDEX_CRC, &wCrc, sizeof(wCrc));
        p_pCommand->GetParameterData(PARAMETER_INDEX_KEEP_LOCK, &ubKeepLock, sizeof(ubKeepLock));

        //Timeout
        dTimeout = p_pCommand->GetTimeout();

        //Execute Command
        while(!oResult && !m_oAbortCommands)
        {
            //Reset
            sendErrorInfo.Reset();
            receiveErrorInfo.Reset();

            //Send and Receive
            oSendResult = SendFrame(p_pInterfaceManager, p_hI_Handle, p_hTransactionHandle, uOpCode, &uLen, &pDataBuffer, &dDataBufferLength, &wCrc, &sendErrorInfo);
            MmcSleep(50);
            oReceiveResult = ReceiveFrame(p_pInterfaceManager, p_hI_Handle, p_hTransactionHandle, &uRetOpCode, &uRetLen, &pRetDataBuffer, &dRetDataBufferLength, &wRetCrc, dTimeout, &receiveErrorInfo);

            //Evaluate Retry
            oResult = EvaluateWriteRetry(oSendResult, sendErrorInfo, oReceiveResult, receiveErrorInfo, oExecuteRetry, errorInfo);
            if(oExecuteRetry)
            {
                dRetryCount++;
                if(dRetryCount > MAX_RETRY) break;
            }
            else
            {
                //Don't retry
                break;
            }
        }

        //Set PS ReturnParameter Data
        p_pCommand->SetStatus(oResult, &errorInfo);
        p_pCommand->SetParameterData(PARAMETER_INDEX_LEN, &uLen, sizeof(uLen));
        p_pCommand->SetParameterData(PARAMETER_INDEX_DATA, pDataBuffer, dDataBufferLength);
        p_pCommand->SetParameterData(PARAMETER_INDEX_CRC, &wCrc, sizeof(wCrc));
        p_pCommand->SetReturnParameterData(RETURN_PARAMETER_INDEX_OP_CODE, &uRetOpCode, sizeof(uRetOpCode));
        p_pCommand->SetReturnParameterData(RETURN_PARAMETER_INDEX_LEN, &uRetLen, sizeof(uRetLen));
        p_pCommand->SetReturnParameterData(RETURN_PARAMETER_INDEX_DATA, pRetDataBuffer, dRetDataBufferLength);
        p_pCommand->SetReturnParameterData(RETURN_PARAMETER_INDEX_CRC, &wRetCrc, sizeof(wRetCrc));

        //Free DataBuffer
        if(pDataBuffer) free(pDataBuffer);
        if(pRetDataBuffer) free(pRetDataBuffer);

        //Unlock CriticalSection
        if(!ubKeepLock) Unlock();
    }

    return oResult;
}

BOOL CGatewayMaxonSerialV2ToHID::EvaluateWriteRetry(BOOL p_oSendResult, CErrorInfo& p_rSendErrorInfo, BOOL p_oReceiveResult, CErrorInfo& p_rReceiveErrorInfo, BOOL& p_roExecuteRetry, CErrorInfo& p_rErrorInfo)
{
    static BOOL oSendFrameSizeErrorDetected(0);
    BOOL oResult(0);

    if(p_oSendResult)
    {
        //SendFrame succeeded
        if(p_oReceiveResult)
        {
            //ReceiveFrame succeeded -> Don't Retry
            oSendFrameSizeErrorDetected = 0;
            p_roExecuteRetry = 0;
            p_rErrorInfo = p_rReceiveErrorInfo;
            oResult = 1;
        }
        else
        {
            //ReceiveFrame failed
            if(oSendFrameSizeErrorDetected)
            {
                //Retry
            	MmcSleep(5);
                p_roExecuteRetry = 1;
                p_rErrorInfo = p_rReceiveErrorInfo;
                oResult = 0;
            }
            else
            {
                //Don't Retry
                p_roExecuteRetry = 0;
                p_rErrorInfo = p_rReceiveErrorInfo;
                oResult = 0;
            }
        }
    }
    else
    {
        //SendFrame failed
        if(p_oReceiveResult)
        {
            //ReceiveFrame succeeded -> Don't Retry
            oSendFrameSizeErrorDetected = 1;
            p_roExecuteRetry = 0;
            p_rErrorInfo = p_rReceiveErrorInfo;
            oResult = 1;
        }
        else
        {
            //ReceiveFrame failed -> Retry
        	MmcSleep(5);
            p_roExecuteRetry = 1;
            p_rErrorInfo = p_rSendErrorInfo;
            oResult = 0;
        }
    }

    return oResult;
}

CGateway* CGatewayMaxonSerialV2ToHID::Clone()
{
    CGatewayMaxonSerialV2ToHID* pClonedGateway;

    pClonedGateway = new CGatewayMaxonSerialV2ToHID();
    *pClonedGateway = *this;

    return pClonedGateway;
}

CGatewayMaxonSerialV2ToHID& CGatewayMaxonSerialV2ToHID::operator=(CGatewayMaxonSerialV2ToHID& p_Other)
{
    if(this != &p_Other)
    {
        *((CGatewayMaxonSerialV2ToI*)this) = *((CGatewayMaxonSerialV2ToI*)&p_Other);
    }

    return *this;
}

BOOL CGatewayMaxonSerialV2ToHID::I_ReadData(CInterfaceManagerBase* p_pInterfaceManager, HANDLE p_hI_Handle, HANDLE p_hTransactionHandle, void* p_pData, DWORD p_ulNumberOfBytesToRead, DWORD* p_pulNumberOfBytesRead, CErrorInfo* p_pErrorInfo)
{
    BOOL oResult(0);
    DWORD dataLength(0);

    if(m_pCommand_ReadData)
    {
        //Set Parameter Data
        m_pCommand_ReadData->ResetStatus();
        m_pCommand_ReadData->SetParameterData(0, &p_ulNumberOfBytesToRead, sizeof(p_ulNumberOfBytesToRead));

        //Execute Command
        oResult = p_pInterfaceManager->ExecuteCommand(m_pCommand_ReadData, p_hI_Handle, p_hTransactionHandle);

        //Limit Parameter Length
        dataLength = m_pCommand_ReadData->GetReturnParameterLength(0);
        if(dataLength > p_ulNumberOfBytesToRead) dataLength = p_ulNumberOfBytesToRead;

        //Get ReturnParameter Data
        m_pCommand_ReadData->GetReturnParameterData(0, p_pData, dataLength);
        if(p_pulNumberOfBytesRead) *p_pulNumberOfBytesRead = dataLength;

        //Get ErrorCode
        m_pCommand_ReadData->GetErrorInfo(p_pErrorInfo);
    }

    return oResult;
}

BOOL CGatewayMaxonSerialV2ToHID::I_WriteData(CInterfaceManagerBase* p_pInterfaceManager, HANDLE p_hI_Handle, HANDLE p_hTransactionHandle, void* p_pData, DWORD p_ulNumberOfBytesToWrite, DWORD* p_pulNumberOfBytesWritten, CErrorInfo* p_pErrorInfo)
{
    BOOL oResult(0);

    if(m_pCommand_WriteData && p_pInterfaceManager)
    {
        //Set Parameter Data
        m_pCommand_WriteData->ResetStatus();
        m_pCommand_WriteData->SetParameterData(0, p_pData, p_ulNumberOfBytesToWrite);

        //Execute Command
        oResult = p_pInterfaceManager->ExecuteCommand(m_pCommand_WriteData, p_hI_Handle, p_hTransactionHandle);

        //Get ReturnParameter Data
        m_pCommand_WriteData->GetReturnParameterData(0, p_pulNumberOfBytesWritten, sizeof(*p_pulNumberOfBytesWritten));

        //Get ErrorCode
        m_pCommand_WriteData->GetErrorInfo(p_pErrorInfo);
    }

    return oResult;
}

BOOL CGatewayMaxonSerialV2ToHID::InitErrorHandling()
{
    CErrorProducer errorProducer;
    CStdString strClassName(_T("GatewayMaxonSerialV2ToHID"));

    if(m_pErrorHandling)
    {
        //Init ErrorProducer
        errorProducer.Init(PROTOCOL_STACK_LAYER, strClassName);
        m_pErrorHandling->InitErrorProducer(&errorProducer);
        return 1;
    }

    return 0;
}

BOOL CGatewayMaxonSerialV2ToHID::InitLayerParameterStack(CCommandRoot* p_pCommand)
{
    CLayerParameterStack layerParameterStack;
    CLayerParameterSet layerParameterSet;
    BOOL oResult = 0;

    if(p_pCommand)
    {
        if(p_pCommand->GetLayerParameterStack(layerParameterStack))
        {
            //Pop PS Layer Parameter Set
            layerParameterStack.PopLayer(PROTOCOL_STACK_LAYER, layerParameterSet);

            //Set I Layer Commands
            if(m_pCommand_WriteData) m_pCommand_WriteData->SetLayerParameterStack(layerParameterStack);
            if(m_pCommand_ReadData) m_pCommand_ReadData->SetLayerParameterStack(layerParameterStack);
            oResult = 1;
        }
    }

    return oResult;
}
#endif //_MMC_I_HID
#endif //_MMC_PS_MAXON_SERIAL_V2
