// GatewayCANopenToIXXAT.h: Schnittstelle f�r die Klasse CGatewayCANopenToIXXAT.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GatewayCANopenToIXXAT_H__89B9836A_BF97_42DF_8370_3E0AF46F87FE__INCLUDED_)
#define AFX_GatewayCANopenToIXXAT_H__89B9836A_BF97_42DF_8370_3E0AF46F87FE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "GatewayCANopenToI.h"

class CGatewayCANopenToIXXAT : public CGatewayCANopenToI
{
public:
	CGatewayCANopenToIXXAT();
	virtual ~CGatewayCANopenToIXXAT();

	virtual CGateway* Clone();
	CGatewayCANopenToIXXAT& operator=(CGatewayCANopenToIXXAT& other);

private:
	BOOL InitErrorHandling();
};

#endif // !defined(AFX_GatewayCANopenToIXXAT_H__89B9836A_BF97_42DF_8370_3E0AF46F87FE__INCLUDED_)
