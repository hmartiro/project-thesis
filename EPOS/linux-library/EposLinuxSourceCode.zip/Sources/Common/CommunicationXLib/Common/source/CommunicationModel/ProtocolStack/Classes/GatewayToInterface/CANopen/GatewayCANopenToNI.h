// GatewayCANopenToNI.h: Schnittstelle f�r die Klasse CGatewayCANopenToNI.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GatewayCANopenToNI_H__89B9836A_BF97_42DF_8370_3E0AF46F87FE__INCLUDED_)
#define AFX_GatewayCANopenToNI_H__89B9836A_BF97_42DF_8370_3E0AF46F87FE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "GatewayCANopenToI.h"

class CGatewayCANopenToNI : public CGatewayCANopenToI
{
public:
	CGatewayCANopenToNI();
	virtual ~CGatewayCANopenToNI();

	virtual CGateway* Clone();
	CGatewayCANopenToNI& operator=(CGatewayCANopenToNI& other);

private:
	BOOL InitErrorHandling();
};

#endif // !defined(AFX_GatewayCANopenToNI_H__89B9836A_BF97_42DF_8370_3E0AF46F87FE__INCLUDED_)
