// CommandSetObjectDictionary_DCS_Escon.h: Schnittstelle f�r die Klasse CCommandSetObjectDictionary_DCS_Escon.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include <CommunicationModel/Common/CommunicationModelDefinitions.h>
#ifdef _MMC_DCS_ESCON

#include "../BaseClasses/CommandSetBase_DCS.h"
#include <CommunicationModel/CommonLayer/ErrorHandling/ErrorInfo.h>
#include <Classes/XXMLFile.h>

class CGateway;
class CCommand_DCS_Escon;
class CLayerManagerBase;

class CCommandSetObjectDictionary_DCS_Escon : public CCommandSetBase_DCS
{
public:
    //Funktionalit�t fuer Escon Befehlssatz
    BOOL DCS_ReadObject(CLayerManagerBase* p_pManager, HANDLE p_hHandle, HANDLE p_hTransactionHandle, WORD p_usNodeId, WORD p_usIndex, WORD p_usSubIndex, BYTE* p_pubObjectBuffer, DWORD p_ulObjectLength, CErrorInfo* p_pErrorInfo = 0);
    BOOL DCS_WriteObject(CLayerManagerBase* p_pManager, HANDLE p_hHandle, HANDLE p_hTransactionHandle, WORD p_usNodeId, WORD p_usIndex, WORD p_usSubIndex, BYTE* p_pubObjectBuffer, DWORD p_ulObjectLength, CErrorInfo* p_pErrorInfo = 0);
    BOOL DCS_InitiateSegmentedRead(CLayerManagerBase* p_pManager, HANDLE p_hHandle, HANDLE p_hTransactionHandle, WORD p_usNodeId, WORD p_usIndex, WORD p_usSubIndex, CErrorInfo* p_pErrorInfo = 0);
    BOOL DCS_InitiateSegmentedWrite(CLayerManagerBase* p_pManager, HANDLE p_hHandle, HANDLE p_hTransactionHandle, WORD p_usNodeId, WORD p_usIndex, WORD p_usSubIndex, DWORD p_ulObjectLength, CErrorInfo* p_pErrorInfo = 0);
    BOOL DCS_SegmentedRead(CLayerManagerBase* p_pManager, HANDLE p_hHandle, HANDLE p_hTransactionHandle, WORD p_usNodeId, BOOL p_oToggle, BOOL* p_poMoreSegments, BYTE* p_pubSegmentBuffer, DWORD p_ulSegmentBufferLength, DWORD* p_pulSegmentLengthRead, CErrorInfo* p_pErrorInfo = 0);
    BOOL DCS_SegmentedWrite(CLayerManagerBase* p_pManager, HANDLE p_hHandle, HANDLE p_hTransactionHandle, WORD p_usNodeId, BOOL p_oToggle, BOOL p_oMoreSegments, BYTE* p_pubSegmentBuffer, DWORD p_ulSegmentLength, DWORD* p_pulSegmentLengthWritten, CErrorInfo* p_pErrorInfo = 0);
    BOOL DCS_AbortSegmentedTransfer(CLayerManagerBase* p_pManager, HANDLE p_hHandle, HANDLE p_hTransactionHandle, WORD p_usNodeId, WORD p_usIndex, WORD p_usSubIndex, DWORD p_ulAbortCode, CErrorInfo* p_pErrorInfo = 0);

    CCommandSetObjectDictionary_DCS_Escon();
    virtual ~CCommandSetObjectDictionary_DCS_Escon();

//JournalManager
    virtual void InitJournalManager(CJournalManagerBase* p_pJournalManager);
    virtual void ResetJournalManager();

    virtual BOOL InitGateway(CGateway *p_pGateway);

    CXXMLFile::CElementPart* StoreToXMLFile(CXXMLFile* p_pFile, CXXMLFile::CElementPart* p_pParentElement);

private:
    void DeleteCommands();
    void InitCommands();

    CCommand_DCS_Escon* m_pCommand_WriteObject;
    CCommand_DCS_Escon* m_pCommand_InitiateSegmentedWrite;
    CCommand_DCS_Escon* m_pCommand_SegmentedWrite;

    CCommand_DCS_Escon* m_pCommand_ReadObject;
    CCommand_DCS_Escon* m_pCommand_InitiateSegmentedRead;
    CCommand_DCS_Escon* m_pCommand_SegmentedRead;

    CCommand_DCS_Escon* m_pCommand_AbortSegmentedTransfer;
};
#endif //_MMC_DCS_ESCON
