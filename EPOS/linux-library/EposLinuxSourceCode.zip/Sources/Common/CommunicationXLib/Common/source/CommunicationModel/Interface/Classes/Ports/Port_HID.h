#if !defined(AFX_Port_HID_H__95811EF2_3171_4F25_B8FD_52A0035BF3C4__INCLUDED_)
#define AFX_Port_HID_H__95811EF2_3171_4F25_B8FD_52A0035BF3C4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <MmcDefinitions.h>
#ifdef _MMC_I_HID
#include "BaseClasses/PortBase.h"

class CCommand_I_USB;
class CJournalManagerBase;

class CPort_HID : public CPortBase
{    
public:
    BOOL operator==(const CPort_HID& p_rPort);
    CPort_HID& operator=(CPort_HID& p_rSetting);

    CPort_HID();
    CPort_HID(CPort_HID& p_rObject);
    virtual ~CPort_HID();
    CPortBase* Clone();

    //Funktionalit�t
    BOOL GetCommands(CStdString* p_pCommandInfo);
    BOOL I_ReadData(HANDLE p_hTransactionHandle, void* p_pData, DWORD p_ulNumberOfBytesToRead, DWORD* p_pulNumberOfBytesRead, CErrorInfo* p_pErrorInfo = 0);
    BOOL I_WriteData(HANDLE p_hTransactionHandle, void* p_pData, DWORD p_ulNumberOfBytesToWrite, DWORD* p_pulNumberOfBytesWritten, CErrorInfo* p_pErrorInfo = 0);

//JournalManager
    virtual void InitJournalManager(CJournalManagerBase *p_pJournalManager);
    virtual void ResetJournalManager();

private:
    BOOL InitErrorHandling();
    void DeleteCommands();
    void InitCommands();
    void InitCommands(CGatewayIToDrv* p_pGateway);
    BOOL InitGateway(CGatewayIToDrv* p_pGateway);
    void ResetPortMembers();
    void SetDefault();

    //ParameterSet
    BOOL InitParameterSet();

private:
    CCommand_I_USB* m_pCommand_ReadData;
    CCommand_I_USB* m_pCommand_WriteData;
};
#endif //_MMC_I_HID
#endif // !defined(AFX_Port_HID_H__95811EF2_3171_4F25_B8FD_52A0035BF3C4__INCLUDED_)
