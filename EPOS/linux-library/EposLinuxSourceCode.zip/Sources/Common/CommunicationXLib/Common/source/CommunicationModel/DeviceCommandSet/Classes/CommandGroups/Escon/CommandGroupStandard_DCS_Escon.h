// CommandGroupStandard_DCS_Escon.h: Schnittstelle f�r die Klasse CCommandGroupStandard_DCS_Escon.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include <CommunicationModel/Common/CommunicationModelDefinitions.h>
#ifdef _MMC_DCS_ESCON
#include <Classes/XXMLFile.h>
#include "../BaseClasses/CommandGroupBase_DCS.h"

class CCommandSetObjectDictionary_DCS_Escon;
class CGateway;

class CCommandGroupStandard_DCS_Escon : public CCommandGroupBase_DCS
{
public:
    CCommandGroupStandard_DCS_Escon();
    virtual ~CCommandGroupStandard_DCS_Escon();

//JournalManager
    virtual void InitJournalManager(CJournalManagerBase* p_pJournalManager);
    virtual void ResetJournalManager();

    virtual BOOL InitGateway(CGateway *p_pGateway);

    CXXMLFile::CElementPart* StoreToXMLFile(CXXMLFile* pFile, CXXMLFile::CElementPart* pParentElement);

private:
    void DeleteSetList();
    void FillSetList();

    CCommandSetObjectDictionary_DCS_Escon* m_pCommandSetObjectDictionary;
};
#endif //_MMC_DCS_ESCON
