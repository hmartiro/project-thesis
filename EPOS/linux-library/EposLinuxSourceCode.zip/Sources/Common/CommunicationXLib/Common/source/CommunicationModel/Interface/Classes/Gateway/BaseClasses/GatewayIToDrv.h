// GatewayIToDrv.h: Schnittstelle f�r die Klasse CGatewayIToDrv.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GatewayIToDrv_H__21893C20_2412_4E7B_9899_51A57FDE37D4__INCLUDED_)
#define AFX_GatewayIToDrv_H__21893C20_2412_4E7B_9899_51A57FDE37D4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "../../../../CommonLayer/Classes/Gateway/Gateway.h"
#include "../../Ports/BaseClasses/PortBase.h"

class CCommand_PS;
class CInterfaceManagerBase;

class CGatewayIToDrv: public CGateway
{
public:
	virtual WORD GetNbOfAvailableBoards();

	CGatewayIToDrv();
	virtual ~CGatewayIToDrv();
	virtual CGateway* Clone();
	virtual CGatewayIToDrv& operator=(CGatewayIToDrv& other);

//Interne Struktur Funktionen
	virtual BOOL InitPort(WORD wBoardNumber,WORD wNbBoardWithOldDriver);
	virtual BOOL InitGateway();
	virtual BOOL InitBaudrateSelection(CStdDWordArray& dBaudrateSel);
	virtual BOOL InitDefaultPortSettings(DWORD dBaudrate,DWORD dTimeout);
	virtual BOOL UpdatePort(tPortList& p_rOpenPortList);

//Initialisation
	virtual BOOL OpenInterface(CStdString strInterfaceName,CErrorInfo* pErrorInfo = NULL);
	virtual BOOL CloseInterface(CErrorInfo* pErrorInfo = NULL);

	virtual BOOL OpenPort(CStdString strPortName,CErrorInfo* pErrorInfo = NULL);
	virtual BOOL ReopenPort(CStdString strPortName,CErrorInfo* pErrorInfo = NULL);
	virtual BOOL ClosePort(CErrorInfo* pErrorInfo = NULL);

//Hilfsfunktionen
	virtual BOOL ResetPort(CErrorInfo* pErrorInfo = NULL);
	virtual BOOL GetDefaultPortSettings(DWORD* pdBaudrate,DWORD* pdTimeout,CErrorInfo* pErrorInfo = NULL);
	virtual BOOL IsPortNameSupported(CStdString strPortName);
    virtual BOOL SetDefaultPortSettings(DWORD dBaudrate, DWORD dTimeout, CErrorInfo* pErrorInfo = NULL);

//Selection Funktionen
	virtual BOOL GetPortNameSelection(CStdStringArray* pPortSel,CErrorInfo* pErrorInfo = NULL);
	virtual BOOL GetBaudrateSelection(CStdDWordArray* pdBaudrateSel,CErrorInfo* pErrorInfo = NULL);
	virtual BOOL GetPortModeSelection(CStdStringArray* pPortModeSel,CErrorInfo* pErrorInfo = NULL);

//Setting Funktionen
	virtual BOOL SetPortSettings(DWORD dBaudrate,DWORD dTimeout,BOOL oChangeOnly,CErrorInfo* pErrorInfo = NULL);
	virtual BOOL GetPortSettings(DWORD* pdBaudrate,DWORD* pdTimeout,CErrorInfo* pErrorInfo = NULL);

	virtual BOOL SetPortMode(WORD wPortMode,CErrorInfo* pErrorInfo = NULL);
	virtual BOOL GetPortMode(WORD* pwPortMode,CErrorInfo* pErrorInfo = NULL);

//Name Funktionen
	virtual BOOL InitInterfacePortName(CStdString* pStrInterfacePortName,WORD wBoardNumber,WORD wNbBoardWithOldDriver);
	virtual BOOL InitInterfaceName(CStdString* pStrInterfaceName,WORD wBoardNumber,WORD wNbBoardWithOldDriver);

//Funktionalit�t
	virtual BOOL ProcessCommand(CCommandRoot* pCommand,CLayerManagerBase* pManager,HANDLE h_Handle,HANDLE hTransactionHandle);

//Tracing
	virtual BOOL EnableTracing(CStdString p_FileName,CErrorInfo* pErrorInfo = NULL);
	virtual BOOL DisableTracing(CErrorInfo* pErrorInfo = NULL);

protected:
	void AddPortList(CStdString strPortName);
	void DeletePortList();

	//Tracing
	BOOL Trace_Open(CStdString p_FileName);
	BOOL Trace_WriteData(BOOL oResult,void* pDataBuffer,DWORD dNbOfBytesToWrite,DWORD* pdNbOfBytesWritten,CStdString description = _T(""));
	BOOL Trace_ReadData(BOOL oResult,void* pDataBuffer,DWORD dNbOfBytesToRead,DWORD* pdNbOfBytesRead,CStdString description = _T(""));
	BOOL Trace_Settings(DWORD dBaudrate,DWORD dTimeout);
	BOOL Trace_Close();

private:
	//Tracing
	BOOL Trace_FormatData(CStdString strFunction,BOOL oResult,void* pDataBuffer,DWORD dNbOfBytesToDo,DWORD* pdNbOfBytesDone,BOOL oShowFailedData,CStdString description,CStdString& p_rTraceLine);
	BOOL Trace_WriteLine(CStdString traceLine);

protected:
	CStdString m_strInterfaceName;
	CStdString m_strInterfacePortName;
	CStdStringArray m_strPortArray;
	CStdDWordArray m_BaudrateSelection;
	
	DWORD m_dDefaultBaudrate;
	DWORD m_dDefaultTimeout;

	DWORD m_dBaudrate;
	DWORD m_dTimeout;

	CStdString m_PortName;
	WORD	m_wPortMode;

private:
	//Tracing
	CStdString		m_TraceFileName;
	std::ofstream	m_TraceFile;
	BOOL			m_TraceFileOpen;
	DWORD			m_dTraceLineCount;
	DWORD			m_dStartTime;
	DWORD			m_dLastTime;
	BOOL			m_oTracingEnabled;

};

#endif // !defined(AFX_GatewayIToDrv_H__21893C20_2412_4E7B_9899_51A57FDE37D4__INCLUDED_)
