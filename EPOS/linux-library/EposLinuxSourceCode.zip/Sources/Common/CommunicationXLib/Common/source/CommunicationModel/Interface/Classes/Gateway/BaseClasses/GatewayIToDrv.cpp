// GatewayIToDrv.cpp: Implementierung der Klasse CGatewayIToDrv.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "GatewayIToDrv.h"
#include <Process/MmcProcess.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////
CGatewayIToDrv::CGatewayIToDrv()
{
	m_eInputLayer = INTERFACE_LAYER;
	m_eOutputLayer = NO_LAYER;

	m_strInterfaceName = "";
	m_strInterfacePortName = "";
	m_dDefaultBaudrate = 0;
	m_dDefaultTimeout = 0;

	m_dBaudrate = 0;
	m_dTimeout = 0;
	m_wPortMode = 0;

	m_TraceFileName = _T("");
	m_oTracingEnabled = FALSE;
	m_TraceFileOpen = FALSE;
	m_dTraceLineCount = 0;
	m_dStartTime = 0;
	m_dLastTime = 0;
}

CGatewayIToDrv::~CGatewayIToDrv()
{
}

BOOL CGatewayIToDrv::InitGateway()
{
	return TRUE;
}

BOOL CGatewayIToDrv::InitBaudrateSelection(CStdDWordArray& dBaudrateSel)
{
	m_BaudrateSelection.clear();
	m_BaudrateSelection=dBaudrateSel;

	return TRUE;
}
	
BOOL CGatewayIToDrv::InitDefaultPortSettings(DWORD dBaudrate,DWORD dTimeout)
{
	m_dDefaultBaudrate = dBaudrate;
	m_dDefaultTimeout = dTimeout;
	GetDefaultPortSettings(&m_dBaudrate,&m_dTimeout);

	return TRUE;
}

BOOL CGatewayIToDrv::InitInterfacePortName(CStdString* pStrInterfacePortName,WORD wBoardNumber,WORD wNbBoardWithOldDriver)
{
	return FALSE;
}

BOOL CGatewayIToDrv::InitInterfaceName(CStdString* pStrInterfaceName,WORD wBoardNumber,WORD wNbBoardWithOldDriver)
{
	return FALSE;
}

CGateway* CGatewayIToDrv::Clone()
{
	return NULL;
}

BOOL CGatewayIToDrv::InitPort(WORD wBoardNumber,WORD wNbBoardWithOldDriver)
{
	return FALSE;
}

BOOL CGatewayIToDrv::UpdatePort(tPortList& p_rOpenPortList)
{
	return FALSE;
}

BOOL CGatewayIToDrv::OpenPort(CStdString strPortName,CErrorInfo* pErrorInfo)
{
	return FALSE;
}

BOOL CGatewayIToDrv::ReopenPort(CStdString strPortName,CErrorInfo* pErrorInfo)
{
	BOOL oResult = FALSE;

    //Close
    if(ClosePort(pErrorInfo))
    {
        //Open
        oResult = OpenPort(strPortName, pErrorInfo);
    }

    if(!oResult && m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
    return oResult;

}

BOOL CGatewayIToDrv::ClosePort(CErrorInfo* pErrorInfo)
{
	return FALSE;
}

BOOL CGatewayIToDrv::ResetPort(CErrorInfo* pErrorInfo)
{
	return FALSE;
}

BOOL CGatewayIToDrv::SetPortSettings(DWORD dBaudrate,DWORD dTimeout,BOOL oChangeOnly,CErrorInfo* pErrorInfo)
{
	return FALSE;
}

BOOL CGatewayIToDrv::GetPortSettings(DWORD* pdBaudrate,DWORD* pdTimeout,CErrorInfo* pErrorInfo)
{
	return FALSE;
}

BOOL CGatewayIToDrv::GetDefaultPortSettings(DWORD* pdBaudrate,DWORD* pdTimeout,CErrorInfo* pErrorInfo)
{
	if(pdBaudrate) *pdBaudrate = m_dDefaultBaudrate;
	if(pdTimeout) *pdTimeout = m_dDefaultTimeout;

	return TRUE;
}

BOOL CGatewayIToDrv::SetDefaultPortSettings(DWORD dBaudrate, DWORD dTimeout, CErrorInfo* pErrorInfo)
{
	m_dDefaultBaudrate = dBaudrate;
	m_dDefaultTimeout = dTimeout;

	return TRUE;
}

BOOL CGatewayIToDrv::SetPortMode(WORD wPortMode,CErrorInfo* pErrorInfo)
{
	return FALSE;
}

BOOL CGatewayIToDrv::GetPortMode(WORD* pwPortMode,CErrorInfo* pErrorInfo)
{
	return FALSE;
}

CGatewayIToDrv& CGatewayIToDrv::operator=(CGatewayIToDrv& other)
{
	if(this != &other)
	{
		*((CGateway*)this) = *((CGateway*)&other);
		m_strInterfaceName = other.m_strInterfaceName;
		m_strInterfacePortName = other.m_strInterfacePortName;

		m_BaudrateSelection.clear();
		m_BaudrateSelection=other.m_BaudrateSelection;

		m_dDefaultBaudrate = other.m_dDefaultBaudrate;
		m_dDefaultTimeout = other.m_dDefaultTimeout;

		m_dBaudrate = other.m_dBaudrate;
		m_dTimeout = other.m_dTimeout;
		m_wPortMode = other.m_wPortMode;
	}

	return *this;
}

BOOL CGatewayIToDrv::ProcessCommand(CCommandRoot* pCommand,CLayerManagerBase* pManager,HANDLE h_Handle,HANDLE hTransactionHandle)
{
	return FALSE;
}

BOOL CGatewayIToDrv::OpenInterface(CStdString strInterfaceName,CErrorInfo* pErrorInfo)
{
	return TRUE;
}

BOOL CGatewayIToDrv::CloseInterface(CErrorInfo* pErrorInfo)
{
	return TRUE;
}

void CGatewayIToDrv::DeletePortList()
{
	m_strPortArray.clear();
}

//********************************************************************
void CGatewayIToDrv::AddPortList(CStdString strPortName)
{
	CStdString strPortNameList;

	for(std::size_t i=0;i<m_strPortArray.size();i++)
	{
		strPortNameList = m_strPortArray.at(i);

		if(strPortName==strPortNameList)
		{			
			m_strPortArray[i]=strPortName;
			return;
		}
	}
	m_strPortArray.push_back(strPortName);
	return;
}
//********************************************************************
BOOL CGatewayIToDrv::GetPortNameSelection(CStdStringArray* pPortSel,CErrorInfo* pErrorInfo)
{
	if(pPortSel)
	{
		pPortSel->clear();
		*pPortSel = m_strPortArray;
		return TRUE;
	}

	if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal,pErrorInfo);
	return FALSE;
}

//********************************************************************
BOOL CGatewayIToDrv::GetBaudrateSelection(CStdDWordArray* pdBaudrateSel,CErrorInfo* pErrorInfo)
{
	if(pdBaudrateSel)
	{
		pdBaudrateSel->clear();
		*pdBaudrateSel=m_BaudrateSelection;
		return TRUE;
	}

	if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_NullPointer,pErrorInfo);
	return FALSE;
}

//********************************************************************
BOOL CGatewayIToDrv::GetPortModeSelection(CStdStringArray* pPortModeSel,CErrorInfo* pErrorInfo)
{
	if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal,pErrorInfo);
	return FALSE;
}

//********************************************************************
BOOL CGatewayIToDrv::IsPortNameSupported(CStdString strPortName)
{
	CStdString strName;

	for(std::size_t i=0;i<m_strPortArray.size();i++)
	{
		strName = m_strPortArray.at(i);

		if(strName==strPortName)
		{
			return TRUE;
		}
	}

	return FALSE;
}

//********************************************************************
WORD CGatewayIToDrv::GetNbOfAvailableBoards()
{
	return 0;
}


BOOL CGatewayIToDrv::EnableTracing(CStdString p_FileName,CErrorInfo* pErrorInfo)
{
	BOOL oResult = FALSE;

	//Init
	m_oTracingEnabled = TRUE;
	m_TraceFileName = p_FileName;

	//Open
	if(Trace_Open(p_FileName))
	{
		//Succeeded
		m_oTracingEnabled = TRUE;
		oResult = TRUE;
	}
	else
	{
		//Failed
		m_oTracingEnabled = FALSE;
		m_TraceFileName = _T("");

		if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal,pErrorInfo);
		oResult = FALSE;
	}

	return oResult;
}

BOOL CGatewayIToDrv::DisableTracing(CErrorInfo* pErrorInfo)
{
	BOOL oResult = FALSE;

	//Close
	if(Trace_Close())
	{
		m_oTracingEnabled = FALSE;
		oResult = TRUE;
	}
	
	return oResult;
}

BOOL CGatewayIToDrv::Trace_Open(CStdString p_FileName)
{
	BOOL oResult = FALSE;

	if(!m_TraceFileOpen && !m_TraceFileName.IsEmpty())
	{
		m_TraceFile.open(m_TraceFileName);

		if(!m_TraceFile.fail())
		{
			m_dStartTime = 0;
			m_dTraceLineCount = 0;
			m_TraceFileOpen = TRUE;
			m_TraceFileName = p_FileName;
			oResult = TRUE;
		}
	}

	return oResult;
}

BOOL CGatewayIToDrv::Trace_WriteData(BOOL oResult,void* pDataBuffer,DWORD dNbOfBytesToWrite,DWORD* pdNbOfBytesWritten,CStdString description)
{
	CStdString strTraceLine;
	BOOL oRes = FALSE;

	if(m_oTracingEnabled)
	{
		if(Trace_FormatData("WriteData",oResult,pDataBuffer,dNbOfBytesToWrite,pdNbOfBytesWritten,TRUE,description,strTraceLine))
		{
			oRes = Trace_WriteLine(strTraceLine);
		}
	}

	return oRes;
}

BOOL CGatewayIToDrv::Trace_ReadData(BOOL oResult,void* pDataBuffer,DWORD dNbOfBytesToRead,DWORD* pdNbOfBytesRead,CStdString description)
{
	CStdString strTraceLine;
	BOOL oRes = FALSE;

	if(m_oTracingEnabled)
	{
		if(Trace_FormatData("ReadData",oResult,pDataBuffer,dNbOfBytesToRead,pdNbOfBytesRead,FALSE,description,strTraceLine))
		{
			oRes = Trace_WriteLine(strTraceLine);
		}
	}

	return oRes;
}

BOOL CGatewayIToDrv::Trace_Settings(DWORD dBaudrate,DWORD dTimeout)
{
	CStdString strTraceLine;
	CStdString str;
	DWORD dTime = 0;
	BOOL oRes = FALSE;

	if(m_oTracingEnabled)
	{
		//Line
		str.Format("Line %.8X:",m_dTraceLineCount++);
		strTraceLine = str;

		//Time
		if(m_dStartTime == 0)
		{
			m_dStartTime = MmcGetTickCount();
			m_dLastTime = 0;
			str.Format("Time: %.8ums,%.8ums; ",0,0);
		}
		else
		{
			dTime = MmcGetTickCount()-m_dStartTime;
			str.Format("Time: %.8ums,%.8ums; ",dTime,dTime-m_dLastTime);
			m_dLastTime = dTime;
		}
		strTraceLine += str;

		//Settings
		str.Format("Baudrate=%i,Timeout=%i",dBaudrate,dTimeout);
		strTraceLine += str;

		oRes = Trace_WriteLine(strTraceLine);
	}

	return oRes;
}

BOOL CGatewayIToDrv::Trace_FormatData(CStdString strFunction,BOOL oResult,void* pDataBuffer,DWORD dNbOfBytesToDo,DWORD* pdNbOfBytesDone,BOOL oShowFailedData,CStdString description,CStdString& p_rTraceLine)
{
	DWORD dTime = 0;
	CStdString strTraceLine = _T("");
	CStdString str = _T("");
	DWORD dDataSize = 0;
	BOOL oRes = FALSE;

	if(pDataBuffer && pdNbOfBytesDone)
	{
		//Line
		str.Format("Line %.8X:",m_dTraceLineCount++);
		strTraceLine = str;

		//Time
		if(m_dStartTime == 0)
		{
			m_dStartTime = MmcGetTickCount();
			m_dLastTime = 0;
			str.Format("Time: %.8ums,%.8ums; ",0,0);
		}
		else
		{
			dTime = MmcGetTickCount()-m_dStartTime;
			str.Format("Time: %.8ums,%.8ums; ",dTime,dTime-m_dLastTime);
			m_dLastTime = dTime;
		}
		strTraceLine += str;

		//Header
		strTraceLine += strFunction;
		if(oResult)
		{
			if(description.IsEmpty())
			{
				strTraceLine += " Succeeded: ";
			}
			else
			{
				strTraceLine += " Succeeded (" + description + "): ";
			}
		}
		else
		{
			if(description.IsEmpty())
			{
				strTraceLine += " Failed: ";
			}
			else
			{
				strTraceLine += " Failed (" + description + "): ";
			}
		}

		//Numbers
		str.Format("ToDo %i,Done %i:",dNbOfBytesToDo,*pdNbOfBytesDone);
		strTraceLine += str;

		//Data
		if(oShowFailedData) dDataSize = dNbOfBytesToDo; else dDataSize = *pdNbOfBytesDone;
		for(DWORD i=0;i<dDataSize;i++)
		{
			str.Format("%.2X ",*((BYTE*)pDataBuffer+i));
			strTraceLine += str;
		}

		p_rTraceLine = strTraceLine;
		oRes = TRUE;
	}

	return oRes;
}

BOOL CGatewayIToDrv::Trace_WriteLine(CStdString traceLine)
{
	char lineFeed = '\x0A';
	char carriageReturn = '\r';
	char data = 0;
	BOOL oResult = FALSE;

	if(m_TraceFileOpen)
	{
		for(int i=0;i<traceLine.GetLength();i++)
		{
			data = traceLine.GetAt(i);
			
			m_TraceFile << data;
		}

		m_TraceFile << carriageReturn << lineFeed;
	}

	return oResult;
}

BOOL CGatewayIToDrv::Trace_Close()
{
	BOOL oResult = FALSE;
	if(m_TraceFileOpen)
	{
		m_TraceFile.close();
		m_TraceFileOpen = FALSE;
		oResult = TRUE;
	}

	return oResult;

}
