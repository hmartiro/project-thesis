// GatewayUsbToHidDrv.h: Schnittstelle f�r die Klasse CGatewayUsbToHidDrv.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include <MmcDefinitions.h>
#ifdef _MMC_I_HID

#include <MmcTypeDefinition.h>
#include <Drv/Hid/MmcHidHndl.h>

//baudrate selection
const DWORD USB_BAUDRATE_1000000 = 1000000;

#include "../BaseClasses/GatewayIToDrv.h"
#include "Classes/HidDeviceInfoHandling.h"

class CCommand_I;
class COutReportThread;
class CInterfaceBase;
class CHidDeviceInfo;
class CHidDeviceInfoHandling;

class CGatewayUsbToHidDrv : public CGatewayIToDrv
{    
public:
    CGatewayUsbToHidDrv();
    virtual ~CGatewayUsbToHidDrv();

    virtual CGateway* Clone();
    CGatewayUsbToHidDrv& operator=(CGatewayUsbToHidDrv& p_rOther);

//Interne Struktur Funktionen
    virtual BOOL InitPort(WORD p_usBoardNumber, WORD p_usNbBoardWithOldDriver);
    virtual BOOL UpdatePort(tPortList& p_rOpenPortList);

//Initialisation
    virtual BOOL OpenPort(CStdString p_PortName, CErrorInfo* p_pErrorInfo = 0);
    virtual BOOL ReopenPort(CStdString p_PortName, CErrorInfo* p_pErrorInfo = 0);
    virtual BOOL ClosePort(CErrorInfo* p_pErrorInfo = 0);

//Hilfsfunktionen
    virtual BOOL ResetPort(CErrorInfo* p_pErrorInfo = 0);

//Setting Funktionen
    virtual BOOL SetPortSettings(DWORD p_ulBaudrate, DWORD p_ulTimeout, BOOL p_oChangeOnly, CErrorInfo* p_pErrorInfo = 0);
    virtual BOOL GetPortSettings(DWORD* p_pulBaudrate, DWORD* p_pulTimeout, CErrorInfo* p_pErrorInfo = 0);

    virtual BOOL SetPortMode(WORD p_usPortMode, CErrorInfo* p_pErrorInfo = 0);
    virtual BOOL GetPortMode(WORD* p_pusPortMode, CErrorInfo* p_pErrorInfo = 0);

//Name Funktionen
    virtual BOOL InitInterfacePortName(CStdString* p_InterfacePortName, WORD p_usBoardNumber, WORD p_usNbBoardWithOldDriver);
    virtual BOOL InitInterfaceName(CStdString* p_InterfaceName, WORD p_usBoardNumber, WORD p_usNbBoardWithOldDriver);

//Funktionalit�t
    virtual BOOL ProcessCommand(CCommandRoot*p_pCommand, CLayerManagerBase* p_pManager, HANDLE p_hHandle, HANDLE p_hTransactionHandle);

    BOOL WaitForOutReportData(DWORD p_ulTimeout);
    BOOL UpdateOutReport();

    //UsbDeviceInfoHandling
    virtual BOOL InitUsbDeviceInfoHandling(CHidDeviceInfoHandling* p_pUsbDeviceInfoHandling);

private:
    //Initialisation
    BOOL InitBaudrateSelection();
    BOOL InitDefaultPortSettings();
    BOOL InitErrorHandling();

    //Settings
    BOOL ConfigurePortSettings(DWORD p_ulBaudrate, DWORD p_ulTimeout, BOOL p_oChangeOnly, CErrorInfo* p_pErrorInfo, BOOL p_oDoLock);
    BOOL ConfigurePortMode(WORD p_usPortMode, CErrorInfo* p_pErrorInfo, BOOL p_oDoLock);

    //Commands
    BOOL Process_ReadData(CCommand_I* p_pCommand);
    BOOL Process_WriteData(CCommand_I* p_pCommand);
    BOOL Process_Rescan(CCommand_I* p_pCommand);
    BOOL Process_Reload(CCommand_I* p_pCommand);

    BOOL PurgeBuffer();
    BOOL SetTimeout(DWORD p_ulTimeout);
    BOOL SetBaudrate(DWORD p_ulBaudrate);
    BOOL ReadReport(BYTE* p_pDataBuffer, DWORD p_ulNbOfBytesToRead, DWORD* p_pulNbOfBytesRead, CErrorInfo* p_pErrorInfo = 0);
    BOOL WriteData(void* p_pDataBuffer, DWORD p_ulNbOfBytesToWrite, DWORD* p_pulNbOfBytesWritten, DWORD p_ulMaxRetry, CErrorInfo* p_pErrorInfo = 0);
    BOOL WriteReport(BYTE* p_pDataBuffer, DWORD p_ulNbOfBytesToWrite, DWORD* p_pulNbOfBytesWritten, CErrorInfo* p_pErrorInfo = 0);
    BOOL Rescan(CErrorInfo* p_pErrorInfo = 0);
    BOOL Reload(WORD p_usVendorId, WORD p_usProductId, CErrorInfo* p_pErrorInfo = 0);

    //DeviceInfos
    BOOL UpdatePortList(CHidDeviceInfoHandling* pDeviceInfoHandling);
    BOOL GetLocationId(CStdString p_PortName, CStdString& p_rDevicePath, DWORD& p_rulLocationId);
    BOOL UpdateLocationId(CHidDeviceInfoHandling* pDeviceInfoHandling, CStdString p_PortName, CStdString& p_rDevicePath, DWORD& p_rulLocationId);
    BOOL GetDeviceInfos(tHidDeviceInfoList& p_rDeviceInfoList);
    BOOL DeleteDeviceInfoList(tHidDeviceInfoList& p_rDeviceInfoList);
    BOOL UpdateInstance(CHidDeviceInfoHandling* pThreadInstance);
    BOOL UpdatePortLocked(CStdString p_PortName, BOOL p_oLocked);
    
private:
    //UsbDeviceInfoHandling
    CHidDeviceInfoHandling* m_pUsbDeviceInfoHandling;
	CMmcHidHndl*			m_pHidHndl;				
	BOOL m_oUpdateLockedPort;
	BOOL m_oFirstInit;    
    //InReport
    BYTE m_pubInReport[54];
    BYTE m_ubInValue;
    BYTE m_pubOutReport[18];
    DWORD m_ulOutReportCount;
};
#endif //_MMC_I_HID
