// GatewayVectorToXLDrvLib.cpp: Implementierung der Klasse CGatewayVectorToXLDrvLib.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "GatewayVectorToXLDrvLib.h"
#ifdef _MMC_I_VECTOR

#include <malloc.h>
#include <Process/MmcProcess.h>
#include <Time/MmcHiResTimer.h>
#include <CommunicationModel/CommonLayer/Classes/Commands/Interface/BaseClasses/Command_I.h>
#include "../../../../CommonLayer/Classes/Commands/Interface/Command_I_CAN.h"
#include "../../../../Interface/BaseClasses/InterfaceManagerBase.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////
CGatewayVectorToXLDrvLib::CGatewayVectorToXLDrvLib()
{
	m_wPortMode = 0;

	InitErrorHandling();
	InitBaudrateSelection();
	InitDefaultPortSettings();
}

CGatewayVectorToXLDrvLib::~CGatewayVectorToXLDrvLib()
{
	
}

BOOL CGatewayVectorToXLDrvLib::InitBaudrateSelection()
{
	m_BaudrateSelection.clear();
	m_BaudrateSelection.push_back(1000000);
	m_BaudrateSelection.push_back(800000);
	m_BaudrateSelection.push_back(500000);
	m_BaudrateSelection.push_back(250000);
	m_BaudrateSelection.push_back(125000);
	m_BaudrateSelection.push_back(50000);
	m_BaudrateSelection.push_back(20000);

	return TRUE;
}

BOOL CGatewayVectorToXLDrvLib::InitDefaultPortSettings()
{
	m_dDefaultBaudrate = 1000000;
	m_dDefaultTimeout = 500;

	GetDefaultPortSettings(&m_dBaudrate,&m_dTimeout);

	return TRUE;
}

BOOL CGatewayVectorToXLDrvLib::IsPortNameSupported(CStdString strPortName)
{
	CStdString strName;
	//Prepare PortName
	if(strPortName.Find("CAN") == 0) strPortName.TrimLeft("CAN");
	strPortName = "CAN" + strPortName;

	for(CStdStringArray::iterator it=m_strPortArray.begin(); it!=m_strPortArray.end();it++)
	{
		strName = (*it);
		if(strName.CompareNoCase(strPortName) == 0)
		{
			return TRUE;
		}
	}

	return FALSE;
}

BOOL CGatewayVectorToXLDrvLib::ProcessCommand(CCommandRoot* pCommand, CLayerManagerBase* pManager, HANDLE h_Handle, HANDLE hTransactionHandle)
{
	CCommand_I* pCommand_I;

	if(CGateway::ProcessCommand(pCommand, pManager, h_Handle, hTransactionHandle))
	{
		if(CheckLayers(pCommand,pManager))
		{
			pCommand_I = (CCommand_I*)pCommand;

			switch(pCommand->GetCommandId())
			{
				case CAN_TRANSMIT_CAN_FRAME: return Process_TransmitCanFrame(pCommand_I);
				case CAN_RECEIVE_CAN_FRAME: return Process_ReceiveCanFrame(pCommand_I);
				case CAN_RECEIVE_FILTERED_CAN_FRAME: return Process_ReceiveFilteredCanFrame(pCommand_I);
			}
		}
	}

	return FALSE;
}

BOOL CGatewayVectorToXLDrvLib::Process_TransmitCanFrame(CCommand_I* pCommand)
{
	BOOL oResult = FALSE;

	//*Constants I*
	const int k_ParameterIndex_CobId = 0;
	const int k_ParameterIndex_Rtr = 1;
	const int k_ParameterIndex_Dlc = 2;
	const int k_ParameterIndex_Data = 3;

	//*Variables I*
	//Parameter
	DWORD dCobId;
	BYTE oRtr;
	BYTE uDlc;
	void* pDataBuffer = NULL;
	DWORD dDataBufferLength;

	CErrorInfo errorInfo;

	if(pCommand)
	{
		//Lock CriticalSection
		if(!Lock(pCommand->GetTimeout())) return FALSE;

		//Prepare DataBuffer
		dDataBufferLength = pCommand->GetParameterLength(k_ParameterIndex_Data);
		if(dDataBufferLength > 0) pDataBuffer = malloc(dDataBufferLength);

		//Get I Parameter Data
		pCommand->GetParameterData(k_ParameterIndex_CobId,&dCobId,sizeof(dCobId));
		pCommand->GetParameterData(k_ParameterIndex_Rtr,&oRtr,sizeof(oRtr));
		pCommand->GetParameterData(k_ParameterIndex_Dlc,&uDlc,sizeof(uDlc));
		pCommand->GetParameterData(k_ParameterIndex_Data,pDataBuffer,dDataBufferLength);

		//Execute Command
		oResult = TransmitCanFrame(dCobId,oRtr,uDlc,pDataBuffer,dDataBufferLength,&errorInfo);

		//Set PS ReturnParameter Data
		pCommand->SetStatus(oResult,&errorInfo);

		//Free DataBuffer
		if(pDataBuffer) free(pDataBuffer);

		//Unlock CriticalSection
		Unlock();
	}

	return oResult;
}

BOOL CGatewayVectorToXLDrvLib::Process_ReceiveCanFrame(CCommand_I* pCommand)
{
	//*Constants I*
	const int k_ReturnParameterIndex_CobId = 0;
	const int k_ReturnParameterIndex_Rtr = 1;
	const int k_ReturnParameterIndex_Dlc = 2;
	const int k_ReturnParameterIndex_Data = 3;

	//*Variables I*
	//Parameter
	DWORD dTimeout;
	//ReturnParamter
	DWORD dCobId;
	BOOL oRtr;
	BYTE uDlc;
	void* pDataBuffer = NULL;
	DWORD dDataBufferLength;

	BOOL oResult = FALSE;
	CErrorInfo errorInfo;

	if(pCommand)
	{
		//Lock CriticalSection
		if(!Lock(pCommand->GetTimeout())) return FALSE;

		//Get I Parameter Data
		if(pCommand->IsTimeoutValid()) dTimeout = pCommand->GetTimeout(); else dTimeout = m_dTimeout;

		//Execute Command
		oResult = ReceiveCanFrame(dTimeout,&dCobId,&oRtr,&uDlc,&pDataBuffer,&dDataBufferLength,&errorInfo);

		//Set I ReturnParameter Data
		pCommand->SetStatus(oResult,&errorInfo);
		pCommand->SetReturnParameterData(k_ReturnParameterIndex_CobId,&dCobId,sizeof(dCobId));
		pCommand->SetReturnParameterData(k_ReturnParameterIndex_Rtr,&oRtr,sizeof(oRtr));
		pCommand->SetReturnParameterData(k_ReturnParameterIndex_Dlc,&uDlc,sizeof(uDlc));
		pCommand->SetReturnParameterData(k_ReturnParameterIndex_Data,pDataBuffer,dDataBufferLength);

		//Free DataBuffer
		if(pDataBuffer) free(pDataBuffer);

		//Unlock CriticalSection
		Unlock();
	}

	return oResult;
}

BOOL CGatewayVectorToXLDrvLib::Process_ReceiveFilteredCanFrame(CCommand_I* pCommand)
{
	//*Constants I*
	const int k_ParameterIndex_CobId = 0;
	const int k_ParameterIndex_Rtr = 1;

	const int k_ReturnParameterIndex_CobId = 0;
	const int k_ReturnParameterIndex_Rtr = 1;
	const int k_ReturnParameterIndex_Dlc = 2;
	const int k_ReturnParameterIndex_Data = 3;
	BOOL oResult = FALSE;
	//*Variables I*
	//Parameter
	DWORD dCobIdFilter;
	BYTE oRtrFilter;
	DWORD dTimeout;

	//ReturnParamter
	DWORD dCobId;
	BOOL oRtr;
	BYTE uDlc;
	void* pDataBuffer = NULL;
	DWORD dDataBufferLength;

	CErrorInfo errorInfo;

	if(pCommand)
	{
		//Lock CriticalSection
		if(!Lock(pCommand->GetTimeout())) return FALSE;

		//Get I Parameter Data
		pCommand->GetParameterData(k_ParameterIndex_CobId,&dCobIdFilter,sizeof(dCobIdFilter));
		pCommand->GetParameterData(k_ParameterIndex_Rtr,&oRtrFilter,sizeof(oRtrFilter));
		if(pCommand->IsTimeoutValid()) dTimeout = pCommand->GetTimeout(); else dTimeout = m_dTimeout;

		//Execute Command
		oResult = ReceiveFilteredCanFrame(dCobIdFilter,oRtrFilter,dTimeout,&dCobId,&oRtr,&uDlc,&pDataBuffer,&dDataBufferLength,&errorInfo);

		//Set I ReturnParameter Data
		pCommand->SetStatus(oResult,&errorInfo);
		pCommand->SetReturnParameterData(k_ReturnParameterIndex_CobId,&dCobIdFilter,sizeof(dCobIdFilter));
		pCommand->SetReturnParameterData(k_ReturnParameterIndex_Rtr,&oRtrFilter,sizeof(oRtrFilter));
		pCommand->SetReturnParameterData(k_ReturnParameterIndex_Dlc,&uDlc,sizeof(uDlc));
		pCommand->SetReturnParameterData(k_ReturnParameterIndex_Data,pDataBuffer,dDataBufferLength);

		//Free DataBuffer
		if(pDataBuffer) free(pDataBuffer);

		//Unlock CriticalSection
		Unlock();
	}

	return oResult;
}

BOOL CGatewayVectorToXLDrvLib::TransmitCanFrame(DWORD dCobId,BOOL oRtr,BYTE uDlc,void* pDataBuffer,DWORD dDataBufferLength,CErrorInfo* pErrorInfo)
{
	//ResetErrorInfo
	if(pErrorInfo) pErrorInfo->Reset();

	if(!m_VectorHndl.TransmitCanFrame(dCobId,oRtr,uDlc,pDataBuffer,dDataBufferLength))
	{
		if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_ExecutingCommand,pErrorInfo);
		return FALSE;

	}
	return TRUE;
}

BOOL CGatewayVectorToXLDrvLib::ReceiveCanFrame(DWORD dTimeout,DWORD* pdCobId,BOOL* poRtr,BYTE* puDlc,void** ppDataBuffer,DWORD* pdDataBufferLength,CErrorInfo* pErrorInfo)
{
	//ResetErrorInfo
	if(pErrorInfo) pErrorInfo->Reset();

	if(!m_VectorHndl.ReceiveCanFrame(dTimeout,pdCobId,poRtr,puDlc,ppDataBuffer,pdDataBufferLength))
	{
		if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_ExecutingCommand,pErrorInfo);
		return FALSE;

	}
	return TRUE;
}

BOOL CGatewayVectorToXLDrvLib::ReceiveFilteredCanFrame(DWORD dCobIdFilter,BOOL oRtrFilter,DWORD dTimeout,DWORD* pdCobId,BOOL* poRtr,BYTE* puDlc,void** ppDataBuffer,DWORD* pdDataBufferLength,CErrorInfo* pErrorInfo)
{
	//ResetErrorInfo
	if(pErrorInfo) pErrorInfo->Reset();

	if(!m_VectorHndl.ReceiveFilteredCanFrame(dCobIdFilter,oRtrFilter,dTimeout,pdCobId,poRtr,puDlc,ppDataBuffer,pdDataBufferLength))
	{
		if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_ExecutingCommand,pErrorInfo);
		return FALSE;

	}
	return TRUE;
}

CGateway* CGatewayVectorToXLDrvLib::Clone()
{
	CGatewayVectorToXLDrvLib* pClonedGateway;

	pClonedGateway = new CGatewayVectorToXLDrvLib();
	*pClonedGateway = *this;

	return pClonedGateway;
}

CGatewayVectorToXLDrvLib& CGatewayVectorToXLDrvLib::operator=(CGatewayVectorToXLDrvLib& other)
{
	if(this != &other)
	{
		*((CGatewayIToDrv*)this) = *((CGatewayIToDrv*)&other);

	}

	return *this;
}

//********************************************************************
BOOL CGatewayVectorToXLDrvLib::OpenPort(CStdString strPortName,CErrorInfo* pErrorInfo)
{
	if(!m_VectorHndl.OpenPort())
	{
		if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_I_OpeningPort,pErrorInfo);
		return FALSE;
	}
	
	return TRUE;
}

//********************************************************************
BOOL CGatewayVectorToXLDrvLib::ClosePort(CErrorInfo* pErrorInfo)
{
	if( !m_VectorHndl.ClosePort() )
	{
		if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_I_PortNotOpen,pErrorInfo);

		return false;
	}

	return true;
}

//********************************************************************
BOOL CGatewayVectorToXLDrvLib::InitPort(WORD wBoardNumber,WORD wNbBoardWithOldDriver)
{
	BOOL oResult = FALSE;
	
	vector<CStdString> ports = m_VectorHndl.InitPort(wBoardNumber);

	for( vector<CStdString>::iterator it=ports.begin(); it!=ports.end(); it++)
		AddPortList((*it));

	return m_strPortArray.size() > 0;
}

//********************************************************************
BOOL CGatewayVectorToXLDrvLib::ResetPort(CErrorInfo* pErrorInfo)
{
	if( !m_VectorHndl.ResetPort() )
	{
		if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_I_ResetPort,pErrorInfo);
		return false;
	}
		
	return true;
}

BOOL CGatewayVectorToXLDrvLib::CheckStatusAndReset()
{	
	return m_VectorHndl.CheckStatusAndReset() ? TRUE : FALSE;
}

//********************************************************************
BOOL CGatewayVectorToXLDrvLib::GetPortSettings(DWORD* pdBaudrate,DWORD* pdTimeout,CErrorInfo* pErrorInfo)
{
	if(pdBaudrate) *pdBaudrate = m_dBaudrate;
	if(pdTimeout) *pdTimeout = m_dTimeout;

	return TRUE;
}

//********************************************************************
BOOL CGatewayVectorToXLDrvLib::GetPortMode(WORD* pwPortMode,CErrorInfo* pErrorInfo)
{
	if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal,pErrorInfo);
	return FALSE;
}

//********************************************************************
BOOL CGatewayVectorToXLDrvLib::SetPortSettings(DWORD dBaudrate,DWORD dTimeout,BOOL oChangeOnly,CErrorInfo* pErrorInfo)
{
	m_dBaudrate = dBaudrate;
	m_dTimeout = dTimeout;

	if( !m_VectorHndl.SetPortSettings(dBaudrate,dTimeout) )
	{
		if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_I_SetPortSettings,pErrorInfo);	

		return FALSE;
	}

	return TRUE;
}

//********************************************************************
BOOL CGatewayVectorToXLDrvLib::SetPortMode(WORD wPortMode,CErrorInfo* pErrorInfo)
{
	if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal,pErrorInfo);
	return FALSE;
}

//********************************************************************
BOOL CGatewayVectorToXLDrvLib::InitInterfaceName(CStdString* pStrInterfaceName,WORD wBoardNumber,WORD wNbBoardWithOldDriver)
{
	CStdString strInterfacePortName;

	if(InitInterfacePortName(&strInterfacePortName,wBoardNumber,wNbBoardWithOldDriver))
	{
		m_strInterfaceName = strInterfacePortName;
		if(pStrInterfaceName) *pStrInterfaceName = m_strInterfaceName;
		return TRUE;
	}

	return FALSE;
}

//********************************************************************
BOOL CGatewayVectorToXLDrvLib::InitInterfacePortName(CStdString* pStrInterfacePortName,WORD wBoardNumber,WORD wNbBoardWithOldDriver)
{
	CStdString strInterfacePortName = m_VectorHndl.GetInterfacePortName(wBoardNumber);
	
	if( strInterfacePortName.IsEmpty() )
	{
		m_strInterfacePortName = strInterfacePortName;

		if(pStrInterfacePortName) *pStrInterfacePortName = strInterfacePortName;

		return TRUE;
	}
	
	return FALSE;
}

//********************************************************************
BOOL CGatewayVectorToXLDrvLib::InitErrorHandling()
{
	CErrorProducer errorProducer;
	CStdString strClassName = "GatewayVectorToXLDrvLib";

	if(m_pErrorHandling)
	{
		//Init ErrorProducer
		errorProducer.Init(INTERFACE_LAYER,strClassName);
		m_pErrorHandling->InitErrorProducer(&errorProducer);
		return TRUE;
	}

	return FALSE;
}

//********************************************************************
WORD CGatewayVectorToXLDrvLib::GetNbOfAvailableBoards()
{	
	return m_VectorHndl.GetNbOfAvailableBoards();
}
#endif //_MMC_I_VECTOR
