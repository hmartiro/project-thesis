// PortBase.h: Schnittstelle f�r die Klasse CPortBase.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PORTBASE_H__489D7B2F_6A13_49FA_BE0D_0FCFF7F656F1__INCLUDED_)
#define AFX_PORTBASE_H__489D7B2F_6A13_49FA_BE0D_0FCFF7F656F1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <list>
#include <CommunicationModel/CommonLayer/ErrorHandling/ErrorInfo.h>
#include <CommunicationModel/CommonLayer/ErrorHandling/ErrorHandling.h>

class CJournalManagerBase;
class CGatewayIToDrv;
class CCommandRoot;
class CPortBase;

typedef std::list<CPortBase*> tPortList;

class CPortBase
{
public:
	CPortBase();
    CPortBase(const CPortBase& rObject);
    virtual ~CPortBase();
    virtual CPortBase* Clone();
	virtual BOOL IsEqual(CStdString p_PortName);

//Interne Struktur Funktionen
    virtual BOOL InitPort(WORD wBoardNumber, WORD wNbBoardWithOldDriver);
    virtual BOOL InitGateway(CGatewayIToDrv* pGateway);
    virtual BOOL InitBaudrateSelection(CStdDWordArray& dBaudrateSel);
    virtual BOOL InitDefaultPortSettings(DWORD dBaudrate, DWORD dTimeout);
    virtual BOOL UpdatePort(tPortList& p_rOpenPortList);
    virtual BOOL ReopenPort(CErrorInfo* pErrorInfo = NULL);

//Initialisation
    virtual BOOL OpenPort(CStdString strPortName, CErrorInfo* pErrorInfo = NULL);
    virtual BOOL ClosePort(CErrorInfo* pErrorInfo = NULL);

//Hilfsfunktionen
    virtual BOOL GetDefaultPortSettings(DWORD* pdBaudrate, DWORD* pdTimeout, CErrorInfo* pErrorInfo = NULL);
    virtual BOOL ResetPort(CErrorInfo* pErrorInfo = NULL);
    virtual BOOL IsPortNameSupported(CStdString strPortName);
    virtual BOOL SetDefaultPortSettings(DWORD dBaudrate, DWORD dTimeout, CErrorInfo* pErrorInfo = NULL);

//Selection Funktionen
    virtual BOOL GetPortNameSelection(CStdStringArray* pPortSel, CErrorInfo* pErrorInfo = NULL);
    virtual BOOL GetBaudrateSelection(CStdDWordArray* pdBaudrateSel, CErrorInfo* pErrorInfo = NULL);
    virtual BOOL GetPortModeSelection(CStdStringArray* pPortModeSel, CErrorInfo* pErrorInfo = NULL);

//Setting Funktionen
    virtual BOOL GetPortSettings(DWORD* pdBaudrate, DWORD* pdTimeout, CErrorInfo* pErrorInfo = NULL);
    virtual BOOL SetPortSettings(DWORD dBaudrate, DWORD dTimeout, BOOL oChangeOnly, CErrorInfo* pErrorInfo = NULL);

    virtual BOOL GetPortMode(WORD* pwPortMode, CErrorInfo* pErrorInfo = NULL);
    virtual BOOL SetPortMode(WORD wPortMode, CErrorInfo* pErrorInfo = NULL);

//Name Funktionen
    virtual BOOL GetPortName(CStdString* pPortName);
    virtual BOOL GetInterfacePortName(CStdString* pInterfacePortName);
    virtual BOOL InitInterfacePortName(WORD wBoardNumber = 0, WORD wNbBoardWithOldDriver = 0);

//Funktionalit�t
    virtual BOOL ExecuteCommand(CCommandRoot* pCommand, HANDLE hTransactionHandle);
    virtual BOOL GetCommands(CStdString* pCommandInfo);

//JournalManager
    virtual BOOL InitJournalManager(HANDLE hHandle, CJournalManagerBase* pJournalManager);
    virtual BOOL ResetJournalManager(HANDLE hHandle);
    virtual void InitJournalManager(CJournalManagerBase *pJournalManager);
    virtual void ResetJournalManager();

//Tracing
    virtual BOOL EnableTracing(CStdString p_FileName, CErrorInfo* pErrorInfo = NULL);
    virtual BOOL DisableTracing(CErrorInfo* pErrorInfo = NULL);

//ErrorHandling
    virtual BOOL InitErrorHandling();
    virtual BOOL DeleteErrorHandling();

//Parameter
	BOOL AreParameterEqual(CPortBase* p_pDevice);
    BOOL SetParameter(CStdString p_Name, BYTE* p_pValue, DWORD p_ulSize);
	BOOL SetParameter(CStdString p_Name, CStdString p_Value);
	BOOL GetParameter(CStdString p_Name, BYTE* p_pValue, DWORD p_ulSize);
	BOOL GetParameter(CStdString p_Name, CStdString& p_rValue);

//Critical Section
    BOOL Lock(DWORD p_ulTimeout = -1);
    BOOL Unlock();
    BOOL IsLocked();

protected:
    void DeleteGateway();

    CErrorHandling* m_pErrorHandling;
    CGatewayIToDrv* m_pGateway;
    CJournalManagerBase* m_pJournalManager;
    CStdString m_strInterfacePortName;
    CStdString m_strPortName;
};

#endif // !defined(AFX_PORTBASE_H__489D7B2F_6A13_49FA_BE0D_0FCFF7F656F1__INCLUDED_)
