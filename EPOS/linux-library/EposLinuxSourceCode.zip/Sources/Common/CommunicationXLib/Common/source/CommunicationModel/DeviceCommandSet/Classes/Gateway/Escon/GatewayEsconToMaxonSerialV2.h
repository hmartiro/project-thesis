// GatewayEsconToMaxonSerialV2.h: Schnittstelle f�r die Klasse CGatewayEsconToMaxonSerialV2.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include <CommunicationModel/Common/CommunicationModelDefinitions.h>
#ifdef _MMC_DCS_ESCON
#ifdef _MMC_PS_MAXON_SERIAL_V2

#include "../BaseClasses/GatewayDCStoPS.h"
class CCommand_PS_MaxonSerialV2;

class CGatewayEsconToMaxonSerialV2 : public CGatewayDCStoPS
{
public:
    CGatewayEsconToMaxonSerialV2();
    virtual ~CGatewayEsconToMaxonSerialV2();

    virtual CGateway* Clone();
    CGatewayEsconToMaxonSerialV2& operator=(CGatewayEsconToMaxonSerialV2& other);

    virtual BOOL ProcessCommand(CCommandRoot*pCommand, CLayerManagerBase* pManager, HANDLE h_Handle, HANDLE hTransactionHandle);

private:
    void DeleteCommands();
    void InitCommands();

    BOOL Process_ReadObject(CCommand_DCS* pCommand, CProtocolStackManagerBase* pProtocolStackManager, HANDLE hPS_Handle, HANDLE hTransactionHandle);
    BOOL Process_WriteObject(CCommand_DCS* pCommand, CProtocolStackManagerBase* pProtocolStackManager, HANDLE hPS_Handle, HANDLE hTransactionHandle);
    BOOL Process_InitiateSegmentedRead(CCommand_DCS* pCommand, CProtocolStackManagerBase* pProtocolStackManager, HANDLE hPS_Handle, HANDLE hTransactionHandle);
    BOOL Process_InitiateSegmentedWrite(CCommand_DCS* pCommand, CProtocolStackManagerBase* pProtocolStackManager, HANDLE hPS_Handle, HANDLE hTransactionHandle);
    BOOL Process_SegmentRead(CCommand_DCS* pCommand, CProtocolStackManagerBase* pProtocolStackManager, HANDLE hPS_Handle, HANDLE hTransactionHandle);
    BOOL Process_SegmentWrite(CCommand_DCS* pCommand, CProtocolStackManagerBase* pProtocolStackManager, HANDLE hPS_Handle, HANDLE hTransactionHandle);
    BOOL Process_AbortSegmentedTransfer(CCommand_DCS* pCommand, CProtocolStackManagerBase* pProtocolStackManager, HANDLE hPS_Handle, HANDLE hTransactionHandle);

    BOOL PS_ProcessProtocol(CProtocolStackManagerBase* pProtocolStackManager, HANDLE hPS_Handle, HANDLE hTransactionHandle, BYTE uOpCode, void* pDataBuffer, DWORD dDataBufferLength, BYTE ubKeepLock, void** ppRetDataBuffer, DWORD* pdRetDataBufferLength, CErrorInfo* p_pErrorInfo = 0);
    BOOL PS_AbortProtocol(CProtocolStackManagerBase* pProtocolStackManager, HANDLE hPS_Handle, HANDLE hTransactionHandle, CErrorInfo* p_pErrorInfo = 0);

    //Layer Parameter Stack
    BOOL InitLayerParameterStack(CCommandRoot* p_pCommand);

    BOOL EvaluateErrorCode(BOOL oResult, DWORD dDeviceErrorCode, CErrorInfo* pComErrorInfo, CErrorInfo* pCmdErrorInfo);

    BOOL CopyData(void*& pDest, void* pSource, DWORD sourceSize);
    BOOL CopyReturnData(void* pDest, DWORD destSize, void*& pSource, DWORD& sourceSize);

    BOOL InitErrorHandling();

private:
    CCommand_PS_MaxonSerialV2* m_pCommand_ProcessProtocol;
    CCommand_PS_MaxonSerialV2* m_pCommand_AbortProtocol;
};
#endif //_MMC_PS_MAXON_SERIAL_V2
#endif //_MMC_DCS_ESCON
