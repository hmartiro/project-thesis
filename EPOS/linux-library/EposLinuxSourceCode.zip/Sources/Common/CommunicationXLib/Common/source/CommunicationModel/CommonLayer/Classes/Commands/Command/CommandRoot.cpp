// Command.cpp: Implementierung der Klasse CCommandRoot.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include <Classes/MmcDataConversion.h>
#include <CommunicationModel/Common/Journal/Time/JournalTime.h>
#include <CommunicationModel/Common/Journal/BaseClasses/JournalManagerBase.h>
#include "ParameterInfo/ParameterInfo.h"
#include <CommunicationModel/CommonLayer/Classes/Commands/Command/LayerParameter/LayerParameterStack.h>
#include "../../Gateway/Gateway.h"
#include <CommunicationModel/CommonLayer/Classes/Commands/Command/CommandRoot.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

CCommandRoot::CCommandRoot()
{
    m_oTransactionEventEnabled = TRUE;
	m_pErrorInfo = NULL;
    m_pParameterInfo = new CParameterInfo();
	m_pLayerParameterStack = new CLayerParameterStack();
    m_pJournalTime = new CJournalTime();
    ResetCommand();
}

CCommandRoot::~CCommandRoot()
{
    if(m_pParameterInfo)
    {
        delete m_pParameterInfo;
        m_pParameterInfo = NULL;
    }

	if(m_pLayerParameterStack)
    {
        delete m_pLayerParameterStack;
        m_pLayerParameterStack = NULL;
    }

	if(m_pJournalTime)
    {
        delete m_pJournalTime;
        m_pJournalTime = NULL;
    }

    ResetErrorInfo();
}

void CCommandRoot::ResetErrorInfo()
{
    if(m_pErrorInfo)
    {
        delete m_pErrorInfo;
        m_pErrorInfo = NULL;
    }
}

//******************************************************************
BOOL CCommandRoot::SetTimeout(DWORD timeout)
{
    BOOL oResult = TRUE;

    m_dTimeout = timeout;

    return oResult;
}

BOOL CCommandRoot::ResetTimeout()
{
    BOOL oResult = TRUE;

    m_dTimeout = UINT_MAX;

    return oResult;
}

//******************************************************************
DWORD CCommandRoot::GetTimeout()
{
    return m_dTimeout;
}

//******************************************************************
BOOL CCommandRoot::IsTimeoutValid()
{
    return (m_dTimeout != UINT_MAX);
}

//********************************************************************
void CCommandRoot::AddParameter(int lParameterIndex, CStdString parameterName, EObjectDataType eParameterType)
{
    if(m_pParameterInfo)
    {
        m_pParameterInfo->AddParameter(lParameterIndex, parameterName, eParameterType);
    }
}

//********************************************************************
void CCommandRoot::AddParameter(int lParameterIndex, CStdString parameterName, EObjectDataType eParameterType, BOOL oVisible, BOOL oEditable)
{
    if(m_pParameterInfo)
    {
        m_pParameterInfo->AddParameter(lParameterIndex, parameterName, eParameterType, oVisible, oEditable);
    }
}

//********************************************************************
void CCommandRoot::AddParameter(int lParameterIndex, CStdString parameterName, EObjectDataType eParameterType, DWORD dArraySize)
{
    if(m_pParameterInfo)
    {
        m_pParameterInfo->AddParameter(lParameterIndex, parameterName, eParameterType, dArraySize);
    }
}

//********************************************************************
void CCommandRoot::AddParameter(int lParameterIndex, CStdString parameterName, EObjectDataType eParameterType, DWORD dArraySize, BOOL oVisible, BOOL oEditable)
{
    if(m_pParameterInfo)
    {
        m_pParameterInfo->AddParameter(lParameterIndex, parameterName, eParameterType, oVisible, oEditable);
    }
}

//********************************************************************
void CCommandRoot::AddReturnParameter(int lParameterIndex, CStdString parameterName, EObjectDataType eParameterType)
{
    if(m_pParameterInfo)
    {
        m_pParameterInfo->AddReturnParameter(lParameterIndex, parameterName, eParameterType);
    }
}

//********************************************************************
void CCommandRoot::AddReturnParameter(int lParameterIndex, CStdString parameterName, EObjectDataType eParameterType, BOOL oVisible)
{
    if(m_pParameterInfo)
    {
        m_pParameterInfo->AddReturnParameter(lParameterIndex, parameterName, eParameterType, oVisible);
    }
}

//********************************************************************
void CCommandRoot::AddReturnParameter(int lParameterIndex, CStdString parameterName, EObjectDataType eParameterType, DWORD dArraySize)
{
    if(m_pParameterInfo)
    {
        m_pParameterInfo->AddReturnParameter(lParameterIndex, parameterName, eParameterType, dArraySize);
    }
}

//********************************************************************
void CCommandRoot::AddReturnParameter(int lParameterIndex, CStdString parameterName, EObjectDataType eParameterType, DWORD dArraySize, BOOL oVisible)
{
    if(m_pParameterInfo)
    {
        m_pParameterInfo->AddReturnParameter(lParameterIndex, parameterName, eParameterType, oVisible);
    }
}

//********************************************************************
CCommandRoot* CCommandRoot::CloneCommand()
{
    CCommandRoot* pNewCommand;

    pNewCommand = new CCommandRoot();
    *pNewCommand = *this;

    return pNewCommand;
}

//******************************************************************
BOOL CCommandRoot::DoTransactionEvent(HANDLE hTransactionHandle)
{
    if(hTransactionHandle != 0 && m_oTransactionEventEnabled)
    {
        if(m_pJournalManager)
        {
            return m_pJournalManager->TransactionEvent(m_eLayer, hTransactionHandle, this);
        }
    }

    return FALSE;
}

BOOL CCommandRoot::EnableTransactionEvent(BOOL p_oEnabled)
{
	m_oTransactionEventEnabled = p_oEnabled;
	return TRUE;
}

//***********************************************************************************
BOOL CCommandRoot::Execute(CLayerManagerBase* pManager, HANDLE h_Handle, HANDLE hTransactionHandle)
{
    BOOL oResult = FALSE;

    if(m_pGateway)
    {
        //Start Time
        StartCommandTime();

        //Process Command
        oResult = m_pGateway->ProcessCommand(this, pManager, h_Handle, hTransactionHandle);

        //Stop Time
        StopCommandTime();

        //Transaction Event
        DoTransactionEvent(hTransactionHandle);

		//Update SubLayer Lock State
		m_oSubLayerRemainsLocked = m_pGateway->IsLocked();
	
    }

    return oResult;
}

//******************************************************************
CStdString CCommandRoot::GetCommandName()
{
    return m_CommandName;
}

//******************************************************************
ELayer CCommandRoot::GetLayer()
{
    return m_eLayer;
}

//******************************************************************
CStdString CCommandRoot::GetJournalRunTimeString()
{
    //Actual Run Time
    if(m_pJournalTime)
    {
        return m_pJournalTime->GetJournalRunTimeString();
    }
    return "";
}

//******************************************************************
CStdString CCommandRoot::GetCommandTimeString()
{
    if(m_pJournalTime)
    {
        return m_pJournalTime->GetCommandTimeString();
    }
    return "";
}

//******************************************************************
void CCommandRoot::SetCommandTime(CStdString* pCommandTime)
{
    if(m_pJournalTime)
    {
        m_pJournalTime->SetCommandTime(pCommandTime);
    }
}

//******************************************************************
void CCommandRoot::SetJournalRunTime(CStdString* pJournalRunTime)
{
    if(m_pJournalTime)
    {
        m_pJournalTime->SetJournalRunTime(pJournalRunTime);
    }
}

//********************************************************************
void CCommandRoot::InitCommand(CStdString commandName, ELayer eLayer, DWORD dCommandId)
{
    m_CommandName = commandName;
    m_eLayer = eLayer;
    m_dCommandId = dCommandId;
}

//********************************************************************
BOOL CCommandRoot::InitCommandName(CStdString commandName)
{
    m_CommandName = commandName;
    return TRUE;
}

//********************************************************************
BOOL CCommandRoot::InitLayer(CStdString strLayer)
{
    if(strLayer.CompareNoCase(VIRTUAL_COMMAND_SET_LAYER_STRING) == 0)
    {
        m_eLayer = VIRTUAL_COMMAND_SET_LAYER;
        return TRUE;
    }
    else if(strLayer.CompareNoCase(COMMAND_SET_LAYER_STRING) == 0)
    {
        m_eLayer = DEVICE_COMMAND_SET_LAYER;
        return TRUE;
    }
    else if(strLayer.CompareNoCase(PROTOCOL_STACK_LAYER_STRING) == 0)
    {
        m_eLayer = PROTOCOL_STACK_LAYER;
        return TRUE;
    }
    else if(strLayer.CompareNoCase(INTERFACE_LAYER_STRING) == 0)
    {
        m_eLayer = INTERFACE_LAYER;
        return TRUE;
    }

    m_eLayer = NO_LAYER;
	return FALSE;
}

//********************************************************************
BOOL CCommandRoot::InitCommandId(CStdString strCommandId)
{
    CMmcDataConversion dataConversion;

    return dataConversion.DecDWordStr2DWord(strCommandId, &m_dCommandId, FALSE);
}

//********************************************************************
void CCommandRoot::StartCommandTime()
{
    if(m_pJournalManager)
    {
        m_pJournalManager->StartCommandTime(m_pJournalTime);
    }
}

//********************************************************************
void CCommandRoot::StopCommandTime()
{
    if(m_pJournalManager)
    {
        m_pJournalManager->StopCommandTime(m_pJournalTime);
    }
}
//********************************************************************
BOOL CCommandRoot::LoadFromXMLFile(CXXMLFile* pFile, CXXMLFile::CElement* pCommandElement)
{
    CXXMLFile::CElement* pParameterInfoElement;
    CXXMLFile::CElementPart* pElementPart;
    std::list<CXXMLFile::CElementPart*> childList;
    CStdString sJournalRunTime;
    CStdString sCommandTime;
    CStdString sCmdStatus;
    CStdString sCmdName;
    CStdString sCmdLayer;
    CStdString sCmdId;
    CStdString sCmdErrorCode;

    if(pFile && pCommandElement)
    {
        if(pCommandElement->m_Text.CompareNoCase("Command") == 0)
        {
            //Command Elements
			tMmcStringToStringMap::iterator it;

			if((it=pCommandElement->AttributeToValue.find("Name")) == pCommandElement->AttributeToValue.end() )
				return FALSE;
			
			sCmdName = (*it).second;
			
			if(!InitCommandName(sCmdName)) return FALSE;

			if((it=pCommandElement->AttributeToValue.find("Layer")) == pCommandElement->AttributeToValue.end() )
				return FALSE;

            if(!InitLayer(sCmdLayer)) 
				return FALSE;
			
			sCmdLayer = (*it).second;

			if((it=pCommandElement->AttributeToValue.find("CommandId")) == pCommandElement->AttributeToValue.end() )
				return FALSE;

			sCmdId = (*it).second;

            if(!InitCommandId(sCmdId)) return FALSE;

            //Status
            if((it=pCommandElement->AttributeToValue.find("Status")) != pCommandElement->AttributeToValue.end() )
				sCmdStatus = (*it).second;

			if((it=pCommandElement->AttributeToValue.find("ErrorCode")) != pCommandElement->AttributeToValue.end() )
				sCmdErrorCode = (*it).second;
            
            InitCommandStatus(sCmdStatus, sCmdErrorCode);

            //Time
			if((it=pCommandElement->AttributeToValue.find("JournalRunTime")) != pCommandElement->AttributeToValue.end() )
				sJournalRunTime = (*it).second;

			if((it=pCommandElement->AttributeToValue.find("CommandDuration")) != pCommandElement->AttributeToValue.end() )
				sCommandTime = (*it).second;

            SetJournalRunTime(&sJournalRunTime);
            SetCommandTime(&sCommandTime);

            //ParameterInfo Element
            for(std::list<CXXMLFile::CElementPart*>::iterator it=pCommandElement->begin();
				it!=pCommandElement->end(); it++)
            {
                pElementPart = (*it);
                if(pFile->IsElement(pElementPart))
                {
                    pParameterInfoElement = (CXXMLFile::CElement*)pElementPart;
                    if(pParameterInfoElement->m_Text.CompareNoCase("ParameterInfo") == 0)
                    {
                        if(m_pParameterInfo && !m_pParameterInfo->LoadFromXMLFile(pFile, pParameterInfoElement)) return FALSE;
                    }

                    return TRUE;
                }
            }
        }
    }

    return FALSE;
}

//********************************************************************
BOOL CCommandRoot::LoadFromXMLString(CStdString *pDataString)
{
    CXXMLFile file;
    CXXMLFile::CElement* pRootElement;
    CXXMLFile::CElement* pCommandElement;
    CXXMLFile::CElementPart* pElementPart;

    //Read XML File
    if(file.ReadFromString(pDataString))
    {
        //Root
        pElementPart = file.Root();
        if(file.IsElement(pElementPart))
        {
            pRootElement = (CXXMLFile::CElement*)pElementPart;
            pCommandElement = FindCommandElement(&file, pRootElement);
            if(pCommandElement)
            {
                return LoadFromXMLFile(&file, pCommandElement);
            }
        }
    }

    return FALSE;
}

//********************************************************************
CXXMLFile::CElement* CCommandRoot::FindCommandElement(CXXMLFile* pFile, CXXMLFile::CElement* pParentElement)
{
    if(pFile && pParentElement)
    {
		for(std::list<CXXMLFile::CElementPart*>::iterator it=pParentElement->begin();
				it!=pParentElement->end(); it++)
        {
            CXXMLFile::CElementPart* pElementPart = (*it);
            if(pFile->IsElement(pElementPart))
            {
                CXXMLFile::CElement* pElement = (CXXMLFile::CElement*)pElementPart;
                if(pElement->m_Text.CompareNoCase("Command") == 0)
                {
                    return pElement;
                }
                else
                {
                    pElement = FindCommandElement(pFile, pElement);
                    if(pElement) return pElement;
                }
            }
        }
    }

    return NULL;
}

//********************************************************************
CXXMLFile::CElement* CCommandRoot::DeleteCommandElement(CXXMLFile* pFile, CXXMLFile::CElement* pParentElement, CXXMLFile::CElement* pCommandElement)
{
    CXXMLFile::CElement* pElement;
     
    if(pFile && pParentElement && pCommandElement)
    {
		for(std::list<CXXMLFile::CElementPart*>::iterator it=pParentElement->begin();
				it!=pParentElement->end(); it++)			        
        {
            CXXMLFile::CElementPart* pElementPart = (*it);
            if(pFile->IsElement(pElementPart))
            {
                pElement = (CXXMLFile::CElement*)pElementPart;
                if(pElement == pCommandElement)
                {
                    if(pFile->DeleteElement(pParentElement, pElement))
                    {
                        return pParentElement;
                    }
                }
                else
                {
                    pElement = DeleteCommandElement(pFile, pElement, pCommandElement);
                    if(pElement) return pElement;
                }
            }
        }
    }

    return NULL;
}

//********************************************************************
CCommandRoot& CCommandRoot::operator=(CCommandRoot& other)
{
    if(this != &other)
    {
        ResetCommand();

        m_CommandName = other.m_CommandName;
        m_dCommandId = other.m_dCommandId;
        m_eLayer = other.m_eLayer;
        m_dTimeout = other.m_dTimeout;
		
        m_CommandStatus = other.m_CommandStatus;
        if(other.m_pErrorInfo) m_pErrorInfo = other.m_pErrorInfo->Clone();

        m_pJournalManager = other.m_pJournalManager;
        m_pGateway = other.m_pGateway;
		m_oTransactionEventEnabled = other.m_oTransactionEventEnabled;

        if(m_pJournalTime && other.m_pJournalTime) *m_pJournalTime = *other.m_pJournalTime;
        if(m_pParameterInfo && other.m_pParameterInfo) *m_pParameterInfo = *other.m_pParameterInfo;
		if(m_pLayerParameterStack && other.m_pLayerParameterStack) *m_pLayerParameterStack = *other.m_pLayerParameterStack;
    }

    return *this;
}

//********************************************************************
void CCommandRoot::ResetCommand()
{
    m_oTransactionEventEnabled = TRUE;
	m_pJournalManager = NULL;
    m_pGateway = NULL;
    m_CommandName = "";
    m_eLayer = NO_LAYER;
    m_dCommandId = 0;
    m_CommandStatus = CMD_IDLE;
    m_dTimeout = UINT_MAX;
	m_oSubLayerRemainsLocked = FALSE;
    ResetErrorInfo();

    if(m_pParameterInfo) m_pParameterInfo->Reset();
    if(m_pJournalTime) m_pJournalTime->Reset();
}

#ifdef WINVER
//********************************************************************
void CCommandRoot::Serialize(CArchive &ar)
{
    const DWORD k_CommandStructureVersion = 1;

    int iLayer, iCommandStatus;
    BOOL oErrorInfoExisting;
    BOOL oParameterInfoExisting;
    BOOL oJournalTimeExisting;
    DWORD dCommandStructureVersion;

    if(ar.IsStoring())
    {
        ar << k_CommandStructureVersion;

        ar << m_CommandName;
        ar << m_eLayer;
        ar << m_dCommandId;
        ar << m_dTimeout;
        ar << m_CommandStatus;
		ar << m_oSubLayerRemainsLocked;

        //ErrorInfo
        oErrorInfoExisting = BOOL(m_pErrorInfo);
        ar << oErrorInfoExisting;
        if(oErrorInfoExisting) m_pErrorInfo->Serialize(ar);

        //ParameterInfo
        oParameterInfoExisting = BOOL(m_pParameterInfo);
        ar << oParameterInfoExisting;
        if(oParameterInfoExisting) m_pParameterInfo->Serialize(ar);

        //JournalTime
		ar << m_oTransactionEventEnabled;
        oJournalTimeExisting = BOOL(m_pJournalTime);
        ar << oJournalTimeExisting;
        if(oJournalTimeExisting) m_pJournalTime->Serialize(ar);
    }
    else
    {
        ResetCommand();

        ar >> dCommandStructureVersion;
        if(dCommandStructureVersion == k_CommandStructureVersion)
        {
            ar >> m_CommandName;
            ar >> iLayer; m_eLayer = (ELayer)iLayer;
            ar >> m_dCommandId;
            ar >> m_dTimeout;
            ar >> iCommandStatus; m_CommandStatus = (ECommandStatus)iCommandStatus;
			ar >> m_oSubLayerRemainsLocked;

            //ErrorInfo
            ar >> oErrorInfoExisting;
            if(oErrorInfoExisting)
            {
                m_pErrorInfo = new CErrorInfo();
                m_pErrorInfo->Serialize(ar);
            }

            //ParameterInfo
            ar >> oParameterInfoExisting;
            if(oParameterInfoExisting)
            {
                if(m_pParameterInfo == NULL) m_pParameterInfo = new CParameterInfo();
                m_pParameterInfo->Serialize(ar);
            }

            //JournalTime
			ar >> m_oTransactionEventEnabled;
            ar >> oJournalTimeExisting;
            if(oJournalTimeExisting)
            {
                if(m_pJournalTime == NULL) m_pJournalTime = new CJournalTime();
                m_pJournalTime->Serialize(ar);
            }
        }
    }
}
#endif

//********************************************************************
BOOL CCommandRoot::SetParameterData(int lParameterIndex, void* pData, size_t dLength)
{
    if(m_pParameterInfo)
    {
        return m_pParameterInfo->SetParameterData(lParameterIndex, pData, dLength);
    }

    return FALSE;
}

//********************************************************************
BOOL CCommandRoot::SetReturnParameterData(int lParameterIndex, std::string data)
{
    if(m_pParameterInfo)
    {
        return m_pParameterInfo->SetReturnParameterData(lParameterIndex, (void*)data.c_str(), data.size());
    }

    return FALSE;
}

BOOL CCommandRoot::SetReturnParameterData(int lParameterIndex, void* pData, DWORD dLength)
{
    if(m_pParameterInfo)
    {
        return m_pParameterInfo->SetReturnParameterData(lParameterIndex, pData, dLength);
    }

    return FALSE;
}


//********************************************************************
BOOL CCommandRoot::GetReturnParameterData(int lParameterIndex, void* pData, DWORD dLength)
{
    if(m_pParameterInfo)
    {
        return m_pParameterInfo->GetReturnParameterData(lParameterIndex, pData, dLength);
    }

    return FALSE;
}

//********************************************************************
BOOL CCommandRoot::GetParameterData(int lParameterIndex, void* pData, DWORD dLength)
{
    if(m_pParameterInfo)
    {
        return m_pParameterInfo->GetParameterData(lParameterIndex, pData, dLength);
    }

    return FALSE;
}

//******************************************************************
CXXMLFile::CElement* CCommandRoot::StoreToXMLFile(CXXMLFile* pFile, CXXMLFile::CElement* pParentElement, BOOL oCheckVisibility)
{
    CXXMLFile::CElement* pElement = NULL;
    CStdString runTime;
    CStdString commandTime;

    if(pFile && pParentElement)
    {
        //Time
        runTime = GetJournalRunTimeString();
        commandTime = GetCommandTimeString();

        //Command Elements
        pElement = (CXXMLFile::CElement*)pFile->AddElement(pParentElement);
        pFile->SetText(pElement, "Command");

		pElement->SetAt("Name", m_CommandName);
        pElement->SetAt("Layer", GetLayerStr());
        pElement->SetAt("CommandId", GetCommandIdStr());

        pElement->SetAt("Status", GetCommandStatusStr(m_CommandStatus));
        pElement->SetAt("ErrorCode", GetErrorCodeStr());

        pElement->SetAt("JournalRunTime", runTime);
        pElement->SetAt("CommandDuration", commandTime);

        //Parameter Elements
        if(m_pParameterInfo && !m_pParameterInfo->StoreToXMLFile(pFile, pElement, oCheckVisibility)) return NULL;
    }

    return pElement;
}

//*******************************************************************
BOOL CCommandRoot::StoreToXMLString(CStdString *pDataString, BOOL oCheckVisibility)
{
    CXXMLFile file;
    CXXMLFile::CElementPart* pElementPart;
    CXXMLFile::CElement* pParentElement;

    if(pDataString)
    {
        //Root
        file.RemoveAll();
        pElementPart = file.Root();
        if(!file.IsElement(pElementPart)) return FALSE;
        pParentElement = (CXXMLFile::CElement*)pElementPart;

        //Store
        if(!StoreToXMLFile(&file, pParentElement, oCheckVisibility)) return FALSE;

        //Write XML String
        pDataString->Empty();
		file.WriteToString(pDataString);

        return TRUE;
    }

    return FALSE;
}

//*******************************************************************
void CCommandRoot::InitJournalManager(CJournalManagerBase *pJournalManager)
{
    m_pJournalManager = pJournalManager;
}

//*******************************************************************
BOOL CCommandRoot::InitGateway(CGateway *pGateway)
{
    m_pGateway = pGateway;
    return TRUE;
}

//*******************************************************************
void CCommandRoot::ResetGateway()
{
    m_pGateway = NULL;
}

//*******************************************************************
void CCommandRoot::ResetJournalManager()
{
    m_pJournalManager = NULL;
}

//*******************************************************************
void CCommandRoot::SetStatus(BOOL oResult, CErrorInfo* pErrorInfo)
{
    //CommandStatus
    if(oResult)
    {
        m_CommandStatus = CMD_SUCCESSFUL;
    }
    else
    {
        m_CommandStatus = CMD_FAILED;
    }

    //ErrorInfo
    ResetErrorInfo();
    if(pErrorInfo)
    {
        m_pErrorInfo = pErrorInfo->Clone();
        if(!m_pErrorInfo->IsCommandNameSet()) m_pErrorInfo->SetCommandName(m_CommandName);
    }
}

//*******************************************************************
void CCommandRoot::ResetStatus()
{
    m_CommandStatus = CMD_IDLE;
    ResetErrorInfo();
}

//*******************************************************************
CStdString CCommandRoot::GetLayerStr()
{
    switch(m_eLayer)
    {
        case VIRTUAL_COMMAND_SET_LAYER: return VIRTUAL_COMMAND_SET_LAYER_STRING;
        case DEVICE_COMMAND_SET_LAYER: return COMMAND_SET_LAYER_STRING;
        case PROTOCOL_STACK_LAYER: return PROTOCOL_STACK_LAYER_STRING;
        case INTERFACE_LAYER: return INTERFACE_LAYER_STRING;
        case NO_LAYER: return "NoLayer";
    }

    return "";
}

//*******************************************************************
CStdString CCommandRoot::GetCommandIdStr()
{
    CMmcDataConversion dataConversion;
    CStdString strResult;

    if(dataConversion.DWord2DecDWordStr(m_dCommandId, &strResult))
    {
        return strResult;
    }

    return "";
}

//*******************************************************************
CStdString CCommandRoot::GetErrorCodeStr()
{
    DWORD ulErrorCode = 0;
    CMmcDataConversion dataConversion;
    CStdString strErrorCode;

    if(m_pErrorInfo) ulErrorCode = m_pErrorInfo->GetErrorCode();
    if(dataConversion.DWord2DecDWordStr(ulErrorCode, &strErrorCode))
    {
        return strErrorCode;
    }

    return "";
}

//*******************************************************************
CStdString CCommandRoot::GetCommandStatusStr(ECommandStatus eCommandStatus)
{
    switch(eCommandStatus)
    {
        case CMD_IDLE:          return "Idle";
        case CMD_SUCCESSFUL:    return "Successful";
        case CMD_FAILED:        return "Failed";
        default: return "";
    }
}

//*******************************************************************
BOOL CCommandRoot::InitCommandStatus(CStdString strCmdStatus, CStdString strCmdErrorCode)
{
    CMmcDataConversion dataConversion;
    DWORD dErrorCode;

    if(dataConversion.DecDWordStr2DWord(strCmdErrorCode, &dErrorCode, FALSE))
    {
        //ErrorInfo
        ResetErrorInfo();
        m_pErrorInfo = new CErrorInfo();
        m_pErrorInfo->Init(dErrorCode);

        //CommandStatus
        if(strCmdStatus.Compare("Idle") == 0)
        {
            m_CommandStatus = CMD_IDLE;
            return TRUE;
        }
        else if(strCmdStatus.Compare("Successful") == 0)
        {
            m_CommandStatus = CMD_SUCCESSFUL;
            return TRUE;
        }
        else if(strCmdStatus.Compare("Failed") == 0)
        {
            m_CommandStatus = CMD_FAILED;
            return TRUE;
        }
        else
        {
            m_CommandStatus = CMD_IDLE;
            return FALSE;
        }
    }

    return FALSE;
}

//*******************************************************************
DWORD CCommandRoot::GetCommandId()
{
    return m_dCommandId;
}

//*******************************************************************
BOOL CCommandRoot::GetErrorInfo(CErrorInfo* pErrorInfo)
{
    if(pErrorInfo)
    {
        if(m_pErrorInfo)
        {
            *pErrorInfo = *m_pErrorInfo;
        }
        else
        {
            pErrorInfo->Reset();
        }
        return TRUE;
    }

    return FALSE;
}

//*******************************************************************
BOOL CCommandRoot::GetErrorCode(DWORD* pdErrorCode)
{
    if(pdErrorCode && m_pErrorInfo)
    {
        *pdErrorCode = m_pErrorInfo->GetErrorCode();
        return TRUE;
    }

    return FALSE;
}

DWORD CCommandRoot::GetParameterLength(int paramIndex)
{
    if(m_pParameterInfo)
    {
        return m_pParameterInfo->GetParameterLength(paramIndex);
    }

    return 0;
}

DWORD CCommandRoot::GetReturnParameterLength(int paramIndex)
{
    if(m_pParameterInfo)
    {
        return m_pParameterInfo->GetReturnParameterLength(paramIndex);
    }

    return 0;
}

int CCommandRoot::GetNbOfParameter()
{
    if(m_pParameterInfo)
    {
        return m_pParameterInfo->GetNbOfParameter();
    }

    return 0;
}

int CCommandRoot::GetNbOfReturnParameter()
{
    if(m_pParameterInfo)
    {
        return m_pParameterInfo->GetNbOfReturnParameter();
    }

    return 0;
}

BOOL CCommandRoot::FindParameterIndex(CStdString p_Name, int& p_rIndex)
{
    BOOL oResult = FALSE;

    if(m_pParameterInfo)
    {
        oResult = m_pParameterInfo->FindParameterIndex(p_Name,p_rIndex);
    }

    return oResult;
}
    
BOOL CCommandRoot::FindReturnParameterIndex(CStdString p_Name, int& p_rIndex)
{
    BOOL oResult = FALSE;

    if(m_pParameterInfo)
    {
        oResult = m_pParameterInfo->FindReturnParameterIndex(p_Name,p_rIndex);
    }

    return oResult;
}

CStdString CCommandRoot::GetParameterName(int paramIndex)
{
    if(m_pParameterInfo)
    {
        return m_pParameterInfo->GetParameterName(paramIndex);
    }

    return "";
}

CStdString CCommandRoot::GetReturnParameterName(int paramIndex)
{
    if(m_pParameterInfo)
    {
        return m_pParameterInfo->GetReturnParameterName(paramIndex);
    }

    return "";
}

BOOL CCommandRoot::IsSuccessful()
{
    return (m_CommandStatus == CMD_SUCCESSFUL);
}

BOOL CCommandRoot::GetParameterInfo(int paramIndex, CStdString* pName, CStdString* pType, CStdString* pData, EObjectValueStringFormat format)
{
    if(m_pParameterInfo->IsParameterExisting(paramIndex))
    {
        if(pName) *pName = m_pParameterInfo->GetParameterName(paramIndex);
        if(pType) *pType = m_pParameterInfo->GetParameterTypeStr(paramIndex);
        if(pData) *pData = m_pParameterInfo->GetParameterDataStr(paramIndex, format);

        return TRUE;
    }

    return FALSE;
}

BOOL CCommandRoot::GetReturnParameterInfo(int paramIndex, CStdString* pName, CStdString* pType, CStdString* pData, EObjectValueStringFormat format)
{
    if(m_pParameterInfo->IsReturnParameterExisting(paramIndex))
    {
        if(pName) *pName = m_pParameterInfo->GetReturnParameterName(paramIndex);
        if(pType) *pType = m_pParameterInfo->GetReturnParameterTypeStr(paramIndex);
        if(pData) *pData = m_pParameterInfo->GetReturnParameterDataStr(paramIndex, format);

        return TRUE;
    }

    return FALSE;
}

EObjectDataType CCommandRoot::GetParameterType(int paramIndex)
{
    if(m_pParameterInfo)
    {
        return m_pParameterInfo->GetParameterType(paramIndex);
    }

    return ODT_UNKNOWN;
}

EObjectDataType CCommandRoot::GetReturnParameterType(int paramIndex)
{
    if(m_pParameterInfo)
    {
        return m_pParameterInfo->GetReturnParameterType(paramIndex);
    }

    return ODT_UNKNOWN;
}

BOOL CCommandRoot::IsParameterEditable(int paramIndex)
{
    if(m_pParameterInfo)
    {
        return m_pParameterInfo->IsParameterEditable(paramIndex);
    }

    return FALSE;
}

BOOL CCommandRoot::IsParameterVisible(int paramIndex)
{
    if(m_pParameterInfo)
    {
        return m_pParameterInfo->IsParameterVisible(paramIndex);
    }

    return FALSE;
}

BOOL CCommandRoot::IsReturnParameterVisible(int paramIndex)
{
    if(m_pParameterInfo)
    {
        return m_pParameterInfo->IsReturnParameterVisible(paramIndex);
    }

    return FALSE;
}

BOOL CCommandRoot::SetParameterDataString(int lParameterIndex, CStdString strValue, BOOL showMsg)
{
    if(m_pParameterInfo)
    {
        return m_pParameterInfo->SetParameterDataString(lParameterIndex, strValue, showMsg);
    }

    return FALSE;
}

BOOL CCommandRoot::SetReturnParameterDataString(int lParameterIndex, CStdString strValue, BOOL showMsg)
{
    if(m_pParameterInfo)
    {
        return m_pParameterInfo->SetReturnParameterDataString(lParameterIndex, strValue, showMsg);
    }

    return FALSE;
}

BOOL CCommandRoot::GetParameterDataString(int lParameterIndex, CStdString* pStrValue, EObjectValueStringFormat format)
{
    if(m_pParameterInfo)
    {
        return m_pParameterInfo->GetParameterDataString(lParameterIndex, pStrValue, format);
    }

    return FALSE;
}

BOOL CCommandRoot::GetReturnParameterDataString(int lParameterIndex, CStdString* pStrValue, EObjectValueStringFormat format)
{
    if(m_pParameterInfo)
    {
        return m_pParameterInfo->GetReturnParameterDataString(lParameterIndex, pStrValue, format);
    }

    return FALSE;
}

BOOL CCommandRoot::IsEditableParameterExisting()
{
    if(m_pParameterInfo)
    {
        return m_pParameterInfo->IsEditableParameterExisting();
    }

    return FALSE;
}

BOOL CCommandRoot::IsVisibleParameterExisting()
{
    if(m_pParameterInfo)
    {
        return m_pParameterInfo->IsVisibleParameterExisting();
    }

    return FALSE;
}

BOOL CCommandRoot::IsVisibleReturnParameterExisting()
{
    if(m_pParameterInfo)
    {
        return m_pParameterInfo->IsVisibleReturnParameterExisting();
    }

    return FALSE;
}

DWORD CCommandRoot::GetParameterArraySize(int paramIndex)
{
    if(m_pParameterInfo)
    {
        return m_pParameterInfo->GetParameterArraySize(paramIndex);
    }

    return FALSE;
}

DWORD CCommandRoot::GetReturnParameterArraySize(int paramIndex)
{
    if(m_pParameterInfo)
    {
        return m_pParameterInfo->GetReturnParameterArraySize(paramIndex);
    }

    return FALSE;
}

BOOL CCommandRoot::PushLayerParameterSet(CLayerParameterSet& p_rParameterSet)
{
	BOOL oResult = FALSE;

	if(m_pLayerParameterStack)
	{
		oResult = m_pLayerParameterStack->PushLayer(p_rParameterSet);
	}

	return oResult;
}
	
BOOL CCommandRoot::SetLayerParameterStack(CLayerParameterStack& p_rParameterStack)
{
	BOOL oResult = FALSE;

	if(m_pLayerParameterStack)
	{
		*m_pLayerParameterStack = p_rParameterStack;
		oResult = TRUE;
	}

	return oResult;
}
	
BOOL CCommandRoot::GetLayerParameterStack(CLayerParameterStack& p_rParameterStack)
{
	BOOL oResult = FALSE;

	if(m_pLayerParameterStack)
	{
		p_rParameterStack = *m_pLayerParameterStack;
		oResult = TRUE;
	}

	return oResult;
}
	
BOOL CCommandRoot::GetLayerParameter(ELayer p_eLayer, CStdString p_Name, BYTE* p_pValue, DWORD p_ulSize, CErrorInfo* pErrorInfo)
{
	BOOL oResult = FALSE;

	if(m_pLayerParameterStack)
	{
		//Init
		oResult = TRUE;

		if(!m_pLayerParameterStack->GetLayerParameter(p_eLayer, p_Name, p_pValue, p_ulSize))
		{
			if(pErrorInfo) pErrorInfo->Init(k_Error_BadParameter, NULL);
			oResult = FALSE;
		}
	}

	return oResult;
}

BOOL CCommandRoot::GetLayerParameter(ELayer p_eLayer, CStdString p_Name, CStdString& p_rValue, CErrorInfo* pErrorInfo)
{
	BOOL oResult = FALSE;

	if(m_pLayerParameterStack)
	{
		//Init
		oResult = TRUE;

		if(!m_pLayerParameterStack->GetLayerParameter(p_eLayer, p_Name, p_rValue))
		{
			if(pErrorInfo) pErrorInfo->Init(k_Error_BadParameter, NULL);
			oResult = FALSE;
		}
	}

	return oResult;
}

BOOL CCommandRoot::IsSubLayerLocked()
{
	return m_oSubLayerRemainsLocked;
}
