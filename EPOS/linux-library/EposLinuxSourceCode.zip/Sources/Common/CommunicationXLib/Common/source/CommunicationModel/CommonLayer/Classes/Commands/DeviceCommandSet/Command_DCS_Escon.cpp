// Command_DCS_Escon.cpp: Implementierung der Klasse CCommand_DCS_Escon.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <CommunicationModel/CommonLayer/Classes/Commands/DeviceCommandSet/Command_DCS_Escon.h>
#ifdef _MMC_DCS_ESCON
#include <CommunicationModel/CommonLayer/Classes/Commands/DeviceCommandSet/DcsEsconDef.h>

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
/////////////////////////0/////////////////////////////////////////////

CCommand_DCS_Escon::CCommand_DCS_Escon()
{
}

CCommand_DCS_Escon::CCommand_DCS_Escon(DWORD dCommandId)
{
    InitCommand(dCommandId);
}

CCommand_DCS_Escon::~CCommand_DCS_Escon()
{
}

CCommandRoot* CCommand_DCS_Escon::CloneCommand()
{
    CCommand_DCS_Escon* pNewCommand;

    pNewCommand = new CCommand_DCS_Escon();
    *pNewCommand = *this;

    return pNewCommand;
}

CCommand_DCS_Escon& CCommand_DCS_Escon::operator=(CCommand_DCS_Escon& other)
{
    if(this != &other)
    {
        *((CCommandRoot*)this) = *((CCommandRoot*)&other);
    }

    return *this;
}

BOOL CCommand_DCS_Escon::InitCommand(DWORD dCommandId)
{
    ResetCommand();

    if(InitCommand_ObjectDictionary(dCommandId)) return 1;

    return 0;
}

BOOL CCommand_DCS_Escon::InitCommand_ObjectDictionary(DWORD dCommandId)
{
    switch(dCommandId)
    {
        case ESCON_WRITE_OBJECT:
            {
                CCommand_DCS::InitCommand("WriteObject", ESCON_WRITE_OBJECT);
                AddParameter(0, "index", ODT_UINT16);
                AddParameter(1, "subIndex", ODT_UINT8);
                AddParameter(2, "nodeId", ODT_UINT8);
                AddParameter(3, "data", ODT_MEMORY_BLOCK);
                AddParameter(4, "objectLength", ODT_UINT32, 0, 0);
                AddReturnParameter(0, "errorCode", ODT_UINT32);
                SetDefaultParameter_WriteObject();
                return 1;
            };
        case ESCON_READ_OBJECT:
            {
                CCommand_DCS::InitCommand("ReadObject", ESCON_READ_OBJECT);
                AddParameter(0, "index", ODT_UINT16);
                AddParameter(1, "subIndex", ODT_UINT8);
                AddParameter(2, "nodeId", ODT_UINT8);
                AddParameter(3, "objectLength", ODT_UINT32, 0, 0);
                AddReturnParameter(0, "errorCode", ODT_UINT32);
                AddReturnParameter(1, "data", ODT_MEMORY_BLOCK);
                SetDefaultParameter_ReadObject();
                return 1;
            };
        case ESCON_INITIATE_SEGMENT_WRITE:
            {
                CCommand_DCS::InitCommand("InitiateSegmentedWrite", ESCON_INITIATE_SEGMENT_WRITE);
                AddParameter(0, "index", ODT_UINT16);
                AddParameter(1, "subIndex", ODT_UINT8);
                AddParameter(2, "nodeId", ODT_UINT8);
                AddParameter(3, "objectLength", ODT_UINT32);
                AddReturnParameter(0, "errorCode", ODT_UINT32);
                SetDefaultParameter_InitiateSegmentedWrite();
                return 1;
            };
        case ESCON_INITIATE_SEGMENT_READ:
            {
                CCommand_DCS::InitCommand("InitiateSegmentedRead", ESCON_INITIATE_SEGMENT_READ);
                AddParameter(0, "index", ODT_UINT16);
                AddParameter(1, "subIndex", ODT_UINT8);
                AddParameter(2, "nodeId", ODT_UINT8);
                AddReturnParameter(0, "errorCode", ODT_UINT32);
                SetDefaultParameter_InitiateSegmentedRead();
                return 1;
            };
        case ESCON_SEGMENT_WRITE:
            {
                CCommand_DCS::InitCommand("SegmentWrite", ESCON_SEGMENT_WRITE);
                AddParameter(0, "nodeId", ODT_UINT16, 0, 0);
                AddParameter(1, "controlByte", ODT_UINT8);
                AddParameter(2, "data", ODT_MEMORY_BLOCK);
                AddReturnParameter(0, "errorCode", ODT_UINT32);
                AddReturnParameter(1, "controlByte", ODT_UINT8);
                AddReturnParameter(2, "dummyByte", ODT_UINT8);
                SetDefaultParameter_SegmentedWrite();
                return 1;
            };
        case ESCON_SEGMENT_READ:
            {
                CCommand_DCS::InitCommand("SegmentRead", ESCON_SEGMENT_READ);
                AddParameter(0, "nodeId", ODT_UINT16, 0, 0);
                AddParameter(1, "controlByte", ODT_UINT8);
                AddParameter(2, "dummyByte", ODT_UINT8);
                AddReturnParameter(0, "errorCode", ODT_UINT32);
                AddReturnParameter(1, "controlByte", ODT_UINT8);
                AddReturnParameter(2, "data", ODT_MEMORY_BLOCK);
                SetDefaultParameter_SegmentedRead();
                return 1;
            };

        case ESCON_ABORT_SEGMENT_TRANSFER:
            {
                CCommand_DCS::InitCommand("AbortSegmentedTransfer", ESCON_ABORT_SEGMENT_TRANSFER);
                AddParameter(0, "nodeId", ODT_UINT16, 0, 0);
                AddParameter(1, "index", ODT_UINT16);
                AddParameter(2, "subIndex", ODT_UINT8);
                AddParameter(3, "abortCode", ODT_UINT32);
                SetDefaultParameter_AbortSegmentedTransfer();
                return 1;
            };
    }

    return 0;
}

void CCommand_DCS_Escon::SetDefaultParameter_InitiateSegmentedRead()
{
    BYTE ubNodeId = 1;
    WORD wIndex = 0;
    BYTE ubSubIndex = 0;
    DWORD dErrorCode = 0;

    //Parameter
    SetParameterData(0, &wIndex, sizeof(wIndex));
    SetParameterData(1, &ubSubIndex, sizeof(ubSubIndex));
    SetParameterData(2, &ubNodeId, sizeof(ubNodeId));

    //ReturnParameter
    SetReturnParameterData(0, &dErrorCode, sizeof(dErrorCode));
}

void CCommand_DCS_Escon::SetDefaultParameter_InitiateSegmentedWrite()
{
    BYTE ubNodeId = 1;
    WORD wIndex = 0;
    BYTE ubSubIndex = 0;
    WORD objectLength = 0;
    DWORD dErrorCode = 0;

    //Parameter
    SetParameterData(0, &wIndex, sizeof(wIndex));
    SetParameterData(1, &ubSubIndex, sizeof(ubSubIndex));
    SetParameterData(2, &ubNodeId, sizeof(ubNodeId));
    SetParameterData(3, &objectLength, sizeof(objectLength));

    //ReturnParameter
    SetReturnParameterData(0, &dErrorCode, sizeof(dErrorCode));
}

void CCommand_DCS_Escon::SetDefaultParameter_ReadObject()
{
    BYTE ubNodeId = 1;
    WORD wIndex = 0;
    BYTE ubSubIndex = 0;
    DWORD dObjectLength = 0;
    void* pData = 0;
    DWORD dErrorCode = 0;

    //Parameter
    SetParameterData(0, &wIndex, sizeof(wIndex));
    SetParameterData(1, &ubSubIndex, sizeof(ubSubIndex));
    SetParameterData(2, &ubNodeId, sizeof(ubNodeId));
    SetParameterData(3, &dObjectLength, sizeof(dObjectLength));

    //ReturnParameter
    SetReturnParameterData(0, &dErrorCode, sizeof(dErrorCode));
    SetReturnParameterData(1, pData, 0);
}

void CCommand_DCS_Escon::SetDefaultParameter_SegmentedRead()
{
    WORD wNodeId = 1;
    BYTE uControlByte = 0;
    BYTE ubDummyByte = 0;
    DWORD dErrorCode = 0;

    //Parameter
    SetParameterData(0, &wNodeId, sizeof(wNodeId));
    SetParameterData(1, &uControlByte, sizeof(uControlByte));
    SetParameterData(2, &ubDummyByte, sizeof(ubDummyByte));

    //ReturnParameter
    SetReturnParameterData(0, &dErrorCode, sizeof(dErrorCode));
    SetReturnParameterData(1, &uControlByte, sizeof(uControlByte));
    SetReturnParameterData(2, 0, 0);
}

void CCommand_DCS_Escon::SetDefaultParameter_SegmentedWrite()
{
    WORD wNodeId = 1;
    BYTE uControlByte = 0;
    BYTE ubDummyByte = 0;
    DWORD dErrorCode = 0;

    //Parameter
    SetParameterData(0, &wNodeId, sizeof(wNodeId));
    SetParameterData(1, &uControlByte, sizeof(uControlByte));
    SetParameterData(2, 0, 0);

    //ReturnParameter
    SetReturnParameterData(0, &dErrorCode, sizeof(dErrorCode));
    SetReturnParameterData(1, &uControlByte, sizeof(uControlByte));
    SetReturnParameterData(2, &ubDummyByte, sizeof(ubDummyByte));
}

void CCommand_DCS_Escon::SetDefaultParameter_WriteObject()
{
    BYTE ubNodeId = 1;
    WORD wIndex = 0;
    BYTE ubSubIndex = 0;
    WORD objectLength = 0;
    DWORD dErrorCode = 0;

    //Parameter
    SetParameterData(0, &wIndex, sizeof(wIndex));
    SetParameterData(1, &ubSubIndex, sizeof(ubSubIndex));
    SetParameterData(2, &ubNodeId, sizeof(ubNodeId));
    SetParameterData(3, 0, 0);
    SetParameterData(4, &objectLength, sizeof(objectLength));

    //ReturnParameter
    SetReturnParameterData(0, &dErrorCode, sizeof(dErrorCode));
}

void CCommand_DCS_Escon::SetDefaultParameter_AbortSegmentedTransfer()
{
    WORD wNodeId = 1;
    WORD wIndex = 0;
    BYTE ubSubIndex = 0;
    DWORD dAbortCode = 0;

    //Parameter
    SetParameterData(0, &wNodeId, sizeof(wNodeId));
    SetParameterData(1, &wIndex, sizeof(wIndex));
    SetParameterData(2, &ubSubIndex, sizeof(ubSubIndex));
    SetParameterData(3, &dAbortCode, sizeof(dAbortCode));
}
#endif //_MMC_DCS_ESCON
