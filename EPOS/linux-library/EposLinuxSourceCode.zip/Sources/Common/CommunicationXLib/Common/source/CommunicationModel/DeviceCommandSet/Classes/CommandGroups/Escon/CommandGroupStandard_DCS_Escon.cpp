// CommandGroupStandard_DCS_Escon.cpp: Implementierung der Klasse CCommandGroupStandard_DCS_Escon.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CommandGroupStandard_DCS_Escon.h"
#ifdef _MMC_DCS_ESCON
#include "../../CommandSets/Escon/CommandSetObjectDictionary_DCS_Escon.h"

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

CCommandGroupStandard_DCS_Escon::CCommandGroupStandard_DCS_Escon()
{
    m_strCommandGroupName = COMMAND_GROUP_STANDARD;
    FillSetList();
}

CCommandGroupStandard_DCS_Escon::~CCommandGroupStandard_DCS_Escon()
{
    DeleteSetList();
}

void CCommandGroupStandard_DCS_Escon::FillSetList()
{
    m_pCommandSetObjectDictionary = new CCommandSetObjectDictionary_DCS_Escon();
}

void CCommandGroupStandard_DCS_Escon::DeleteSetList()
{
    if(m_pCommandSetObjectDictionary)
    {
        delete m_pCommandSetObjectDictionary;
        m_pCommandSetObjectDictionary = 0;
    }
}

void CCommandGroupStandard_DCS_Escon::InitJournalManager(CJournalManagerBase* p_pJournalManager)
{
    if(m_pCommandSetObjectDictionary) m_pCommandSetObjectDictionary->InitJournalManager(p_pJournalManager);
}

void CCommandGroupStandard_DCS_Escon::ResetJournalManager()
{
    if(m_pCommandSetObjectDictionary) m_pCommandSetObjectDictionary->ResetJournalManager();
}

BOOL CCommandGroupStandard_DCS_Escon::InitGateway(CGateway *p_pGateway)
{
    if(m_pCommandSetObjectDictionary && !m_pCommandSetObjectDictionary->InitGateway(p_pGateway)) return 0;

    return 1;
}

CXXMLFile::CElementPart* CCommandGroupStandard_DCS_Escon::StoreToXMLFile(CXXMLFile* pFile, CXXMLFile::CElementPart* pParentElement)
{
    CXXMLFile::CElement* pElement = 0;

    if(pFile && pParentElement)
    {
        //CommandGroup Elements
        pElement = (CXXMLFile::CElement*)pFile->AddElement(pParentElement);
        pFile->SetText(pElement, "CommandGroup");
        pElement->AttributeToValue["Name"] = m_strCommandGroupName;

        //CommandSet Elements
        if(m_pCommandSetObjectDictionary && !m_pCommandSetObjectDictionary->StoreToXMLFile(pFile, pElement)) return pElement;
    }

    return pElement;
}
#endif //_MMC_DCS_ESCON
