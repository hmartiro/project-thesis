// GatewayMaxonSerialV2ToHID.h: Schnittstelle f�r die Klasse CGatewayMaxonSerialV2ToHID.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GatewayMaxonSerialV2ToHID_H__89B9836A_BF97_42DF_8370_3E0AF46F87FE__INCLUDED_)
#define AFX_GatewayMaxonSerialV2ToHID_H__89B9836A_BF97_42DF_8370_3E0AF46F87FE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <MmcDefinitions.h>
#include <CommunicationModel/Common/CommunicationModelDefinitions.h>
#ifdef _MMC_PS_MAXON_SERIAL_V2
#ifdef _MMC_I_HID
#include "GatewayMaxonSerialV2ToI.h"

class CCommand_I_USB;
class CInterfaceManagerBase;

class CGatewayMaxonSerialV2ToHID : public CGatewayMaxonSerialV2ToI
{
public:
    CGatewayMaxonSerialV2ToHID();
    virtual ~CGatewayMaxonSerialV2ToHID();

    virtual CGateway* Clone();
    CGatewayMaxonSerialV2ToHID& operator=(CGatewayMaxonSerialV2ToHID& p_Other);

private:
    //Protocol Implementation
    BOOL Process_ProcessProtocol(CCommand_PS* p_pCommand, CInterfaceManagerBase* p_pInterfaceManager, HANDLE p_hI_Handle, HANDLE p_hTransactionHandle);
    BOOL EvaluateWriteRetry(BOOL p_oSendResult, CErrorInfo& p_rSendErrorInfo, BOOL p_oReceiveResult, CErrorInfo& p_rReceiveErrorInfo, BOOL& p_roExecuteRetry, CErrorInfo& p_rErrorInfo);

    //Initialisation
    void DeleteCommands();
    void InitCommands();

    //Reading Writing Data
    BOOL I_ReadData(CInterfaceManagerBase* p_pInterfaceManager, HANDLE p_hI_Handle, HANDLE p_hTransactionHandle, void* p_pData, DWORD p_ulNumberOfBytesToRead, DWORD* p_pulNumberOfBytesRead, CErrorInfo* p_pErrorInfo = 0);
    BOOL I_WriteData(CInterfaceManagerBase* p_pInterfaceManager, HANDLE p_hI_Handle, HANDLE p_hTransactionHandle, void* p_pData, DWORD p_ulNumberOfBytesToWrite, DWORD* p_pulNumberOfBytesWritten, CErrorInfo* p_pErrorInfo = 0);

    //Layer Parameter Stack
    BOOL InitLayerParameterStack(CCommandRoot* p_pCommand);

    //Error Handling
    BOOL InitErrorHandling();

private:
    CCommand_I_USB* m_pCommand_WriteData;
    CCommand_I_USB* m_pCommand_ReadData;
};
#endif //_MMC_I_HID
#endif //_MMC_PS_MAXON_SERIAL_V2

#endif // !defined(AFX_GatewayMaxonSerialV2ToHID_H__89B9836A_BF97_42DF_8370_3E0AF46F87FE__INCLUDED_)
