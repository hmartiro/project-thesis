// InterfaceManagerBase.h: Schnittstelle f�r die Klasse CInterfaceManagerBase.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INTERFACEMANAGERBASE_H__CC6EFF22_52C9_4A59_AB67_6B2B44E101FF__INCLUDED_)
#define AFX_INTERFACEMANAGERBASE_H__CC6EFF22_52C9_4A59_AB67_6B2B44E101FF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <CommunicationModel/CommonLayer/LayerManagerBase.h>

class CJournalManagerBase;

class CInterfaceManagerBase  : public CLayerManagerBase
{
public:
//Internal Structure Funktionen
	virtual BOOL I_InitAllInterfaces(CErrorInfo* pErrorInfo = NULL);
	virtual BOOL I_InitInterface(CStdString strInterfaceName,CErrorInfo* pErrorInfo = NULL);
	virtual BOOL I_InitBaudrateSelection(CStdString strInterfaceName,CStdDWordArray& dBaudrateSel,CErrorInfo* pErrorInfo = NULL);
	virtual BOOL I_InitDefaultInterfaceSettings(CStdString strInterfaceName,DWORD dBaudrate,DWORD dTimeout,CErrorInfo* pErrorInfo = NULL);
	virtual BOOL I_UpdateInterface(CStdString strInterfaceName,CErrorInfo* pErrorInfo = NULL);

//Initialisation
	virtual HANDLE I_OpenInterface(CStdString strInterfaceName,CStdString strPortName,CErrorInfo* pErrorInfo = NULL);
	virtual BOOL I_CloseInterface(HANDLE hI_Handle,CErrorInfo* pErrorInfo = NULL);
	virtual BOOL I_CloseAllInterfaces(CErrorInfo* pErrorInfo = NULL);
	virtual BOOL I_AreAllInterfacesClosed();

//Parameter
	virtual BOOL SetParameter(EParameterType p_eParameterType, HANDLE hI_Handle, CStdString p_Name, BYTE* p_pValue, DWORD p_ulSize, CErrorInfo* pErrorInfo = NULL);
	virtual BOOL SetParameter(EParameterType p_eParameterType, HANDLE hI_Handle, CStdString p_Name, CStdString p_Value, CErrorInfo* pErrorInfo = NULL);
	virtual BOOL GetParameter(EParameterType p_eParameterType, HANDLE hI_Handle, CStdString p_Name, BYTE* p_pValue, DWORD p_ulSize, CErrorInfo* pErrorInfo = NULL);
	virtual BOOL GetParameter(EParameterType p_eParameterType, HANDLE hI_Handle, CStdString p_Name, CStdString& p_rValue, CErrorInfo* pErrorInfo = NULL);

//Hilfsfunktionen
	virtual BOOL I_GetKeyHandle(CStdString strInterfaceName,CStdString strPortName,HANDLE* pIKeyHandle,CErrorInfo* pErrorInfo = NULL);
	virtual BOOL I_ResetInterface(HANDLE hI_Handle,CErrorInfo* pErrorInfo = NULL);
	virtual BOOL I_GetDefaultInterfaceSettings(CStdString strInterfaceName,DWORD* pdBaudrate,DWORD* pdTimeout,CErrorInfo* pErrorInfo = NULL);
    virtual BOOL I_SetDefaultInterfaceSettings(CStdString strInterfaceName, DWORD dBaudrate, DWORD dTimeout, CErrorInfo* pErrorInfo = NULL);
	virtual BOOL I_IsInterfaceNameSupported(CStdString strInterfaceName,CErrorInfo* pErrorInfo = NULL);

//Selection Funktionen
	virtual BOOL I_GetInterfaceNameSelection(CStdStringArray* pInterfaceNameSel,CErrorInfo* pErrorInfo = NULL);
	virtual BOOL I_GetPortNameSelection(CStdString strInterfaceName,CStdStringArray* pPortSel,CErrorInfo* pErrorInfo = NULL);
	virtual BOOL I_GetBaudrateSelection(CStdString strInterfaceName,CStdString strPortName,CStdDWordArray* pdBaudrateSel,CErrorInfo* pErrorInfo = NULL);

//Setting Funktionen
	virtual BOOL I_GetInterfaceSettings(HANDLE hI_Handle,DWORD* pdBaudrate,DWORD* pdTimeout,CErrorInfo* pErrorInfo = NULL);
	virtual BOOL I_SetInterfaceSettings(HANDLE hI_Handle,DWORD dBaudrate,DWORD dTimeout,BOOL oChangeOnly,CErrorInfo* pErrorInfo = NULL);

//Name Funktionen
	virtual BOOL I_GetInterfaceName(HANDLE hI_Handle,CStdString* pInterfaceName,CErrorInfo* pErrorInfo = NULL);
	virtual BOOL I_GetPortName(HANDLE hI_Handle,CStdString* pPortName,CErrorInfo* pErrorInfo = NULL);

//Funktionalit�t
	virtual BOOL ExecuteCommand(CCommandRoot *pCommand,HANDLE hHandle,HANDLE hTransactionHandle);
	virtual BOOL GetCommands(HANDLE hHandle,ELayer eLayer,CStdString* pCommandInfo);

//Tracing
	virtual BOOL EnableTracing(HANDLE hI_Handle, CStdString p_TracingFileName,CErrorInfo* pErrorInfo = NULL);
	virtual BOOL DisableTracing(HANDLE hI_Handle,CErrorInfo* pErrorInfo = NULL);

//LayerManager
	virtual BOOL GetLayerManager(HANDLE hHandle,ELayer eLayer,CLayerManagerBase** ppLayerManager);
	virtual BOOL GetLayerManager(CStdString strDeviceName,CStdString strProtocolStackName,ELayer eLayer,CLayerManagerBase** ppLayerManager);

	CInterfaceManagerBase();
	CInterfaceManagerBase(int p_lInstanceValue);
	CInterfaceManagerBase(const CInterfaceManagerBase& rObject);
	virtual ~CInterfaceManagerBase();
	virtual CInterfaceManagerBase* Clone();
};

#endif // !defined(AFX_INTERFACEMANAGERBASE_H__CC6EFF22_52C9_4A59_AB67_6B2B44E101FF__INCLUDED_)
