// Port_Vector.h: Schnittstelle f�r die Klasse CPort_Vector.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PORT_VECTOR_H__23B8D004_0378_4B9F_99B2_E7E713BA7077__INCLUDED_)
#define AFX_PORT_VECTOR_H__23B8D004_0378_4B9F_99B2_E7E713BA7077__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <MmcDefinitions.h>
#ifdef _MMC_I_VECTOR
#include "BaseClasses/PortBase.h"

class CCommand_I_CAN;
class JournalManagerBase;

class CPort_Vector : public CPortBase
{
public:
	CPort_Vector();
	CPort_Vector(CPort_Vector& rObject);
	virtual ~CPort_Vector();
	CPortBase* Clone();

	//Funktionalit�t
	BOOL GetCommands(CStdString* pCommandInfo);

	BOOL I_TransmitCanFrame(HANDLE hTransactionHandle,DWORD dCobId,BOOL oRtr,BYTE uDlc,void* pDataBuffer,DWORD dDataBufferLength,CErrorInfo* pErrorInfo = NULL);
	BOOL I_ReceiveCanFrame(HANDLE hTransactionHandle,DWORD* pdCobId,BOOL* poRtr,BYTE* puDlc,void* pDataBuffer,DWORD dDataBufferLength,CErrorInfo* pErrorInfo = NULL);
	BOOL I_ReceiveFilteredCanFrame(HANDLE hTransactionHandle,DWORD dCobIdFilter,BOOL oRtrFilter,DWORD* pdCobId,BOOL* poRtr,BYTE* puDlc,void* pDataBuffer,DWORD dDataBufferLength,CErrorInfo* pErrorInfo = NULL);

//JournalManager
    virtual void InitJournalManager(CJournalManagerBase *pJournalManager);
    virtual void ResetJournalManager();

private:
	BOOL InitErrorHandling();
	void SetDefault();
	void ResetPortMembers();

	void DeleteCommands();
	void InitCommands();
	void InitCommands(CGatewayIToDrv* pGateway);
	BOOL InitGateway(CGatewayIToDrv* pGateway);

//ParameterSet
	BOOL InitParameterSet();

private:
	CCommand_I_CAN* m_pCommand_TransmitCanFrame;
	CCommand_I_CAN* m_pCommand_ReceiveCanFrame;
	CCommand_I_CAN* m_pCommand_ReceiveFilteredCanFrame;
};
#endif //_MMC_I_VECTOR

#endif // !defined(AFX_PORT_VECTOR_H__23B8D004_0378_4B9F_99B2_E7E713BA7077__INCLUDED_)
