#include "stdafx.h"
#include <cctype> // for toupper
#include <algorithm>
#include <MmcDefinitions.h>
#include "Classes/Interfaces/Interface_RS232.h"
#include "Classes/Interfaces/Interface_USB.h"
#include "Classes/Interfaces/Interface_HID.h"
#include "Classes/Interfaces/Interface_IXXAT.h"
#include "Classes/Interfaces/Interface_Vector.h"
#include "Classes/Interfaces/Interface_NI.h"
#include "Classes/Gateway/USB/Classes/Ftd2xxDeviceInfoHandling.h"
#include "Classes/Gateway/HID/Classes/HidDeviceInfoHandling.h"
#include "Classes/Ports/BaseClasses/PortBase.h"
#include "Classes/Handle/HandleRegistration_I.h"
#include "InterfaceManager.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////
CInterfaceManager::CInterfaceManager():
#ifdef _MMC_I_USB
    m_pUsbDeviceInfoHandling(0),
#endif //_MMC_I_USB
#ifdef _MMC_I_HID
    m_pUsbHidDeviceInfoHandling(0),
#endif //_MMC_I_HID
	m_pHandleRegistrationMap_I(0)
{
    InitErrorHandling();
	InitRegistrationMap();
    CreateUsbDeviceInfoHandling();
}

CInterfaceManager::CInterfaceManager(int p_lInstanceValue)
:   CInterfaceManagerBase(p_lInstanceValue),
#ifdef _MMC_I_USB
    m_pUsbDeviceInfoHandling(0),
#endif //_MMC_I_USB
#ifdef _MMC_I_HID
    m_pUsbHidDeviceInfoHandling(0),
#endif //_MMC_I_HID
	m_pHandleRegistrationMap_I(0)

{
    InitErrorHandling();
	InitRegistrationMap();
    CreateUsbDeviceInfoHandling();
}

CInterfaceManager::CInterfaceManager(const CInterfaceManager& rObject):
    CInterfaceManagerBase(rObject),
#ifdef _MMC_I_USB
    m_pUsbDeviceInfoHandling(0),
#endif
#ifdef _MMC_I_HID
    m_pUsbHidDeviceInfoHandling(0),
#endif //_MMC_I_HID
	m_pHandleRegistrationMap_I(0)

{
    InitErrorHandling();
	InitRegistrationMap();
    CreateUsbDeviceInfoHandling();
}

CInterfaceManagerBase* CInterfaceManager::Clone()
{
    CInterfaceManager* pManager;

    pManager = new CInterfaceManager(*this);
    return pManager;
}

CInterfaceManager::~CInterfaceManager()
{
    ReleaseRegistrationMap();
	DeleteUsbDeviceInfoHandling();
    DeleteInterfaceList();
}

BOOL CInterfaceManager::InitRegistrationMap()
{
	BOOL oResult = FALSE;

	if(!m_pHandleRegistrationMap_I)
	{
		m_pHandleRegistrationMap_I = CHandleRegistrationMap_I::GetInstance(m_lInstanceValue,this);
		if(m_pHandleRegistrationMap_I)
		{
			oResult = TRUE;
		}
	}

	return oResult;
}

BOOL CInterfaceManager::ReleaseRegistrationMap()
{
	BOOL oResult = TRUE;

	if(m_pHandleRegistrationMap_I)
	{
		CHandleRegistrationMap_I::ReleaseInstance(m_lInstanceValue,this);
		m_pHandleRegistrationMap_I = NULL;
	}

	return oResult;
}

BOOL CInterfaceManager::CreateUsbDeviceInfoHandling()
{
    BOOL oResult = FALSE;
#ifdef _MMC_I_USB
    if(!m_pUsbDeviceInfoHandling)
    {
        m_pUsbDeviceInfoHandling = new CFtd2xxDeviceInfoHandling(m_lInstanceValue);
        oResult = TRUE;
    }
#endif //_MMC_I_USB
#ifdef _MMC_I_HID
    if(!m_pUsbHidDeviceInfoHandling)
    {
        m_pUsbHidDeviceInfoHandling = new CHidDeviceInfoHandling();
        oResult = TRUE;
    }
#endif //_MMC_I_HID
    return oResult;
}

BOOL CInterfaceManager::DeleteUsbDeviceInfoHandling()
{
    BOOL oResult = FALSE;
#ifdef _MMC_I_USB
    if(m_pUsbDeviceInfoHandling)
    {
        delete m_pUsbDeviceInfoHandling;
        m_pUsbDeviceInfoHandling = NULL;
        oResult = TRUE;
    }
#endif //_MMC_I_USB
#ifdef _MMC_I_HID
    if(m_pUsbHidDeviceInfoHandling)
    {
        delete m_pUsbHidDeviceInfoHandling;
        m_pUsbHidDeviceInfoHandling = NULL;
        oResult = TRUE;
    }
#endif //_MMC_I_HID
    return oResult;
}

BOOL CInterfaceManager::InitUsbDeviceInfoHandling(CInterfaceBase* pInterface)
{
	BOOL oResult = FALSE;
#ifdef _MMC_I_USB
    CInterface_USB* pUsbInterface = NULL;
	CInterface_HID* pUsbHidInterface = NULL;

	if(pInterface && pInterface->IsKindOf("CInterface_USB"))
   {
        pUsbInterface = (CInterface_USB*)pInterface;
        oResult = pUsbInterface->InitUsbDeviceInfoHandling(m_pUsbDeviceInfoHandling);
    }
	else if(pInterface && pInterface->IsKindOf("CInterface_HID"))
    {
        pUsbHidInterface = (CInterface_HID*)pInterface;
        oResult = pUsbHidInterface->InitUsbDeviceInfoHandling(m_pUsbHidDeviceInfoHandling);
    }
#endif
    return oResult;
}

BOOL CInterfaceManager::ExecuteCommand(CCommandRoot *pCommand, HANDLE hHandle, HANDLE hTransactionHandle)
{
    CInterfaceBase* pInterface = NULL;
    CPortBase* pPort = NULL;
    CHandleRegistration_I* pRegistration = NULL;
	BOOL oResult = FALSE;

    if(m_pHandleRegistrationMap_I)
	{
		if(CheckLayer(pCommand))
		{
			//Init
			oResult = TRUE;

			//GetRegistration
			if(oResult && !m_pHandleRegistrationMap_I->GetRegistration(hHandle, &pRegistration) || (pRegistration == NULL))
			{
				oResult = FALSE;
			}
			
			//Lock (Only if Registration is not locked from last command)
			if(oResult && !pRegistration->IsLocked())
			{
				oResult = pRegistration->DoLock();
			}

			//GetRegistrationEntries
			if(oResult && !m_pHandleRegistrationMap_I->GetRegistrationValues(hHandle, &pInterface, &pPort) ||(pInterface == NULL) ||(pPort == NULL))
			{
				oResult = FALSE;
			}

			//ExecuteCommand
			if(oResult && !pInterface->ExecuteCommand(pCommand, pPort, hTransactionHandle))
			{
				oResult = FALSE;
			}

			//Unlock (Only if Interface does not remain locked until next command)
			if(pInterface && !pInterface->IsLocked())
			{
				//Unlock
				if(pRegistration) pRegistration->DoUnlock();
			}
		}
	}

    return oResult;
}

BOOL CInterfaceManager::AbortCommands(HANDLE hHandle, BOOL oActive)
{
    CInterfaceBase* pInterface = NULL;
    CPortBase* pPort = NULL;
    CHandleRegistration_I* pRegistration = NULL;

    if(m_pHandleRegistrationMap_I)
	{
		//GetRegistration
		if(!m_pHandleRegistrationMap_I->GetRegistration(hHandle, &pRegistration) || (pRegistration == NULL)) return FALSE;

		//GetRegistrationEntries
		if(!m_pHandleRegistrationMap_I->GetRegistrationValues(hHandle, &pInterface, &pPort) ||(pInterface == NULL) ||(pPort == NULL))
		{
			return FALSE;
		}

		//AbortCommands
		if(!pInterface->AbortCommands(oActive))
		{
			return FALSE;
		}

		//Abort Lock
		pRegistration->AbortLock(oActive);

		return TRUE;
	}

	return FALSE;
}

BOOL CInterfaceManager::GetLayerManager(HANDLE hHandle, ELayer eLayer, CLayerManagerBase** ppLayerManager)
{
    if(CheckLayer(eLayer))
    {
        if(ppLayerManager) *ppLayerManager = this;
        return TRUE;
    }

    return FALSE;
}

BOOL CInterfaceManager::GetCommands(HANDLE hHandle, ELayer eLayer, CStdString* pCommandInfo)
{
    CInterfaceBase* pInterface = NULL;
    CPortBase* pPort = NULL;

    if(m_pHandleRegistrationMap_I)
	{
		//GetRegistrationEntries
		if(!m_pHandleRegistrationMap_I->GetRegistrationValues(hHandle, &pInterface, &pPort) ||(pInterface == NULL) ||(pPort == NULL))
		{
			return FALSE;
		}

		if(CheckLayer(eLayer))
		{
			//GetCommands
			return pPort->GetCommands(pCommandInfo);
		}
	}

    return FALSE;
}

BOOL CInterfaceManager::I_InitAllInterfaces(CErrorInfo* pErrorInfo)
{
    BOOL oResult = TRUE;

    //Rest
    DeleteInterfaceList();

    //Init RS232
    if(!I_InitInterface(INTERFACE_RS232, pErrorInfo))
    {
        oResult = FALSE;
    }

    //Init USB
    if(!I_InitInterface(INTERFACE_USB, pErrorInfo))
    {
        oResult = FALSE;
    }

    //Init HID
    if(!I_InitInterface(INTERFACE_HID, pErrorInfo))
    {
        oResult = FALSE;
    }

    //Init IXXAT
    if(!I_InitInterface(INTERFACE_IXXAT, pErrorInfo))
    {
        oResult = FALSE;
    }

    //Init Vector
    if(!I_InitInterface(INTERFACE_VECTOR, pErrorInfo))
    {
        oResult = FALSE;
    }

    //Init NI
    if(!I_InitInterface(INTERFACE_NI, pErrorInfo))
    {
        oResult = FALSE;
    }

    return oResult;
}

BOOL CInterfaceManager::I_InitInterface(CStdString strInterfaceName, CErrorInfo* pErrorInfo)
{
    CMmcSingleLock lock(&m_Sync, TRUE);
    CInterfaceBase* pInterface = NULL;

    std::transform( strInterfaceName.begin(),
    					strInterfaceName.end(),
    					strInterfaceName.begin(),
    					(int(*)(int)) toupper);

    std::string strRefName = INTERFACE_RS232;

    std::transform( strRefName.begin(),
    					strRefName.end(),
    					strRefName.begin(),
    					(int(*)(int)) toupper);
#ifdef _MMC_I_RS232
    //RS232
    if(strInterfaceName==strRefName)
    {
        //Interface is already existing
        if(FindInterface(strInterfaceName, NULL))
        	return TRUE;

        //Interface RS232 in der Liste eintragen
        pInterface = new CInterface_RS232();
		pInterface->InitInstanceValue(m_lInstanceValue);
        if(pInterface->InitInterface())
        {
            m_InterfaceList.push_back(pInterface);
            return TRUE;
        }
        delete pInterface;
    }
#endif //_MMC_I_RS232
    WORD w, wNb, wNb_IXXAT_V2 = 0;
#ifdef _MMC_I_USB
    //USB
    if(strInterfaceName.CompareNoCase(INTERFACE_USB) == 0)
    {
        //Interface is already existing
        if(FindInterface(strInterfaceName, NULL)) return TRUE;
        //Interface USB in der Liste eintragen
        pInterface = new CInterface_USB();
		pInterface->InitInstanceValue(m_lInstanceValue);
        if(InitUsbDeviceInfoHandling(pInterface))
        {
            if(pInterface->InitInterface())
            {
                m_InterfaceList.push_back(pInterface);
                return TRUE;
            }
        }
        delete pInterface;
    }
#endif //_MMC_I_USB
#ifdef _MMC_I_HID
	//HID
    if(strInterfaceName.CompareNoCase(INTERFACE_HID) == 0)
    {
        //Interface is already existing
        if(FindInterface(strInterfaceName, NULL)) return TRUE;
        //Interface HID in der Liste eintragen
        pInterface = new CInterface_HID();
		pInterface->InitInstanceValue(m_lInstanceValue);
        if(InitUsbDeviceInfoHandling(pInterface))
        {
            if(pInterface->InitInterface())
            {
                m_InterfaceList.push_back(pInterface);
                return TRUE;
            }
        }
        delete pInterface;
    }
#endif //_MMC_I_HID
#ifdef _MMC_I_IXXAT
    //IXXAT
    if(strInterfaceName.CompareNoCase(INTERFACE_IXXAT) == 0)
    {
        //Interface is already existing
        for(std::list<CInterfaceBase*>::iterator it=
        		m_InterfaceList.begin(); it != m_InterfaceList.end(); it++)
        {
			if(pInterface->IsKindOf("CInterface_IXXAT"))
				return TRUE;
        }
        //Treiber V2
        wNb = GetNbOfAvailableBoards_IXXAT(k_IXXAT_V2);
        for(w=0;w<wNb;w++)
        {
            pInterface = new CInterface_IXXAT();
			pInterface->InitInstanceValue(m_lInstanceValue);
            pInterface->I_SetInterfaceMode(k_IXXAT_V2);

            if(pInterface->InitInterface(w))
            {
                m_InterfaceList.push_back(pInterface);
                wNb_IXXAT_V2++;
            }
            else
            {
                delete pInterface;
            }
        }

        //Treiber V3
        wNb = GetNbOfAvailableBoards_IXXAT(k_IXXAT_V3);
        for(w=0;w<wNb;w++)
        {
            pInterface = new CInterface_IXXAT();
			pInterface->InitInstanceValue(m_lInstanceValue);
            pInterface->I_SetInterfaceMode(k_IXXAT_V3);

            if(pInterface->InitInterface(w, wNb_IXXAT_V2))
                m_InterfaceList.push_back(pInterface);
            else
                delete pInterface;
        }
        if(m_InterfaceList.size()==0) return FALSE;

        return TRUE;
    }
#endif //_MMC_I_IXXAT
#ifdef _MMC_I_VECTOR
    //VECTOR
    if(strInterfaceName.CompareNoCase(INTERFACE_VECTOR) == 0)
    {
        //Interface is already existing
    	for(std::list<CInterfaceBase*>::iterator it=
    	        		m_InterfaceList.begin(); it != m_InterfaceList.end(); it++)
		{
			if(pInterface->IsKindOf("CInterface_Vector"))
				return TRUE;
		}
        //Interface Vector in der Liste eintragen
        wNb = GetNbOfAvailableBoards_Vector();
        for(w=0;w<wNb;w++)
        {
            pInterface = new CInterface_Vector();
			pInterface->InitInstanceValue(m_lInstanceValue);
            if(pInterface->InitInterface(w))
            {
                m_InterfaceList.push_back(pInterface);
            }
            else
            {
                delete pInterface;
            }
        }
		if(m_InterfaceList.empty()) return FALSE;

        return TRUE;
    }
#endif //_MMC_I_VECTOR
#ifdef _MMC_I_NI
    //NI
    if(strInterfaceName.CompareNoCase(INTERFACE_NI) == 0)
    {
        //Interface is already existing
    	for(std::list<CInterfaceBase*>::iterator it=
    	    m_InterfaceList.begin(); it != m_InterfaceList.end(); it++)
		{
			if(pInterface->IsKindOf("CInterface_NI"))
				return TRUE;
		}
        //Interface NI in der Liste eintragen
        wNb = GetNbOfAvailableBoards_NI();
        for(w=0;w<wNb;w++)
        {
            pInterface = new CInterface_NI();
			pInterface->InitInstanceValue(m_lInstanceValue);
            if(pInterface->InitInterface(w))
            {
                m_InterfaceList.push_back(pInterface);
            }
            else
            {
                delete pInterface;
            }
        }
        if(m_InterfaceList.size()>0) return FALSE;

        return TRUE;
    }
#endif //_MMC_I_NI

    return FALSE;
}

BOOL CInterfaceManager::I_UpdateInterface(CStdString strInterfaceName, CErrorInfo* pErrorInfo)
{
    CMmcSingleLock lock(&m_Sync, TRUE);
    BOOL oResult = FALSE;

    std::transform( strInterfaceName.begin(),
        						strInterfaceName.end(),
        						strInterfaceName.begin(),
        						(int(*)(int)) toupper);

    if(m_pHandleRegistrationMap_I)
	{
    	std::string strRefName = INTERFACE_RS232;

    	    std::transform( strRefName.begin(),
    	    					strRefName.end(),
    	    					strRefName.begin(),
    	    					(int(*)(int)) toupper);

    	//RS232
		if(strInterfaceName==strRefName)
		{
			//Delete Interfaces
			if(DeleteAllInterfaces(strInterfaceName, TRUE))
			{
				//Reinit Interfaces
				oResult = I_InitInterface(strInterfaceName);
			}
		}
		tPortList openPortList;
		CInterfaceBase* pInterface = NULL;
		//USB
		if(strInterfaceName.CompareNoCase(INTERFACE_USB) == 0)
		{
			//Interface is existing
			if(FindInterface(strInterfaceName, &pInterface) && pInterface)
			{
				if(m_pHandleRegistrationMap_I->GetRegisteredPorts(pInterface, openPortList))
				{
					oResult = pInterface->UpdateInterface(openPortList);
				}
			}
		}

		//HID
		if(strInterfaceName.CompareNoCase(INTERFACE_HID) == 0)
		{
		
			//Interface is existing
			if(FindInterface(strInterfaceName, &pInterface) && pInterface)
			{
				if(m_pHandleRegistrationMap_I->GetRegisteredPorts(pInterface, openPortList))
				{
					oResult = pInterface->UpdateInterface(openPortList);
				}
			}
		}
		
		//IXXAT
		if(strInterfaceName.CompareNoCase(INTERFACE_IXXAT) == 0)
		{
			//Delete Interfaces
			if(DeleteAllInterfaces(strInterfaceName, TRUE))
			{
				//Reinit Interfaces
				oResult = I_InitInterface(strInterfaceName);
			}
		}

		//VECTOR
		if(strInterfaceName.CompareNoCase(INTERFACE_VECTOR) == 0)
		{
			//Delete Interfaces
			if(DeleteAllInterfaces(strInterfaceName, TRUE))
			{
				//Reinit Interfaces
				oResult = I_InitInterface(strInterfaceName);
			}
		}

		//NI
		if(strInterfaceName.CompareNoCase(INTERFACE_NI) == 0)
		{
			//Delete Interfaces
			if(DeleteAllInterfaces(strInterfaceName, TRUE))
			{
				//Reinit Interfaces
				oResult = I_InitInterface(strInterfaceName);
			}
		}
	}
    return oResult;
}

BOOL CInterfaceManager::I_InitBaudrateSelection(CStdString strInterfaceName, CStdDWordArray& dBaudrateSel, CErrorInfo* pErrorInfo)
{
    CMmcSingleLock lock(&m_Sync, TRUE);
    CInterfaceBase* pInterface = NULL;
    BOOL oResult = TRUE;

    if(FindInterface(strInterfaceName, &pInterface))
    {
        if(pInterface)
        {
            if(!pInterface->InitBaudrateSelection(dBaudrateSel))
            {
                if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
                oResult = FALSE;
            }
        }
    }

    return oResult;
}

BOOL CInterfaceManager::I_InitDefaultInterfaceSettings(CStdString strInterfaceName, DWORD dBaudrate, DWORD dTimeout, CErrorInfo* pErrorInfo)
{
    CMmcSingleLock lock(&m_Sync, TRUE);
    CInterfaceBase* pInterface = NULL;
    BOOL oResult = TRUE;

    if(FindInterface(strInterfaceName, &pInterface))
    {
        if(pInterface)
        {
            if(!pInterface->InitDefaultInterfaceSettings(dBaudrate, dTimeout))
            {
                if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
                oResult = FALSE;
            }
        }
    }

    return oResult;
}

void CInterfaceManager::DeleteInterfaceList()
{
    for(std::list<CInterfaceBase*>::iterator it=m_InterfaceList.begin();
    		it!=m_InterfaceList.end(); it++)
    {
    	CInterfaceBase* pInterface = (*it);
        delete pInterface;
    }
    m_InterfaceList.clear();
}

BOOL CInterfaceManager::FindInterfaceIndex(CStdString strInterfaceName, short* piInterfaceIndex)
{
    CStdString strName;
    short index = 0;

    std::transform( strInterfaceName.begin(),
            			strInterfaceName.end(),
            			strInterfaceName.begin(),
            	        						(int(*)(int)) toupper);

    for(std::list<CInterfaceBase*>::iterator it=m_InterfaceList.begin();
        		it!=m_InterfaceList.end(); it++)
    {
    	CInterfaceBase* pInterface = (*it);
        if(pInterface->I_GetInterfaceName(&strName))
        {
        	std::transform( strName.begin(),
        			strName.end(),
        			strName.begin(),
        						(int(*)(int)) toupper);

            if(strName == strInterfaceName)
            {
                if(piInterfaceIndex) *piInterfaceIndex = index;
                return TRUE;
            }
        }
        index++;
    }

    if(piInterfaceIndex) *piInterfaceIndex = -1;
    return FALSE;
}

BOOL CInterfaceManager::FindInterface(CStdString strInterfaceName, CInterfaceBase** ppInterface)
{
    CStdString strName;

    std::transform( strInterfaceName.begin(),
            	        			strInterfaceName.end(),
            	        			strInterfaceName.begin(),
            	        	        						(int(*)(int)) toupper);

    for(std::list<CInterfaceBase*>::iterator it=m_InterfaceList.begin();
            		it!=m_InterfaceList.end(); it++)
    {
    	CInterfaceBase* pInterface = (*it);
        if(pInterface && pInterface->I_GetInterfaceName(&strName))
        {
        	std::transform( strName.begin(),
        	        			strName.end(),
        	        			strName.begin(),
        	        						(int(*)(int)) toupper);

            if(strName==strInterfaceName)
            {
                if(ppInterface) *ppInterface = pInterface;
                return TRUE;
            }
        }
    }

    return FALSE;
}

BOOL CInterfaceManager::DeleteInterface(CStdString strInterfaceName, BOOL oCheckPrefixOnly)
{
    CStdString strName = _T("");
    BOOL oResult = FALSE;

    for(std::list<CInterfaceBase*>::iterator it=m_InterfaceList.begin();
                		it!=m_InterfaceList.end(); it++)
    {
        	CInterfaceBase* pInterface = (*it);
        if(pInterface && pInterface->I_GetInterfaceName(&strName))
        {
            if((oCheckPrefixOnly && strName.find(strInterfaceName) == 0) || (!oCheckPrefixOnly && strName.CompareNoCase(strInterfaceName) == 0))
            {
                m_InterfaceList.remove(pInterface);
                delete pInterface;
                oResult = TRUE;
                break;
            }
        }
    }

    return oResult;
}

BOOL CInterfaceManager::DeleteAllInterfaces(CStdString strInterfaceName, BOOL oCheckPrefixOnly)
{
    BOOL oInterfaceDeleted = TRUE;
    BOOL oResult = TRUE;

    //Delete All Interfaces
    while(oInterfaceDeleted)
    {
        oInterfaceDeleted = DeleteInterface(strInterfaceName, oCheckPrefixOnly);
    }

    return oResult;
}

BOOL CInterfaceManager::I_IsInterfaceNameSupported(CStdString strInterfaceName, CErrorInfo* pErrorInfo)
{
    return FindInterface(strInterfaceName, NULL);
}

BOOL CInterfaceManager::FindInterfacePortIndex(CStdString strInterfaceName, CStdString strPortName, short* piPortIndex)
{
    CInterfaceBase* pInterface = NULL;

    if(FindInterface(strInterfaceName, &pInterface) && pInterface)
    {
        return pInterface->I_FindInterfacePortIndex(strPortName, piPortIndex);
    }

    return FALSE;
}

BOOL CInterfaceManager::FindPort(CStdString strInterfaceName, CStdString strPortName, CPortBase** ppPort)
{
    CInterfaceBase* pInterface = NULL;

    if(FindInterface(strInterfaceName, &pInterface) && pInterface)
    {
        return pInterface->I_FindPort(strInterfaceName, strPortName, ppPort);
    }

    return FALSE;
}

HANDLE CInterfaceManager::I_OpenInterface(CStdString strInterfaceName, CStdString strPortName, CErrorInfo* pErrorInfo)
{
    CMmcSingleLock lock(&m_Sync, TRUE);
    CInterfaceBase* pInterface = NULL;
    CInterfaceBase* pExistingInterface = NULL;
    CPortBase* pPort = NULL;
    HANDLE hI_Handle = 0;

    if(m_pHandleRegistrationMap_I)
	{
		//Suchen Position der Schnittstellen in der Liste
		if(!FindInterface(strInterfaceName, &pInterface))
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_BadInterfaceName, pErrorInfo);
			return (HANDLE)0;
		}
		//Suche Position des Ports in der Liste
		if(!FindPort(strInterfaceName, strPortName, &pPort))
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_BadPortName, pErrorInfo);
			return (HANDLE)0;
		}

		//�berpr�fen ob Interface & Port schon offen
		hI_Handle = m_pHandleRegistrationMap_I->IsRegistrationExisting(pInterface, strPortName);
		if(!hI_Handle)
		{
			//�berpr�fen ob Interface schon offen
			hI_Handle = m_pHandleRegistrationMap_I->IsRegistrationExisting(pInterface);
			if(hI_Handle)
			{
				//Interface schon offen -> nur Port �ffnen
				if(m_pHandleRegistrationMap_I->GetRegistrationValues(hI_Handle, &pExistingInterface, NULL) && pExistingInterface)
				{
					pInterface = pExistingInterface;

					//Schnittstelle in der Mappe registrieren (-> Clone)
					hI_Handle = m_pHandleRegistrationMap_I->RegisterHandle(pInterface, pPort);
					if(hI_Handle)
					{
						if(m_pHandleRegistrationMap_I->GetRegistrationValues(hI_Handle, &pInterface, &pPort) && pInterface && pPort)
						{
							//Port �ffnen
							if(pInterface->I_OpenInterfacePort(pPort, strPortName, pErrorInfo))
							{
								return hI_Handle;
							}
							else
							{
								m_pHandleRegistrationMap_I->DeleteMapRegistration(hI_Handle);
								return (HANDLE)0;
							}
						}

						m_pHandleRegistrationMap_I->DeleteMapRegistration(hI_Handle);
					}

					if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
					return (HANDLE)0;
				}
			}
			else
			{
				//Schnittstelle in der Mappe registrieren (-> Clone)
				hI_Handle = m_pHandleRegistrationMap_I->RegisterHandle(pInterface, pPort);
				if(hI_Handle)
				{
					if(m_pHandleRegistrationMap_I->GetRegistrationValues(hI_Handle, &pInterface, &pPort) && pInterface && pPort)
					{
						//Interface & Port �ffnen
						if(pInterface->I_OpenInterface(pErrorInfo))
						{
							if(pInterface->I_OpenInterfacePort(pPort, strPortName, pErrorInfo))
							{
								return hI_Handle;
							}
							else
							{
								m_pHandleRegistrationMap_I->DeleteMapRegistration(hI_Handle);
								return (HANDLE)0;
							}
						}
						else
						{
							m_pHandleRegistrationMap_I->DeleteMapRegistration(hI_Handle);
							return (HANDLE)0;
						}
					}

					m_pHandleRegistrationMap_I->DeleteMapRegistration(hI_Handle);
				}

				if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
				return (HANDLE)0;
			}
		}
	}

    return hI_Handle;
}

BOOL CInterfaceManager::I_CloseInterface(HANDLE hI_Handle, CErrorInfo* pErrorInfo)
{
    CMmcSingleLock lock(&m_Sync, TRUE);
    CInterfaceBase* pInterface = NULL;
    CPortBase* pPort = NULL;
    CHandleRegistration_I* pRegistration = NULL;
    int portCount = 0;

    if(m_pHandleRegistrationMap_I)
	{
		//Get Registration
		if(!m_pHandleRegistrationMap_I->GetRegistration(hI_Handle, &pRegistration) || (pRegistration == NULL))
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_HandleNotValid, pErrorInfo);
			return FALSE;
		}

		//Lock
		if(!pRegistration->DoLock())
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
			return FALSE;
		}

		//Get Registration Values
		if(!m_pHandleRegistrationMap_I->GetRegistrationValues(hI_Handle, &pInterface, &pPort) || (pInterface == NULL) || (pPort == NULL))
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
			if(pRegistration) pRegistration->DoUnlock();
			return FALSE;
		}

		//Anzahl ge�ffnete Ports pro Interface ermitteln
		portCount = m_pHandleRegistrationMap_I->GetRegistrationCount(pInterface);

		//InterfacePort schliessen
		if(pInterface->I_CloseInterfacePort(pPort, pErrorInfo))
		{
			//Interface schliessen
			if(portCount == 1)
			{
				if(pInterface->I_CloseInterface(pErrorInfo))
				{
					m_pHandleRegistrationMap_I->DeleteMapRegistration(hI_Handle);
					if(pRegistration) pRegistration->DoUnlock();
					return TRUE;
				}
				else
				{
					m_pHandleRegistrationMap_I->DeleteMapRegistration(hI_Handle);
					if(pRegistration) pRegistration->DoUnlock();
					return FALSE;
				}
			}
			else
			{
				//Registrierte Werte aus der Mappe l�schen
				if(m_pHandleRegistrationMap_I->DeleteMapRegistration(hI_Handle))
				{
					if(pRegistration) pRegistration->DoUnlock();
					return TRUE;
				}
				else
				{
					if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
					if(pRegistration) pRegistration->DoUnlock();
					return FALSE;
				}
			}
		}
		else
		{
			if(pRegistration) pRegistration->DoUnlock();
			return FALSE;
		}
	}

	return FALSE;
}

BOOL CInterfaceManager::I_CloseAllInterfaces(CErrorInfo* pErrorInfo)
{
    tHandleRegistrationI_List* pRegistrationList;

	if(m_pHandleRegistrationMap_I)
	{
		if(m_pHandleRegistrationMap_I->GetRegistrationList(&pRegistrationList) && pRegistrationList)
		{
			while(pRegistrationList->size() > 0)
			{
				tHandleRegistrationI_List::iterator it = pRegistrationList->begin();
				if( it != pRegistrationList->end() )
				{
					CHandleRegistration_I* pRegistration = (*it);
					if(pRegistration)
					{
						HANDLE hIHandle = pRegistration->GetKeyHandle();
						if(hIHandle)
							if(!I_CloseInterface(hIHandle, pErrorInfo)) return FALSE;

						pRegistrationList->remove(pRegistration);

						//Delete Registration
						delete pRegistration;
					}
				}
			}

			return TRUE;
		}
	}

    return FALSE;
}

BOOL CInterfaceManager::I_AreAllInterfacesClosed()
{
	BOOL oResult = FALSE;

	if(m_pHandleRegistrationMap_I)
	{
		oResult = m_pHandleRegistrationMap_I->IsRegistrationMapEmpty();
	}

	return oResult;
}

BOOL CInterfaceManager::I_SetInterfaceSettings(HANDLE hI_Handle, DWORD dBaudrate, DWORD dTimeout, BOOL oChangeOnly, CErrorInfo* pErrorInfo)
{
    CInterfaceBase* pInterface = NULL;
    CPortBase* pPort = NULL;
    CHandleRegistration_I* pRegistration = NULL;

    if(m_pHandleRegistrationMap_I)
	{
		//Get Registration
		if(!m_pHandleRegistrationMap_I->GetRegistration(hI_Handle, &pRegistration) || (pRegistration == NULL))
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_HandleNotValid, pErrorInfo);
			return FALSE;
		}

		//Lock
		if(!pRegistration->DoLock())
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
			return FALSE;
		}

		//Get Registration Values
		if(!m_pHandleRegistrationMap_I->GetRegistrationValues(hI_Handle, &pInterface, &pPort) || (pInterface == NULL) || (pPort == NULL))
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
			if(pRegistration) pRegistration->DoUnlock();
			return FALSE;
		}

		//SetInterfaceSettings
		if(!pInterface->I_SetInterfaceSettings(pPort, dBaudrate, dTimeout, oChangeOnly, pErrorInfo))
		{
			if(pRegistration) pRegistration->DoUnlock();
			return FALSE;
		}

		if(pRegistration) pRegistration->DoUnlock();
		return TRUE;
	}

	return FALSE;
}

BOOL CInterfaceManager::I_GetInterfaceSettings(HANDLE hI_Handle, DWORD* pdBaudrate, DWORD* pdTimeout, CErrorInfo* pErrorInfo)
{
    CInterfaceBase* pInterface = NULL;
    CPortBase* pPort = NULL;
    CHandleRegistration_I* pRegistration = NULL;

    if(m_pHandleRegistrationMap_I)
	{

		//Get Registration
		if(!m_pHandleRegistrationMap_I->GetRegistration(hI_Handle, &pRegistration) || (pRegistration == NULL))
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_HandleNotValid, pErrorInfo);
			return FALSE;
		}

		//Lock
		if(!pRegistration->DoLock())
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
			return FALSE;
		}

		//Get Registration Values
		if(!m_pHandleRegistrationMap_I->GetRegistrationValues(hI_Handle, &pInterface, &pPort) || (pInterface == NULL) || (pPort == NULL))
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
			if(pRegistration) pRegistration->DoUnlock();
			return FALSE;
		}

		//GetInterfaceSettings
		if(!pInterface->I_GetInterfaceSettings(pPort, pdBaudrate, pdTimeout, pErrorInfo))
		{
			if(pRegistration) pRegistration->DoUnlock();
			return FALSE;
		}

		if(pRegistration) pRegistration->DoUnlock();
		return TRUE;
	}

	return FALSE;
}

BOOL CInterfaceManager::I_ResetInterface(HANDLE hI_Handle, CErrorInfo* pErrorInfo)
{
    CInterfaceBase* pInterface = NULL;
    CPortBase* pPort = NULL;
    CHandleRegistration_I* pRegistration = NULL;

    if(m_pHandleRegistrationMap_I)
	{
		//Get Registration
		if(!m_pHandleRegistrationMap_I->GetRegistration(hI_Handle, &pRegistration) || (pRegistration == NULL))
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_HandleNotValid, pErrorInfo);
			return FALSE;
		}

		//Lock
		if(!pRegistration->DoLock())
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
			return FALSE;
		}

		//Get Registration Values
		if(!m_pHandleRegistrationMap_I->GetRegistrationValues(hI_Handle, &pInterface, &pPort) || (pInterface == NULL) || (pPort == NULL))
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
			if(pRegistration) pRegistration->DoUnlock();
			return FALSE;
		}

		//ResetInterface
		if(!pInterface->I_ResetInterface(pPort, pErrorInfo))
		{
			if(pRegistration) pRegistration->DoUnlock();
			return FALSE;
		}

		if(pRegistration) pRegistration->DoUnlock();
		return TRUE;
	}

	return FALSE;
}

BOOL CInterfaceManager::SetParameter(EParameterType p_eParameterType, HANDLE hI_Handle, CStdString p_Name, BYTE* p_pValue, DWORD p_ulSize, CErrorInfo* pErrorInfo)
{
	BOOL oResult = FALSE;

    if(m_pHandleRegistrationMap_I)
	{
		oResult = m_pHandleRegistrationMap_I->SetParameter(p_eParameterType, hI_Handle, p_Name, p_pValue, p_ulSize, pErrorInfo);
	}

	return oResult;
}

BOOL CInterfaceManager::SetParameter(EParameterType p_eParameterType, HANDLE hI_Handle, CStdString p_Name, CStdString p_Value, CErrorInfo* pErrorInfo)
{
	BOOL oResult = FALSE;

    if(m_pHandleRegistrationMap_I)
	{
		oResult = m_pHandleRegistrationMap_I->SetParameter(p_eParameterType, hI_Handle, p_Name, p_Value, pErrorInfo);
	}

	return oResult;
}

BOOL CInterfaceManager::GetParameter(EParameterType p_eParameterType, HANDLE hI_Handle, CStdString p_Name, BYTE* p_pValue, DWORD p_ulSize, CErrorInfo* pErrorInfo)
{
	BOOL oResult = FALSE;

    if(m_pHandleRegistrationMap_I)
	{
		oResult = m_pHandleRegistrationMap_I->GetParameter(p_eParameterType, hI_Handle, p_Name, p_pValue, p_ulSize, pErrorInfo);
	}

	return oResult;
}

BOOL CInterfaceManager::GetParameter(EParameterType p_eParameterType, HANDLE hVCS_Handle, CStdString p_Name, CStdString& p_rValue, CErrorInfo* pErrorInfo)
{
	BOOL oResult = FALSE;

    if(m_pHandleRegistrationMap_I)
	{
		oResult = m_pHandleRegistrationMap_I->GetParameter(p_eParameterType, hVCS_Handle, p_Name, p_rValue, pErrorInfo);
	}

	return oResult;
}


//Schnittstellen-Handle der offenen Schnittstelle holen
BOOL CInterfaceManager::I_GetKeyHandle(CStdString strInterfaceName, CStdString strPortName, HANDLE* pIKeyHandle, CErrorInfo* pErrorInfo)
{
	HANDLE hKeyHandle = 0;
    BOOL oInterfaceNameFound = FALSE;
    BOOL oPortNameFound = FALSE;
    CHandleRegistration_I* pRegistration = NULL;
    CInterfaceBase* pInterface = NULL;
    CPortBase* pPort = NULL;
    CStdString strInterfaceNameReg;
    CStdString strPortNameReg;
    tHandleRegistrationI_List* pRegistrationList = NULL;

    if(m_pHandleRegistrationMap_I)
	{
		if(m_pHandleRegistrationMap_I->GetRegistrationList(&pRegistrationList) && pRegistrationList)
		{
			for(tHandleRegistrationI_List::iterator it = pRegistrationList->begin();
					it!=pRegistrationList->end(); it++)
			{
				pRegistration = (*it);

				pRegistration->GetRegistrationValues(&pInterface, &pPort);

				if(!pInterface || !pPort)
				{
					if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
					return FALSE;
				}

				//Compare InterfaceName
				if(pInterface->I_GetInterfaceName(&strInterfaceNameReg))
				{
					if(strInterfaceNameReg.CompareNoCase(strInterfaceName) == 0)
					{
						oInterfaceNameFound = TRUE;

						//Compare PortName
						if(pPort->GetPortName(&strPortNameReg))
						{
							//0 = string1 identical to string2
							if(strPortNameReg.CompareNoCase(strPortName) == 0)
							{
								oPortNameFound = TRUE;
								hKeyHandle = pRegistration->GetKeyHandle();
							}
						}
					}
				}
			}
		}
	}

    //ErrorHandling
    if(hKeyHandle == 0)
    {
        if(m_pErrorHandling)
        {
            if(!oInterfaceNameFound)    m_pErrorHandling->GetError(k_Error_BadInterfaceName, pErrorInfo);
            else if(!oPortNameFound)    m_pErrorHandling->GetError(k_Error_BadPortName, pErrorInfo);
            else if(!hKeyHandle)        m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
        }
    }

    if(pIKeyHandle) *pIKeyHandle = hKeyHandle;
    return (hKeyHandle != 0);
}

BOOL CInterfaceManager::I_GetInterfaceName(HANDLE hI_Handle, CStdString* pInterfaceName, CErrorInfo* pErrorInfo)
{
    CInterfaceBase* pInterface = NULL;
    CPortBase* pPort = NULL;
    CHandleRegistration_I* pRegistration = NULL;

    if(m_pHandleRegistrationMap_I)
	{
		//Get Registration
		if(!m_pHandleRegistrationMap_I->GetRegistration(hI_Handle, &pRegistration) || (pRegistration == NULL))
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_HandleNotValid, pErrorInfo);
			return FALSE;
		}

		//Lock
		if(!pRegistration->DoLock())
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
			return FALSE;
		}

		//Get Registration Values
		if(!m_pHandleRegistrationMap_I->GetRegistrationValues(hI_Handle, &pInterface, &pPort) || (pInterface == NULL) || (pPort == NULL))
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
			if(pRegistration) pRegistration->DoUnlock();
			return FALSE;
		}

		//GetInterfaceName
		if(!pInterface->I_GetInterfaceName(pInterfaceName))
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
			if(pRegistration) pRegistration->DoUnlock();
			return FALSE;
		}

		if(pRegistration) pRegistration->DoUnlock();
		return TRUE;
	}

	return FALSE;
}

BOOL CInterfaceManager::I_GetInterfaceNameSelection(CStdStringArray* pInterfaceNameSel, CErrorInfo* pErrorInfo)
{
    CMmcSingleLock lock(&m_Sync, TRUE);
    CStdString strNameSel;

    if(pInterfaceNameSel)
    {
        pInterfaceNameSel->clear();

        for(std::list<CInterfaceBase*>::iterator it=m_InterfaceList.begin();
        		it!=m_InterfaceList.end(); it++)
        {
        	CInterfaceBase* pInterface = (*it);
            if(pInterface->I_GetInterfaceName(&strNameSel))
                pInterfaceNameSel->push_back(strNameSel);
        }

        return TRUE;
    }

    if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_NullPointer, pErrorInfo);
    return FALSE;
}

BOOL CInterfaceManager::I_GetPortName(HANDLE hI_Handle, CStdString* pPortName, CErrorInfo* pErrorInfo)
{
    CInterfaceBase* pInterface = NULL;
    CPortBase* pPort = NULL;
    CHandleRegistration_I* pRegistration = NULL;

    if(m_pHandleRegistrationMap_I)
	{
		//Get Registration
		if(!m_pHandleRegistrationMap_I->GetRegistration(hI_Handle, &pRegistration) || (pRegistration == NULL))
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_HandleNotValid, pErrorInfo);
			return FALSE;
		}

		//Lock
		if(!pRegistration->DoLock())
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
			return FALSE;
		}

		//Get Registration Values
		if(!m_pHandleRegistrationMap_I->GetRegistrationValues(hI_Handle, &pInterface, &pPort) || (pInterface == NULL) || (pPort == NULL))
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
			if(pRegistration) pRegistration->DoUnlock();
			return FALSE;
		}

		//GetPortName
		if(!pPort->GetPortName(pPortName))
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
			if(pRegistration) pRegistration->DoUnlock();
			return FALSE;
		}

		if(pRegistration) pRegistration->DoUnlock();
		return TRUE;
	}

	return FALSE;
}

BOOL CInterfaceManager::I_GetPortNameSelection(CStdString strInterfaceName, CStdStringArray* pPortSel, CErrorInfo* pErrorInfo)
{
    CMmcSingleLock lock(&m_Sync, TRUE);
    CInterfaceBase* pInterface = NULL;

    //FindInterface
    if(!FindInterface(strInterfaceName, &pInterface) || (pInterface == NULL))
    {
        if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_BadInterfaceName, pErrorInfo);
        return FALSE;
    }

    //GetPortNameSelection
    return pInterface->I_GetPortNameSelection(pPortSel, pErrorInfo);
}

BOOL CInterfaceManager::I_GetBaudrateSelection(CStdString strInterfaceName, CStdString strPortName, CStdDWordArray* pdBaudrateSel, CErrorInfo* pErrorInfo)
{
    CMmcSingleLock lock(&m_Sync, TRUE);
    CInterfaceBase* pInterface = NULL;

    //FindInterface
    if(!FindInterface(strInterfaceName, &pInterface) || (pInterface == NULL))
    {
        if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_BadInterfaceName, pErrorInfo);
        return FALSE;
    }

    //GetBaudrateSelection
    return pInterface->I_GetBaudrateSelection(strPortName, pdBaudrateSel, pErrorInfo);
}

WORD CInterfaceManager::GetNbOfAvailableBoards_IXXAT(WORD wModeIndex)
{
	WORD wCount = 0;
#ifdef _MMC_I_IXXAT
    CInterface_IXXAT* pInterface = NULL;

    pInterface = new CInterface_IXXAT();
    if(pInterface)
    {
        pInterface->I_SetInterfaceMode(wModeIndex);
        wCount = pInterface->GetNbOfAvailableBoards();
        delete pInterface;
    }
#endif //_MMC_I_IXXAT
    return wCount;
}

WORD CInterfaceManager::GetNbOfAvailableBoards_Vector(WORD wModeIndex)
{
	WORD wCount = 0;

#ifdef _MMC_I_VECTOR
    CInterface_Vector* pInterface = NULL;

    pInterface = new CInterface_Vector();
    if(pInterface)
    {
        wCount = pInterface->GetNbOfAvailableBoards();
        delete pInterface;
    }
#endif

    return wCount;
}

WORD CInterfaceManager::GetNbOfAvailableBoards_NI(WORD wModeIndex)
{
	WORD wCount = 0;
#ifdef _MMC_I_NI
    CInterface_NI* pInterface = NULL;

    pInterface = new CInterface_NI();
    if(pInterface)
    {
        wCount = pInterface->GetNbOfAvailableBoards();
        delete pInterface;
    }
#endif //_MMC_I_NI
    return wCount;
}

void CInterfaceManager::InitJournalManager(CJournalManagerBase *pJournalManager)
{
	for(std::list<CInterfaceBase*>::iterator it=m_InterfaceList.begin();
	    		it!=m_InterfaceList.end(); it++)
	    {
	    	CInterfaceBase* pInterface = (*it);
        pInterface->InitJournalManager(pJournalManager);
    }
}

void CInterfaceManager::ResetJournalManager()
{
	for(std::list<CInterfaceBase*>::iterator it=m_InterfaceList.begin();
	    		it!=m_InterfaceList.end(); it++)
	    {
	    	CInterfaceBase* pInterface = (*it);
        pInterface->ResetJournalManager();
    }
}

BOOL CInterfaceManager::InitJournalManager(HANDLE hHandle, CJournalManagerBase* pJournalManager)
{
    CHandleRegistration_I* pRegistration = NULL;
    CInterfaceBase* pInterface = NULL;
    CPortBase* pPort = NULL;

    if(m_pHandleRegistrationMap_I)
	{
		//GetRegistration
		if(m_pHandleRegistrationMap_I->GetRegistration(hHandle, &pRegistration))
		{
			//GetRegistrationEntries
			if(m_pHandleRegistrationMap_I->GetRegistrationValues(hHandle, &pInterface, &pPort))
			{
				if(pInterface) pInterface->InitJournalManager(pJournalManager);
				if(pPort) pPort->InitJournalManager(hHandle, pJournalManager);

				return TRUE;
			}
		}
	}

    return FALSE;
}

BOOL CInterfaceManager::ResetJournalManager(HANDLE hHandle)
{
    CHandleRegistration_I* pRegistration = NULL;
    CInterfaceBase* pInterface = NULL;
    CPortBase* pPort = NULL;

    if(m_pHandleRegistrationMap_I)
	{
		//GetRegistration
		if(m_pHandleRegistrationMap_I->GetRegistration(hHandle, &pRegistration))
		{
			//GetRegistrationEntries
			if(m_pHandleRegistrationMap_I->GetRegistrationValues(hHandle, &pInterface, &pPort))
			{
				if(pInterface) pInterface->ResetJournalManager();
				if(pPort) pPort->ResetJournalManager(hHandle);

				return TRUE;
			}
		}
	}

    return FALSE;
}

BOOL CInterfaceManager::I_GetDefaultInterfaceSettings(CStdString strInterfaceName, DWORD* pdBaudrate, DWORD* pdTimeout, CErrorInfo* pErrorInfo)
{
    CMmcSingleLock lock(&m_Sync, TRUE);
    CInterfaceBase* pInterface = NULL;

    //FindInterface
    if(!FindInterface(strInterfaceName, &pInterface) || (pInterface == NULL))
    {
        if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_BadInterfaceName, pErrorInfo);
        return FALSE;
    }

    //GetDefaultInterfaceSettings
    return pInterface->I_GetDefaultInterfaceSettings(pdBaudrate, pdTimeout, pErrorInfo);
}

BOOL CInterfaceManager::I_SetDefaultInterfaceSettings(CStdString strInterfaceName, DWORD dBaudrate, DWORD dTimeout, CErrorInfo* pErrorInfo)
{
    CMmcSingleLock lock(&m_Sync, TRUE);
    CInterfaceBase* pInterface = NULL;

    //FindInterface
    if(!FindInterface(strInterfaceName, &pInterface) || (pInterface == NULL))
    {
        if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_BadInterfaceName, pErrorInfo);
        return FALSE;
    }

    //SetDefaultInterfaceSettings
    return pInterface->I_SetDefaultInterfaceSettings(dBaudrate, dTimeout, pErrorInfo);
}

BOOL CInterfaceManager::InitErrorHandling()
{
    CErrorProducer errorProducer;
    CStdString strClassName = "InterfaceManager";

    if(m_pErrorHandling)
    {
        //Init ErrorProducer
        errorProducer.Init(INTERFACE_LAYER, strClassName);
        m_pErrorHandling->InitErrorProducer(&errorProducer);
        return TRUE;
    }

    return FALSE;
}

BOOL CInterfaceManager::EnableTracing(HANDLE hI_Handle, CStdString p_TracingFileName, CErrorInfo* pErrorInfo)
{
    CInterfaceBase* pInterface = NULL;
    CPortBase* pPort = NULL;
    CHandleRegistration_I* pRegistration = NULL;

    if(m_pHandleRegistrationMap_I)
	{
		//Get Registration
		if(!m_pHandleRegistrationMap_I->GetRegistration(hI_Handle, &pRegistration) || (pRegistration == NULL))
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_HandleNotValid, pErrorInfo);
			return FALSE;
		}

		//Lock
		if(!pRegistration->DoLock())
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
			return FALSE;
		}

		//Get Registration Values
		if(!m_pHandleRegistrationMap_I->GetRegistrationValues(hI_Handle, &pInterface, &pPort) || (pInterface == NULL) || (pPort == NULL))
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
			if(pRegistration) pRegistration->DoUnlock();
			return FALSE;
		}

		//Enable Tracing
		if(!pInterface->EnableTracing(pPort, p_TracingFileName, pErrorInfo))
		{
			if(pRegistration) pRegistration->DoUnlock();
			return FALSE;
		}

		//Unlock
		if(pRegistration) pRegistration->DoUnlock();
		return TRUE;
	}

	return FALSE;
}

BOOL CInterfaceManager::DisableTracing(HANDLE hI_Handle, CErrorInfo* pErrorInfo)
{
    CInterfaceBase* pInterface = NULL;
    CPortBase* pPort = NULL;
    CHandleRegistration_I* pRegistration = NULL;

    if(m_pHandleRegistrationMap_I)
	{
		//Get Registration
		if(!m_pHandleRegistrationMap_I->GetRegistration(hI_Handle, &pRegistration) || (pRegistration == NULL))
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_HandleNotValid, pErrorInfo);
			return FALSE;
		}

		//Lock
		if(!pRegistration->DoLock())
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
			return FALSE;
		}

		//Get Registration Values
		if(!m_pHandleRegistrationMap_I->GetRegistrationValues(hI_Handle, &pInterface, &pPort) || (pInterface == NULL) || (pPort == NULL))
		{
			if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
			if(pRegistration) pRegistration->DoUnlock();
			return FALSE;
		}

		//Disable Tracing
		if(!pInterface->DisableTracing(pPort, pErrorInfo))
		{
			if(pRegistration) pRegistration->DoUnlock();
			return FALSE;
		}

		//Unlock
		if(pRegistration) pRegistration->DoUnlock();
		return TRUE;
	}

	return FALSE;
}


