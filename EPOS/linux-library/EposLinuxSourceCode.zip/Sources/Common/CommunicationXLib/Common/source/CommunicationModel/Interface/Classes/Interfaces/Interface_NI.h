// Interface_NI.h: Schnittstelle f�r die Klasse CInterface_NI.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_Interface_NI_H__44692961_FDA4_45C0_8C83_89523F8F58C0__INCLUDED_)
#define AFX_Interface_NI_H__44692961_FDA4_45C0_8C83_89523F8F58C0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <MmcDefinitions.h>
#ifdef _MMC_I_NI

#include "BaseClasses/InterfaceBase.h"

class CInterface_NI : public CInterfaceBase
{
public:
	void Init() {m_strClassType="CInterface_NI";}
	WORD GetNbOfAvailableBoards();

	//Initialisation
	BOOL InitInterface(WORD wBoardNumber,WORD wNbBoardWithOldDriver);

	BOOL I_OpenInterface(CErrorInfo* pErrorInfo = NULL);
	BOOL I_OpenInterfacePort(CPortBase* pPort,CStdString strPortName,CErrorInfo* pErrorInfo = NULL);

	BOOL I_CloseInterface(CErrorInfo* pErrorInfo = NULL);
	BOOL I_CloseInterfacePort(CPortBase* pPort,CErrorInfo* pErrorInfo = NULL);

	BOOL I_GetInterfaceSettings(CPortBase* pPort,DWORD* pdBaudrate,DWORD* pdTimeout,CErrorInfo* pErrorInfo = NULL);
	BOOL I_SetInterfaceSettings(CPortBase* pPort,DWORD dBaudrate,DWORD dTimeout,BOOL oChangeOnly,CErrorInfo* pErrorInfo = NULL);

	BOOL I_GetInterfaceMode(WORD* pwModeIndex,CErrorInfo* pErrorInfo = NULL);
	BOOL I_SetInterfaceMode(WORD wModeIndex,CErrorInfo* pErrorInfo = NULL);

	BOOL I_ResetInterface(CPortBase* pPort,CErrorInfo* pErrorInfo = NULL);

	CInterface_NI();
	CInterface_NI(const CInterface_NI& rObject);
	virtual ~CInterface_NI();
	CInterfaceBase* Clone();

//JournalManager
    virtual void InitJournalManager(CJournalManagerBase *pJournalManager);
    virtual void ResetJournalManager();

private:
	BOOL InitErrorHandling();
	BOOL InitGateway();

	//ParameterSet
	BOOL InitParameterSet();
};
#endif //_MMC_I_NI

#endif // !defined(AFX_Interface_NI_H__44692961_FDA4_45C0_8C83_89523F8F58C0__INCLUDED_)
