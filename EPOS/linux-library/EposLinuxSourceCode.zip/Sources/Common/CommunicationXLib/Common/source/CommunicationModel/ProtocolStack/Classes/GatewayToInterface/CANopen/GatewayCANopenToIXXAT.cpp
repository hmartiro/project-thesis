// GatewayCANopenToIXXAT.cpp: Implementierung der Klasse CGatewayCANopenToIXXAT.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"

#include "GatewayCANopenToIXXAT.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////
CGatewayCANopenToIXXAT::CGatewayCANopenToIXXAT()
{
	InitErrorHandling();
}

CGatewayCANopenToIXXAT::~CGatewayCANopenToIXXAT()
{
}

CGateway* CGatewayCANopenToIXXAT::Clone()
{
	CGatewayCANopenToIXXAT* pClonedGateway;

	pClonedGateway = new CGatewayCANopenToIXXAT();
	*pClonedGateway = *this;

	return pClonedGateway;
}

CGatewayCANopenToIXXAT& CGatewayCANopenToIXXAT::operator=(CGatewayCANopenToIXXAT& other)
{
	if(this != &other)
	{
		*((CGatewayCANopenToI*)this) = *((CGatewayCANopenToI*)&other);
	}

	return *this;
}

/************************************************************************/
BOOL CGatewayCANopenToIXXAT::InitErrorHandling()
{
	CErrorProducer errorProducer;
	CStdString strClassName = "GatewayCANopenToIXXAT";

	if(m_pErrorHandling)
	{
		//Init ErrorProducer
		errorProducer.Init(PROTOCOL_STACK_LAYER,strClassName);
		m_pErrorHandling->InitErrorProducer(&errorProducer);
		return TRUE;
	}

	return FALSE;
}

