// GatewayNItoNiCanLib.h: Schnittstelle f�r die Klasse CGatewayNItoNiCanLib.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GatewayNItoNiCanLib_H__89B9836A_BF97_42DF_8370_3E0AF46F87FE__INCLUDED_)
#define AFX_GatewayNItoNiCanLib_H__89B9836A_BF97_42DF_8370_3E0AF46F87FE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <MmcDefinitions.h>
#ifdef _MMC_I_NI

#include <Drv/Ni/MmcNiHndl.h>
#include "../BaseClasses/GatewayIToDrv.h"

class CCommand_I;

class CGatewayNItoNiCanLib : public CGatewayIToDrv
{
public:
	virtual WORD GetNbOfAvailableBoards();

	CGatewayNItoNiCanLib();
	virtual ~CGatewayNItoNiCanLib();

	virtual CGateway* Clone();
	CGatewayNItoNiCanLib& operator=(CGatewayNItoNiCanLib& other);

//Interne Struktur Funktionen
	virtual BOOL InitPort(WORD wBoardNumber,WORD wNbBoardWithOldDriver);

//Initialisation
	virtual BOOL OpenPort(CStdString strPortName,CErrorInfo* pErrorInfo = NULL);
	virtual BOOL ClosePort(CErrorInfo* pErrorInfo = NULL);

//Hilfsfunktionen
	virtual BOOL ResetPort(CErrorInfo* pErrorInfo = NULL);
	virtual BOOL IsPortNameSupported(CStdString strPortName);

//Setting Funktionen
	virtual BOOL SetPortSettings(DWORD dBaudrate,DWORD dTimeout,BOOL oChangeOnly,CErrorInfo* pErrorInfo = NULL);
	virtual BOOL GetPortSettings(DWORD* pdBaudrate,DWORD* pdTimeout,CErrorInfo* pErrorInfo = NULL);

	virtual BOOL SetPortMode(WORD wPortMode,CErrorInfo* pErrorInfo = NULL);
	virtual BOOL GetPortMode(WORD* pwPortMode,CErrorInfo* pErrorInfo = NULL);

//Name Funktionen
	virtual BOOL InitInterfacePortName(CStdString* pStrInterfacePortName,WORD wBoardNumber,WORD wNbBoardWithOldDriver);
	virtual BOOL InitInterfaceName(CStdString* pStrInterfaceName,WORD wBoardNumber,WORD wNbBoardWithOldDriver);

//Funktionalit�t
	virtual BOOL ProcessCommand(CCommandRoot*pCommand,CLayerManagerBase* pManager,HANDLE h_Handle,HANDLE hTransactionHandle);

private:
	CMmcNiHndl	m_NiHndl;

private:
	BOOL Process_TransmitCanFrame(CCommand_I* pCommand);
	BOOL Process_ReceiveCanFrame(CCommand_I* pCommand);
	BOOL Process_ReceiveFilteredCanFrame(CCommand_I* pCommand);
		
	//29-Bit Identifier
	BOOL Process_TransmitCanFrameEx(CCommand_I* pCommand);
	BOOL Process_ReceiveCanFrameEx(CCommand_I* pCommand);
	BOOL Process_ReceiveFilteredCanFrameEx(CCommand_I* pCommand);

	BOOL TransmitCanFrame(BOOL oExtCobId, DWORD dCobId,BOOL oRtr,BYTE uDlc,void* pDataBuffer,DWORD dDataBufferLength,CErrorInfo* pErrorInfo = NULL);
	BOOL ReceiveCanFrame(BOOL oExtCobId, DWORD dTimeout,DWORD* pdCobId,BOOL* poRtr,BYTE* puDlc,void** ppDataBuffer,DWORD* pdDataBufferLength,CErrorInfo* pErrorInfo = NULL);
	BOOL ReceiveFilteredCanFrame(BOOL oExtCobId, DWORD dCobIdFilter,BOOL oRtrFilter,DWORD dTimeout,DWORD* pdCobId,BOOL* poRtr,BYTE* puDlc,void** ppDataBuffer,DWORD* pdDataBufferLength,CErrorInfo* pErrorInfo = NULL);
	
	BOOL InitErrorHandling();
	BOOL InitDefaultBaudrateSelection();
	BOOL InitHighSpeedBaudrateSelection();
	BOOL InitLowSpeedBaudrateSelection();
	BOOL InitSingleWireBaudrateSelection();
	BOOL InitDefaultPortSettings();
	BOOL IsBaudrateSupported(DWORD dBaudrate);
	BOOL CheckStatusAndReset();
};
#endif //_MMC_I_NI

#endif // !defined(AFX_GatewayNItoNiCanLib_H__89B9836A_BF97_42DF_8370_3E0AF46F87FE__INCLUDED_)
