#if !defined(AFX_INTERFACEMANAGER_H__0F52D262_5C84_4F7D_816F_3DE0F0AA6833__INCLUDED_)
#define AFX_INTERFACEMANAGER_H__0F52D262_5C84_4F7D_816F_3DE0F0AA6833__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "BaseClasses/InterfaceManagerBase.h"
#include "Classes/Handle/HandleRegistrationMap_I.h"    // Hinzugef�gt von der Klassenansicht
#include <MmcDefinitions.h>
class CInterfaceBase;
#ifdef _MMC_I_USB
class CFtd2xxDeviceInfoHandling;
#endif //_MMC_I_USB
#ifdef _MMC_I_HID
class CHidDeviceInfoHandling;
#endif //_MMC_I_HID
class CInterfaceManager : public CInterfaceManagerBase
{
public:
//Internal Structure Funktionen
    virtual BOOL I_InitAllInterfaces(CErrorInfo* pErrorInfo = NULL);
    virtual BOOL I_InitInterface(CStdString strInterfaceName, CErrorInfo* pErrorInfo = NULL);
    virtual BOOL I_InitBaudrateSelection(CStdString strInterfaceName, CStdDWordArray& dBaudrateSel, CErrorInfo* pErrorInfo = NULL);
    virtual BOOL I_InitDefaultInterfaceSettings(CStdString strInterfaceName, DWORD dBaudrate, DWORD dTimeout, CErrorInfo* pErrorInfo = NULL);
    virtual BOOL I_UpdateInterface(CStdString strInterfaceName, CErrorInfo* pErrorInfo = NULL);

//Initialisation
    virtual HANDLE I_OpenInterface(CStdString strInterfaceName, CStdString strPortName, CErrorInfo* pErrorInfo = NULL);
    virtual BOOL I_CloseInterface(HANDLE hI_Handle, CErrorInfo* pErrorInfo = NULL);
    virtual BOOL I_CloseAllInterfaces(CErrorInfo* pErrorInfo = NULL);
	virtual BOOL I_AreAllInterfacesClosed();

//Parameter
	virtual BOOL SetParameter(EParameterType p_eParameterType, HANDLE hI_Handle, CStdString p_Name, BYTE* p_pValue, DWORD p_ulSize, CErrorInfo* pErrorInfo = NULL);
	virtual BOOL SetParameter(EParameterType p_eParameterType, HANDLE hI_Handle, CStdString p_Name, CStdString p_Value, CErrorInfo* pErrorInfo = NULL);
	virtual BOOL GetParameter(EParameterType p_eParameterType, HANDLE hI_Handle, CStdString p_Name, BYTE* p_pValue, DWORD p_ulSize, CErrorInfo* pErrorInfo = NULL);
	virtual BOOL GetParameter(EParameterType p_eParameterType, HANDLE hI_Handle, CStdString p_Name, CStdString& p_rValue, CErrorInfo* pErrorInfo = NULL);

//Hilfsfunktionen
    virtual BOOL I_GetKeyHandle(CStdString strInterfaceName, CStdString strPortName, HANDLE* pIKeyHandle, CErrorInfo* pErrorInfo = NULL);
    virtual BOOL I_ResetInterface(HANDLE hI_Handle, CErrorInfo* pErrorInfo = NULL);
    virtual BOOL I_GetDefaultInterfaceSettings(CStdString strInterfaceName, DWORD* pdBaudrate, DWORD* pdTimeout, CErrorInfo* pErrorInfo = NULL);
    virtual BOOL I_SetDefaultInterfaceSettings(CStdString strInterfaceName, DWORD dBaudrate, DWORD dTimeout, CErrorInfo* pErrorInfo = NULL);
    virtual BOOL I_IsInterfaceNameSupported(CStdString strInterfaceName, CErrorInfo* pErrorInfo = NULL);

//Selection Funktionen
    virtual BOOL I_GetInterfaceNameSelection(CStdStringArray* pInterfaceNameSel, CErrorInfo* pErrorInfo = NULL);
    virtual BOOL I_GetPortNameSelection(CStdString strInterfaceName, CStdStringArray* pPortSel, CErrorInfo* pErrorInfo = NULL);
    virtual BOOL I_GetBaudrateSelection(CStdString strInterfaceName, CStdString strPortName, CStdDWordArray* pdBaudrateSel, CErrorInfo* pErrorInfo = NULL);

//Setting Funktionen
    virtual BOOL I_GetInterfaceSettings(HANDLE hI_Handle, DWORD* pdBaudrate, DWORD* pdTimeout, CErrorInfo* pErrorInfo = NULL);
    virtual BOOL I_SetInterfaceSettings(HANDLE hI_Handle, DWORD dBaudrate, DWORD dTimeout, BOOL oChangeOnly, CErrorInfo* pErrorInfo = NULL);

//Name Funktionen
    virtual BOOL I_GetInterfaceName(HANDLE hI_Handle, CStdString* pInterfaceName, CErrorInfo* pErrorInfo = NULL);
    virtual BOOL I_GetPortName(HANDLE hI_Handle, CStdString* pPortName, CErrorInfo* pErrorInfo = NULL);

//Funktionalit�t
    virtual BOOL ExecuteCommand(CCommandRoot *pCommand, HANDLE hHandle, HANDLE hTransactionHandle);
    virtual BOOL GetCommands(HANDLE hHandle, ELayer eLayer, CStdString* pCommandInfo);
    virtual BOOL AbortCommands(HANDLE hHandle, BOOL oActive);

//LayerManager
    virtual BOOL GetLayerManager(HANDLE hHandle, ELayer eLayer, CLayerManagerBase** ppLayerManager);

//Tracing
    virtual BOOL EnableTracing(HANDLE hI_Handle, CStdString p_TracingFileName, CErrorInfo* pErrorInfo = NULL);
    virtual BOOL DisableTracing(HANDLE hI_Handle, CErrorInfo* pErrorInfo = NULL);

//JournalManager
    virtual BOOL InitJournalManager(HANDLE hHandle, CJournalManagerBase* pJournalManager);
    virtual BOOL ResetJournalManager(HANDLE hHandle);
    virtual void InitJournalManager(CJournalManagerBase *pJournalManager);
    virtual void ResetJournalManager();

    CInterfaceManager();
	CInterfaceManager(int p_lInstanceValue);
    CInterfaceManager(const CInterfaceManager& rObject);
    virtual ~CInterfaceManager();
    virtual CInterfaceManagerBase* Clone();

private:
    BOOL DeleteInterface(CStdString strInterfaceName, BOOL oCheckPrefixOnly);
    BOOL DeleteAllInterfaces(CStdString strInterfaceName, BOOL oCheckPrefixOnly);
    BOOL FindInterface(CStdString strInterfaceName, CInterfaceBase** ppInterface);
    BOOL FindInterfaceIndex(CStdString strInterfaceName, short* piInterfaceIndex);
    BOOL FindInterfacePortIndex(CStdString strInterfaceName, CStdString strPortName, short* piPortIndex);
    BOOL FindPort(CStdString strInterfaceName, CStdString strPortName, CPortBase** ppPort);
    BOOL InitErrorHandling();
    WORD GetNbOfAvailableBoards_IXXAT(WORD wModeIndex);
    WORD GetNbOfAvailableBoards_NI(WORD wModeIndex = 0);
    WORD GetNbOfAvailableBoards_Vector(WORD wModeIndex = 0);
    void DeleteInterfaceList();

    //UsbDeviceInfoHandling
    BOOL CreateUsbDeviceInfoHandling();
    BOOL DeleteUsbDeviceInfoHandling();
    BOOL InitUsbDeviceInfoHandling(CInterfaceBase* pInterface);

	//Singleton RegistrationMap
	BOOL InitRegistrationMap();
	BOOL ReleaseRegistrationMap();

private:
    CHandleRegistrationMap_I* m_pHandleRegistrationMap_I;
    std::list<CInterfaceBase*> m_InterfaceList;

    //UsbDeviceInfoHandling
#ifdef _MMC_I_USB
    CFtd2xxDeviceInfoHandling* m_pUsbDeviceInfoHandling;
#endif //_MMC_I_USB
#ifdef _MMC_I_HID
    CHidDeviceInfoHandling* m_pUsbHidDeviceInfoHandling;
#endif //_MMC_I_HID
};

#endif // !defined(AFX_INTERFACEMANAGER_H__0F52D262_5C84_4F7D_816F_3DE0F0AA6833__INCLUDED_)
