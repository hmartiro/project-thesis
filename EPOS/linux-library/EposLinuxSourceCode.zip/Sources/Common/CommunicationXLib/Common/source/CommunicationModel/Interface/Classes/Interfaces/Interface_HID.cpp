// Interface_HID.cpp: Implementierung der Klasse CInterface_HID.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Interface_HID.h"

#ifdef _MMC_I_HID

#include "../Ports/Port_HID.h"
#include "../Gateway/HID/GatewayUsbToHidDrv.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

CInterface_HID::CInterface_HID()
{
    Init();
    InitErrorHandling();

    m_strInterfaceName = INTERFACE_HID;
    m_pJournalManager = 0;
    m_pUsbDeviceInfoHandling = 0;
}

CInterface_HID::CInterface_HID(const CInterface_HID& p_rObject):CInterfaceBase(p_rObject)
{
    InitErrorHandling();

    //JournalManager
    InitJournalManager(p_rObject.m_pJournalManager);

    //UsbDeviceInfoHandling
    m_pUsbDeviceInfoHandling = p_rObject.m_pUsbDeviceInfoHandling;
}

CInterface_HID::~CInterface_HID()
{
}

CInterfaceBase* CInterface_HID::Clone()
{
    CInterfaceBase* pInterfaceBase = new CInterface_HID(*this);
    return pInterfaceBase;
}

BOOL CInterface_HID::InitInterface(WORD p_usBoardNumber, WORD p_usNbBoardWithOldDriver)
{
    if(CInterfaceBase::InitInterface(p_usBoardNumber, p_usNbBoardWithOldDriver))
    {
        CPortBase* pPort = new CPort_HID();
        if(pPort->InitGateway(m_pGateway) && pPort->InitPort(p_usBoardNumber, p_usNbBoardWithOldDriver))
        {
            m_PortList.push_back(pPort);
            return 1;
        }

        delete pPort;
    }

    return 0;
}

BOOL CInterface_HID::I_OpenInterface(CErrorInfo* p_pErrorInfo)
{
    return CInterfaceBase::I_OpenInterface(p_pErrorInfo);
}

BOOL CInterface_HID::I_OpenInterfacePort(CPortBase* pPort, CStdString strPortName, CErrorInfo* p_pErrorInfo)
{
    return CInterfaceBase::I_OpenInterfacePort(pPort, strPortName, p_pErrorInfo);
}

BOOL CInterface_HID::I_CloseInterface(CErrorInfo* p_pErrorInfo)
{
    return CInterfaceBase::I_CloseInterface(p_pErrorInfo);
}

BOOL CInterface_HID::I_CloseInterfacePort(CPortBase* pPort, CErrorInfo* p_pErrorInfo)
{
    return CInterfaceBase::I_CloseInterfacePort(pPort, p_pErrorInfo);
}

BOOL CInterface_HID::I_SetInterfaceSettings(CPortBase* pPort, DWORD dBaudrate, DWORD dTimeout, BOOL oChangeOnly, CErrorInfo* p_pErrorInfo)
{
    return CInterfaceBase::I_SetInterfaceSettings(pPort, dBaudrate, dTimeout, oChangeOnly, p_pErrorInfo);
}

BOOL CInterface_HID::I_GetInterfaceSettings(CPortBase* pPort, DWORD* pdBaudrate, DWORD* pdTimeout, CErrorInfo* p_pErrorInfo)
{
    return CInterfaceBase::I_GetInterfaceSettings(pPort, pdBaudrate, pdTimeout, p_pErrorInfo);
}

BOOL CInterface_HID::I_ResetInterface(CPortBase* pPort, CErrorInfo* p_pErrorInfo)
{
    return CInterfaceBase::I_ResetInterface(pPort, p_pErrorInfo);
}

BOOL CInterface_HID::I_SetInterfaceMode(WORD p_usModeIndex, CErrorInfo* p_pErrorInfo)
{
    return CInterfaceBase::I_SetInterfaceMode(p_usModeIndex, p_pErrorInfo);
}

BOOL CInterface_HID::I_GetInterfaceMode(WORD* pwModeIndex, CErrorInfo* p_pErrorInfo)
{
    return CInterfaceBase::I_GetInterfaceMode(pwModeIndex, p_pErrorInfo);
}

void CInterface_HID::InitJournalManager(CJournalManagerBase *p_pJournalManager)
{
    CInterfaceBase::InitJournalManager(p_pJournalManager);
}

void CInterface_HID::ResetJournalManager()
{
    CInterfaceBase::ResetJournalManager();
}

BOOL CInterface_HID::InitGateway()
{
    CGatewayUsbToHidDrv* pGateway = 0;

    //Reset
    DeleteGateway();

    //Create Gateway
    pGateway = new CGatewayUsbToHidDrv();
    m_pGateway = pGateway;

    //Init Gateway
    if(m_pGateway->InitGateway())
    {
        if(pGateway->InitUsbDeviceInfoHandling(m_pUsbDeviceInfoHandling))
        {
            InitParameterSet();
            return 1;
        }
        else
        {
            DeleteGateway();
            return 0;
        }
    }
    else
    {
        DeleteGateway();
        return 0;
    }
}

BOOL CInterface_HID::InitParameterSet()
{
    BOOL oResult(0);

    if(m_pGateway)
    {
        oResult = 1;
        if(oResult) oResult &= m_pGateway->ResetParameterSet();
    }

    return oResult;
}

BOOL CInterface_HID::InitErrorHandling()
{
    CErrorProducer errorProducer;
    CStdString strClassName = "Interface_HID";

    if(m_pErrorHandling)
    {
        //Init ErrorProducer
        errorProducer.Init(INTERFACE_LAYER, strClassName);
        m_pErrorHandling->InitErrorProducer(&errorProducer);
        return 1;
    }

    return 0;
}

BOOL CInterface_HID::InitUsbDeviceInfoHandling(CHidDeviceInfoHandling* pUsbDeviceInfoHandling)
{
    BOOL oResult(1);

    m_pUsbDeviceInfoHandling = pUsbDeviceInfoHandling;

    return oResult;
}

#endif //_MMC_I_HID
