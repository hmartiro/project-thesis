// GatewayUsbToHidDrv.cpp: Implementierung der Klasse CGatewayUsbToHidDrv.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GatewayUsbToHidDrv.h"

#ifdef _MMC_I_HID

#include <CommunicationModel/CommonLayer/Classes/Commands/Interface/BaseClasses/Command_I.h>
#include <CommunicationModel/CommonLayer/Classes/Commands/Interface/Command_I_USB.h>
#include "../../../../Interface/BaseClasses/InterfaceManagerBase.h"
#include <Process/MmcProcess.h>
//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

CGatewayUsbToHidDrv::CGatewayUsbToHidDrv()
{
    m_PortName = _T("");

	m_pHidHndl = new CMmcHidHndl();

	if( m_pHidHndl != 0 )
		m_pHidHndl->ResetOutReport();

    InitErrorHandling();
    InitBaudrateSelection();
    InitDefaultPortSettings();

	if( m_pHidHndl != 0 )
		m_pHidHndl->Init();
}

CGatewayUsbToHidDrv::~CGatewayUsbToHidDrv()
{
    if( m_pHidHndl != 0 )
		delete m_pHidHndl;
}

BOOL CGatewayUsbToHidDrv::InitBaudrateSelection()
{
    m_BaudrateSelection.clear();
    m_BaudrateSelection.push_back(USB_BAUDRATE_1000000);

    return 1;
}

BOOL CGatewayUsbToHidDrv::InitDefaultPortSettings()
{
    m_dDefaultBaudrate = USB_BAUDRATE_1000000;
    m_dDefaultTimeout = 500;

    GetDefaultPortSettings(&m_dBaudrate, &m_dTimeout);

    return 1;
}

BOOL CGatewayUsbToHidDrv::ProcessCommand(CCommandRoot* p_pCommand, CLayerManagerBase* p_pManager, HANDLE p_hHandle, HANDLE p_hTransactionHandle)
{
    CMmcSingleLock lock(CHidDeviceInfoHandling::GetSyncInstance(), 1);
    CCommand_I* pCommand_I;

    if(CGateway::ProcessCommand(p_pCommand, p_pManager, p_hHandle, p_hTransactionHandle))
    {
        if(CheckLayers(p_pCommand, p_pManager))
        {
            pCommand_I = (CCommand_I*)p_pCommand;
            switch(p_pCommand->GetCommandId())
            {
                case USB_WRITE_DATA:    return Process_WriteData(pCommand_I);
                case USB_READ_DATA:     return Process_ReadData(pCommand_I);
                case USB_RESCAN:        return Process_Rescan(pCommand_I);
                case USB_RELOAD:        return Process_Reload(pCommand_I);
            }
        }
    }

    return 0;
}

BOOL CGatewayUsbToHidDrv::Process_WriteData(CCommand_I* p_pCommand)
{
    //Constants
    const DWORD MAX_RETRY(2);
    const int PARAMETER_INDEX_DATA(0);
    const int RETURN_PARAMETER_INDEX_NB_OF_BYTES_WRITTEN(0);

    //Parameter
    void* pDataBuffer(0);
    DWORD ulDataBufferLength;

    //ReturnParameter
    DWORD ulNbOfBytesWritten(0);

    BOOL oResult(0);
    CErrorInfo errorInfo;

    if(p_pCommand)
    {
        //Lock CriticalSection
        if(!Lock(p_pCommand->GetTimeout())) return 0;

        //Prepare DataBuffer
        ulDataBufferLength = p_pCommand->GetParameterLength(PARAMETER_INDEX_DATA);
        if(ulDataBufferLength > 0) pDataBuffer = malloc(ulDataBufferLength);

        //Get I Parameter Data
        p_pCommand->GetParameterData(PARAMETER_INDEX_DATA, pDataBuffer, ulDataBufferLength);

        //Execute Command
        oResult = WriteData(pDataBuffer, ulDataBufferLength, &ulNbOfBytesWritten, MAX_RETRY, &errorInfo);

        //Set PS ReturnParameter Data
        p_pCommand->SetStatus(oResult, &errorInfo);
        p_pCommand->SetReturnParameterData(RETURN_PARAMETER_INDEX_NB_OF_BYTES_WRITTEN, &ulNbOfBytesWritten, sizeof(ulNbOfBytesWritten));

        //Unlock CriticalSection
        Unlock();
    }

    return oResult;
}

BOOL CGatewayUsbToHidDrv::Process_ReadData(CCommand_I* p_pCommand)
{
    //Constants
    const int PARAMETER_INDEX_NB_OF_BYTES_TO_READ(0);
    const int RETURN_PARAMETER_INDEX_DATA(0);

    //Parameter
    DWORD ulNbOfBytesToRead;

    //ReturnParameter
    void* pDataBuffer(0);
    DWORD ulDataBufferLength;
    DWORD ulNbOfBytesRead(0);

    BOOL oResult(0);
    CErrorInfo errorInfo;

    if(p_pCommand)
    {
        //Lock CriticalSection
        if(!Lock(p_pCommand->GetTimeout())) return 0;

        //Get I Parameter Data
        p_pCommand->GetParameterData(PARAMETER_INDEX_NB_OF_BYTES_TO_READ, &ulNbOfBytesToRead, sizeof(ulNbOfBytesToRead));

        //Prepare DataBuffer
        ulDataBufferLength = ulNbOfBytesToRead;
        if(ulDataBufferLength > 0) pDataBuffer = malloc(ulDataBufferLength);

        //Execute Command
        oResult = ReadReport((BYTE*)pDataBuffer, ulNbOfBytesToRead, &ulNbOfBytesRead, &errorInfo);

        //Set PS ReturnParameter Data
        p_pCommand->SetStatus(oResult, &errorInfo);
        p_pCommand->SetReturnParameterData(RETURN_PARAMETER_INDEX_DATA, pDataBuffer, ulNbOfBytesRead);

        //Unlock CriticalSection
        Unlock();
    }

    return oResult;
}

BOOL CGatewayUsbToHidDrv::Process_Rescan(CCommand_I* p_pCommand)
{
    BOOL oResult(0);
    CErrorInfo errorInfo;

    if(p_pCommand)
    {
        //Lock CriticalSection
        if(!Lock(p_pCommand->GetTimeout())) return 0;

        //Execute Command
        oResult = Rescan(&errorInfo);

        //Set I ReturnParameter Data
        p_pCommand->SetStatus(oResult, &errorInfo);

        //Unlock CriticalSection
        Unlock();
    }

    return oResult;
}

BOOL CGatewayUsbToHidDrv::Process_Reload(CCommand_I* p_pCommand)
{
    //Constants
    const int PARAMETER_INDEX_VENDOR_ID(0);
    const int PARAMETER_INDEX_PRODUCT_ID(1);

    //Parameter
    WORD usVendorId(0);
    WORD usProductId(0);

    BOOL oResult(0);
    CErrorInfo errorInfo;

    if(p_pCommand)
    {
        //Lock CriticalSection
        if(!Lock(p_pCommand->GetTimeout())) return 0;

        //Get I Parameter Data
        p_pCommand->GetParameterData(PARAMETER_INDEX_VENDOR_ID, &usVendorId, sizeof(usVendorId));
        p_pCommand->GetParameterData(PARAMETER_INDEX_PRODUCT_ID, &usProductId, sizeof(usProductId));

        //Execute Command
        oResult = Reload(usVendorId, usProductId, &errorInfo);

        //Set I ReturnParameter Data
        p_pCommand->SetStatus(oResult, &errorInfo);

        //Unlock CriticalSection
        Unlock();
    }

    return oResult;
}

CGateway* CGatewayUsbToHidDrv::Clone()
{
    CGatewayUsbToHidDrv* pClonedGateway;

    pClonedGateway = new CGatewayUsbToHidDrv();
    *pClonedGateway = *this;

    return pClonedGateway;
}

CGatewayUsbToHidDrv& CGatewayUsbToHidDrv::operator=(CGatewayUsbToHidDrv& p_rOther)
{
    if(this != &p_rOther)
    {
        *((CGatewayIToDrv*)this) = *((CGatewayIToDrv*)&p_rOther);
        m_pUsbDeviceInfoHandling = p_rOther.m_pUsbDeviceInfoHandling;
    }

    return *this;
}

BOOL CGatewayUsbToHidDrv::OpenPort(CStdString p_PortName, CErrorInfo* p_pErrorInfo)
{
	BOOL oResult(0);
    const BOOL CHANGE_ONLY(0);
    CMmcSingleLock lock(CHidDeviceInfoHandling::GetSyncInstance(), 1);
    CStdString devicePath(_T(""));
    DWORD ulLocationId(0);

	if(m_pHidHndl!= 0 && m_pHidHndl->IsValid())
    {
        if(GetLocationId(p_PortName, devicePath, ulLocationId))
        {
			m_pHidHndl->OpenPort(devicePath);
            
            if(m_pHidHndl->IsValid())
            {                
                //Configure default settings for port
                if(ConfigurePortSettings(m_dBaudrate, m_dTimeout, CHANGE_ONLY, p_pErrorInfo, 0))
                {
                    m_PortName = p_PortName;
                    if(m_oUpdateLockedPort) UpdatePortLocked(m_PortName, 1);
                    oResult = 1;
                }
                else
                {
                    ClosePort();

                    oResult = 0;
                }
            }
            else
            {
                ClosePort();

                if(m_pErrorHandling) m_pErrorHandling->GetError(MmcGetLastError(), p_pErrorInfo);
                oResult = 0;
            }
        }
    }
    else
    {
        if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_LibraryNotLoaded, p_pErrorInfo);
        oResult = 0;
    }

    return oResult;
}

BOOL CGatewayUsbToHidDrv::ReopenPort(CStdString p_PortName, CErrorInfo* p_pErrorInfo)
{
    BOOL oResult(0);
    //Deactivate update
    m_oUpdateLockedPort = 0;

    //Reopen port
    oResult = CGatewayIToDrv::ReopenPort(p_PortName, p_pErrorInfo);

    //Reactivate update
    m_oUpdateLockedPort = 1;

    return oResult;
}

BOOL CGatewayUsbToHidDrv::SetPortSettings(DWORD p_ulBaudrate, DWORD p_ulTimeout, BOOL p_oChangeOnly, CErrorInfo* p_pErrorInfo)
{
    return ConfigurePortSettings(p_ulBaudrate, p_ulTimeout, p_oChangeOnly, p_pErrorInfo, 1);
}

BOOL CGatewayUsbToHidDrv::ConfigurePortSettings(DWORD p_ulBaudrate, DWORD p_ulTimeout, BOOL p_oChangeOnly, CErrorInfo* p_pErrorInfo, BOOL p_oDoLock)
{
	BOOL oResult(1);

    CMmcSingleLock lock(CHidDeviceInfoHandling::GetSyncInstance(), 0);

    //Lock
    if(p_oDoLock) lock.Lock();

    if(m_pHidHndl!=0 && m_pHidHndl->IsValid())
    {
		if(m_pHidHndl->IsOpened())
        {
            //Do only if changed
            if(!p_oChangeOnly || (p_ulTimeout != m_dTimeout) || (p_ulBaudrate != m_dBaudrate))
            {
                //Do only if changed
                if(oResult)
                {
                    if(!p_oChangeOnly || (p_ulTimeout != m_dTimeout))
                    {
                        //Set Timeout
                        if(!SetTimeout(p_ulTimeout))
                        {
                            if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_I_SetPortSettings, p_pErrorInfo);
                            oResult = 0;
                        }
                    }
                }

                if(oResult)
                {
                    if(!p_oChangeOnly || !m_oFirstInit)
                    {
                        //Configure PortMode
                        if(!ConfigurePortMode(m_wPortMode, p_pErrorInfo, 0))
                        {
                            oResult = 0;
                        }
                    }
                }

                //Do only if changed
                if(oResult)
                {
                    if(!p_oChangeOnly || (p_ulBaudrate != m_dBaudrate))
                    {
                        if(SetBaudrate(p_ulBaudrate))
                        {
                            //Baudrate is set
                            m_dBaudrate = p_ulBaudrate;
                        }
                        else
                        {
                            if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_I_SetPortSettings, p_pErrorInfo);
                            oResult = 0;
                        }
                    }
                }

                if(oResult)
                {
                    if(!p_oChangeOnly || !m_oFirstInit)
                    {
                        //Purge the buffer
                        if(!PurgeBuffer())
                        {
                            if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_I_SetPortSettings, p_pErrorInfo);
                            oResult = 0;
                        }
                        else
                        {
                            m_oFirstInit = 1;
                        }
                    }
                }
            }
        }
        else
        {
            if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_I_PortNotOpen, p_pErrorInfo);
            oResult = 0;
        }
    }
    else
    {
        if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_LibraryNotLoaded, p_pErrorInfo);
        oResult = 0;
    }

    //Tracing
    Trace_Settings(p_ulBaudrate, p_ulTimeout);

    //Unlock
    if(p_oDoLock) lock.Unlock();

    if(!oResult && m_pErrorHandling) m_pErrorHandling->GetError(k_Error_I_SetPortSettings, p_pErrorInfo);
    return oResult;
}

BOOL CGatewayUsbToHidDrv::SetPortMode(WORD p_usPortMode, CErrorInfo* p_pErrorInfo)
{
    return ConfigurePortMode(p_usPortMode, p_pErrorInfo, 1);
}

BOOL CGatewayUsbToHidDrv::ConfigurePortMode(WORD p_usPortMode, CErrorInfo* p_pErrorInfo, BOOL p_oDoLock)
{
	BOOL oResult(0);
    CMmcSingleLock lock(CHidDeviceInfoHandling::GetSyncInstance(), 0);

    //Lock
    if(p_oDoLock) lock.Lock();

	if(m_pHidHndl != 0 && m_pHidHndl->IsValid() )
    {
		if(m_pHidHndl->IsOpened())
        {
            if(m_wPortMode == 0)
            {
                oResult = 1;
            }
        }
        else
        {
            if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_I_PortNotOpen, p_pErrorInfo);
            oResult = 0;
        }
    }
    else
    {
        if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_LibraryNotLoaded, p_pErrorInfo);
        oResult = 0;
    }

    //Unlock
    if(p_oDoLock) lock.Unlock();

    return oResult;
}

BOOL CGatewayUsbToHidDrv::SetTimeout(DWORD p_ulTimeout)
{
    BOOL oResult(0);
	if( m_pHidHndl!=0 && m_pHidHndl->IsOpened() )
    {
        //Set timeout
        m_dTimeout = p_ulTimeout;

        oResult = 1;
    }

    return oResult;
}

BOOL CGatewayUsbToHidDrv::SetBaudrate(DWORD p_ulBaudrate)
{
    BOOL oResult(0);

    if(m_pHidHndl!=0 && m_pHidHndl->IsOpened())
    {
        oResult = 1;
    }

    return oResult;
}

BOOL CGatewayUsbToHidDrv::PurgeBuffer()
{
    BOOL oResult(0);

	if( m_pHidHndl!=0 && m_pHidHndl->IsOpened() )
		oResult = m_pHidHndl->PurgeBuffer() ? 1 : 0;

    return oResult;
}

BOOL CGatewayUsbToHidDrv::WriteData(void* p_pDataBuffer, DWORD p_ulNbOfBytesToWrite, DWORD* p_pulNbOfBytesWritten, DWORD p_ulMaxRetry, CErrorInfo* p_pErrorInfo)
{
    BOOL oResult(0);
    DWORD ulNbOfBytesToWrite(p_ulNbOfBytesToWrite);
    DWORD ulNbOfBytesWritten(0);
    DWORD ulRetryCount(0);
    DWORD ulTotalNbOfBytesWritten(0);
    void* pDataBuffer(p_pDataBuffer);

    while(!oResult && (ulRetryCount < p_ulMaxRetry))
    {
        if(WriteReport((BYTE*)pDataBuffer, ulNbOfBytesToWrite, &ulNbOfBytesWritten, p_pErrorInfo) && (ulNbOfBytesToWrite == ulNbOfBytesWritten))
        {
            if(ulNbOfBytesToWrite == ulNbOfBytesWritten)
            {
                //Succeeded
                ulTotalNbOfBytesWritten += ulNbOfBytesWritten;
                if(p_pulNbOfBytesWritten) *p_pulNbOfBytesWritten = ulTotalNbOfBytesWritten;
                oResult = 1;
            }
            else
            {
                //Retry
                ulTotalNbOfBytesWritten += ulNbOfBytesWritten;
                pDataBuffer = (void*)((BYTE*)p_pDataBuffer + ulTotalNbOfBytesWritten);
                ulNbOfBytesToWrite = p_ulNbOfBytesToWrite - ulTotalNbOfBytesWritten;
                ulRetryCount++;
            }
        }
        else
        {
            //Failed
            ulTotalNbOfBytesWritten += ulNbOfBytesWritten;
            if(p_pulNbOfBytesWritten) *p_pulNbOfBytesWritten = ulTotalNbOfBytesWritten;
            ulRetryCount = p_ulMaxRetry;
            oResult = 0;
        }
    }

    return oResult;
}

BOOL CGatewayUsbToHidDrv::WriteReport(BYTE* p_pDataBuffer, DWORD p_ulNbOfBytesToWrite, DWORD* p_pulNbOfBytesWritten, CErrorInfo* p_pErrorInfo)
{
    BOOL oResult(0);
    DWORD ulNumberOfBytesWritten(0);

    //Reset error info
    if(p_pErrorInfo) p_pErrorInfo->Reset();

	if(m_pHidHndl!=0 && m_pHidHndl->IsValid())
    {
		if(m_pHidHndl->IsOpened())
        {
            //Execute Command
            if(p_pDataBuffer && (p_ulNbOfBytesToWrite > 0))
            {
                //Set report number
                m_pubOutReport[0] = 0;

                //Copy data to byte buffer
                for(DWORD ul = 1; ul < p_ulNbOfBytesToWrite + 1; ul++)
                {
                    m_pubOutReport[ul] = *p_pDataBuffer++;
                }
                //Write to device
                if(m_pHidHndl->WriteFile(m_pubOutReport, sizeof(m_pubOutReport), &ulNumberOfBytesWritten))
                {
                    //INA: was machen wir mit der L�nge? zB. sollen 10 bytes geschr. werden, frame muss aber 18 lang sein + es werden auch 18 geschrieben!
                    if(sizeof(m_pubOutReport) == ulNumberOfBytesWritten)
                    {
                        ulNumberOfBytesWritten = p_ulNbOfBytesToWrite;
                    }

                    if(p_pulNbOfBytesWritten) *p_pulNbOfBytesWritten = ulNumberOfBytesWritten;
                    oResult = 1;
                }
                else
                {
                    CStdString errmsg = m_pHidHndl->GetLastError();

                    if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_USB_WriteData, p_pErrorInfo);
                    oResult = 0;
                }

            }
            else
            {
                if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_NullPointer, p_pErrorInfo);
                oResult = 0;
            }
        }
        else
        {
            if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_I_PortNotOpen, p_pErrorInfo);
            oResult = 0;
        }
    }
    else
    {
        if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_LibraryNotLoaded, p_pErrorInfo);
        oResult = 0;
    }

    Trace_WriteData(oResult, p_pDataBuffer, p_ulNbOfBytesToWrite, p_pulNbOfBytesWritten);
    return oResult;
}

BOOL CGatewayUsbToHidDrv::ReadReport(BYTE* p_pDataBuffer, DWORD p_ulNbOfBytesToRead, DWORD* p_pulNbOfBytesRead, CErrorInfo* p_pErrorInfo)
{
    BOOL oResult(0);
    DWORD ulNbOfBytesRead(0);

    //Reset error info
    if(p_pErrorInfo) p_pErrorInfo->Reset();

    if(m_pHidHndl!=0 && m_pHidHndl->IsValid())
    {
        if(m_pHidHndl->IsOpened())
        {
            if(p_pDataBuffer && (p_ulNbOfBytesToRead > 0) && p_pulNbOfBytesRead)
            {
                //Read from device
                if(m_pHidHndl->ReadFile(m_pubInReport, sizeof(m_pubInReport), &ulNbOfBytesRead) && (sizeof(m_pubInReport) == ulNbOfBytesRead))
                {
                    if(m_pubInReport[0] == 0)
                    {
//                        DWORD ulCopySize = 4 /*DLE, STX, dummy, length*/ + 4 /*error code*/ + p_ulNbOfBytesToRead /*data bytes*/ + 2 /*crc*/;
                        DWORD ulOffset = 0;

                        if(p_ulNbOfBytesToRead == 4)
                        {
                            ulOffset = 1;
                        }
                        else
                        {
                            ulOffset = 5;
                        }

                        //Copy data bytes
                        for(DWORD ul = ulOffset; ul < p_ulNbOfBytesToRead + ulOffset; ul++)
                        {
                            *p_pDataBuffer++ = m_pubInReport[ul];
                        }

                    }
/*                    for(DWORD ul = 1; (ul < ulNbOfBytesRead) || (ul < sizeof(m_pubInReport)); ul++)
                    {
                        *p_pDataBuffer++ = m_pubInReport[ul];
                    }
*/
                    *p_pulNbOfBytesRead = p_ulNbOfBytesToRead;//ulNbOfBytesRead;
                    oResult = 1;
                }
                else
                {
					CStdString errmsg = m_pHidHndl->GetLastError();

                    if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_USB_ReadData, p_pErrorInfo);

                    oResult = 0;
                }
            }
            else
            {
                if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_NullPointer, p_pErrorInfo);
                oResult = 0;
            }
        }
        else
        {
            if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_I_PortNotOpen, p_pErrorInfo);
            oResult = 0;
        }

    }
    else
    {
        if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_LibraryNotLoaded, p_pErrorInfo);
        oResult = 0;
    }

    Trace_ReadData(oResult, p_pDataBuffer, p_ulNbOfBytesToRead, p_pulNbOfBytesRead);
    return oResult;
}

BOOL CGatewayUsbToHidDrv::Rescan(CErrorInfo* p_pErrorInfo)
{
    BOOL oResult(0);

    //ResetErrorInfo
    if(p_pErrorInfo) p_pErrorInfo->Reset();

    if(m_pHidHndl!=0 && m_pHidHndl->IsValid())
    {
        //Rescan
        if(0)//INA: ?
        {
            oResult = 1;
        }
        else
        {
            if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_USB_Rescan, p_pErrorInfo);
            oResult = 0;
        }
    }
    else
    {
        if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_LibraryNotLoaded, p_pErrorInfo);
        oResult = 0;
    }

    return oResult;
}

BOOL CGatewayUsbToHidDrv::Reload(WORD p_usVendorId, WORD p_usProductId, CErrorInfo* p_pErrorInfo)
{
    BOOL oResult(0);

    //ResetErrorInfo
    if(p_pErrorInfo) p_pErrorInfo->Reset();

    if(m_pHidHndl!=0 && m_pHidHndl->IsValid())
    {
        //Reload
        if(0)//INA: ?
        {
            oResult = 1;
        }
        else
        {
            if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_USB_Reload, p_pErrorInfo);
            oResult = 0;
        }
    }
    else
    {
        if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_LibraryNotLoaded, p_pErrorInfo);
        oResult = 0;
    }

    return oResult;
}

BOOL CGatewayUsbToHidDrv::WaitForOutReportData(DWORD p_ulTimeout)
{
	if( m_pHidHndl == 0 )
		return 1;

	return m_pHidHndl->WaitForOutReportData(p_ulTimeout) ? 1 : 0;
}

BOOL CGatewayUsbToHidDrv::UpdateOutReport()
{
	if( m_pHidHndl == 0 )
		return 1;

	return m_pHidHndl->UpdateOutReport() ? 1 : 0;

}

BOOL CGatewayUsbToHidDrv::GetPortSettings(DWORD* p_pulBaudrate, DWORD* p_pulTimeout, CErrorInfo* p_pErrorInfo)
{
    if(p_pulBaudrate) *p_pulBaudrate = m_dBaudrate;
    if(p_pulTimeout) *p_pulTimeout = m_dTimeout;

    return 1;
}

BOOL CGatewayUsbToHidDrv::GetPortMode(WORD* p_pusPortMode, CErrorInfo* p_pErrorInfo)
{
    if(p_pusPortMode)
    {
        *p_pusPortMode = m_wPortMode;
        return 1;
    }

    if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_NullPointer, p_pErrorInfo);
    return 0;
}

BOOL CGatewayUsbToHidDrv::ClosePort(CErrorInfo* p_pErrorInfo)
{
	BOOL oResult(0);
    CMmcSingleLock lock(CHidDeviceInfoHandling::GetSyncInstance(), 1);

    if(m_pHidHndl!=0 && m_pHidHndl->IsValid())
    {
		if(m_pHidHndl->IsOpened())
        {			
            if(m_pHidHndl->ClosePort())
            {
                Trace_Close();
                if(m_oUpdateLockedPort) UpdatePortLocked(m_PortName, 0);
                m_PortName = _T("");         
                oResult = 1;
            }
            else
            {
                if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_I_ClosingPort, p_pErrorInfo);
                oResult = 0;
            }
        }
        else
        {
            if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_I_PortNotOpen, p_pErrorInfo);
            oResult = 0;
        }
    }
    else
    {
        if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_LibraryNotLoaded, p_pErrorInfo);
        oResult = 0;
    }
    return oResult;
}

BOOL CGatewayUsbToHidDrv::ResetPort(CErrorInfo* p_pErrorInfo)
{
	BOOL oResult(0);
    CMmcSingleLock lock(CHidDeviceInfoHandling::GetSyncInstance(), 1);

	if(m_pHidHndl!=0 && m_pHidHndl->IsOpened())
    {
        oResult = 1;

        if(!PurgeBuffer())
        {
            if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_I_ResetPort, p_pErrorInfo);
            oResult = 0;
        }
    }
    else
    {
        if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_I_PortNotOpen, p_pErrorInfo);
        oResult = 0;
    }
    return oResult;
}

BOOL CGatewayUsbToHidDrv::InitPort(WORD p_usBoardNumber, WORD p_usNbBoardWithOldDriver)
{
	BOOL oResult(0);
    CMmcSingleLock lock(CHidDeviceInfoHandling::GetSyncInstance(), 1);

    tHidDeviceInfoList deviceInfoList;

    if(m_pUsbDeviceInfoHandling)
    {
        //Get all physically available ports
        if(GetDeviceInfos(deviceInfoList))
        {
            if(m_pUsbDeviceInfoHandling->InitDeviceInfos(deviceInfoList))
            {
                //Update port list
                oResult = UpdatePortList(m_pUsbDeviceInfoHandling);
            }

            DeleteDeviceInfoList(deviceInfoList);
        }
    }
    return oResult;
}

BOOL CGatewayUsbToHidDrv::UpdatePort(tPortList& p_rOpenPortList)
{
	BOOL oResult(0);
    CMmcSingleLock lock(CHidDeviceInfoHandling::GetSyncInstance(), 1);
    tHidDeviceInfoList deviceInfoList;

    if(m_pUsbDeviceInfoHandling)
    {
        //Get all physically available ports
        if(GetDeviceInfos(deviceInfoList))
        {
            if(m_pUsbDeviceInfoHandling->UpdateDeviceInfos(deviceInfoList, p_rOpenPortList))
            {
                //Update port list
                oResult = UpdatePortList(m_pUsbDeviceInfoHandling);
            }

            DeleteDeviceInfoList(deviceInfoList);
        }
    }
    return oResult;
}

BOOL CGatewayUsbToHidDrv::UpdatePortList(CHidDeviceInfoHandling* pDeviceInfoHandling)
{
    CStdStringArray portNames;
    CStdString portName(_T(""));
    BOOL oResult(0);

    //Reset PortList
    DeletePortList();

    if(pDeviceInfoHandling)
    {
        //Add ports
        if(pDeviceInfoHandling->GetPortNames(portNames))
        {
            oResult = 1;
			for(CStdStringArray::iterator it = portNames.begin(); it != portNames.end(); it++)
            {
                portName = (*it);
                AddPortList(portName);
            }
        }
    }

    return oResult;
}

BOOL CGatewayUsbToHidDrv::InitInterfacePortName(CStdString* p_InterfacePortName, WORD p_usBoardNumber, WORD p_usNbBoardWithOldDriver)
{
    m_strInterfacePortName = INTERFACE_PORT_HID;
    if(p_InterfacePortName) *p_InterfacePortName = m_strInterfacePortName;

    return 1;
}

BOOL CGatewayUsbToHidDrv::InitInterfaceName(CStdString* p_InterfaceName, WORD p_usBoardNumber, WORD p_usNbBoardWithOldDriver)
{
    m_strInterfaceName = INTERFACE_HID;
    if(p_InterfaceName) *p_InterfaceName = m_strInterfaceName;

    return 1;
}

BOOL CGatewayUsbToHidDrv::InitErrorHandling()
{
    CErrorProducer errorProducer;
    CStdString strClassName(_T("GatewayUsbToHidDrv"));

    if(m_pErrorHandling)
    {
        //Init ErrorProducer
        errorProducer.Init(INTERFACE_LAYER, strClassName);
        m_pErrorHandling->InitErrorProducer(&errorProducer);

        return 1;
    }

    return 0;
}

BOOL CGatewayUsbToHidDrv::UpdatePortLocked(CStdString p_PortName, BOOL p_oLocked)
{
    BOOL oResult(0);

    if(m_pUsbDeviceInfoHandling)
    {
        oResult = m_pUsbDeviceInfoHandling->UpdatePortLocked(p_PortName, p_oLocked);
    }

    return oResult;
}

BOOL CGatewayUsbToHidDrv::GetLocationId(CStdString p_PortName, CStdString& p_rDevicePath, DWORD& p_rulLocationId)
{
    BOOL oResult(0);

    if(m_pUsbDeviceInfoHandling)
    {
        if(m_pUsbDeviceInfoHandling->GetLocationId(p_PortName, p_rDevicePath, p_rulLocationId))
        {
            if(p_rulLocationId == 0)
            {
                //LocationId is not valid, update LocationId
                oResult = UpdateLocationId(m_pUsbDeviceInfoHandling, p_PortName, p_rDevicePath, p_rulLocationId);
            }
            else
            {
                //LocationId is valid
                oResult = 1;
            }
        }
    }

    return oResult;
}

BOOL CGatewayUsbToHidDrv::UpdateLocationId(CHidDeviceInfoHandling* pDeviceInfoHandling, CStdString p_PortName, CStdString& p_rDevicePath, DWORD& p_rulLocationId)
{
    tHidDeviceInfoList deviceInfoList;
    BOOL oResult(0);

    if(pDeviceInfoHandling)
    {
        //Get All physically available Ports
        if(GetDeviceInfos(deviceInfoList))
        {
            //Update LocationId
            if(pDeviceInfoHandling->UpdateLocationId(deviceInfoList, p_PortName))
            {
                //Get Updated LocationId
                oResult = pDeviceInfoHandling->GetLocationId(p_PortName, p_rDevicePath, p_rulLocationId);
            }

            DeleteDeviceInfoList(deviceInfoList);
        }
    }

    return oResult;
}

BOOL CGatewayUsbToHidDrv::GetDeviceInfos(tHidDeviceInfoList& p_rDeviceInfoList)
{
    BOOL oResult(0);

    if(m_pHidHndl!=0 && m_pHidHndl->IsValid())
    {
        //Reset
        DeleteDeviceInfoList(p_rDeviceInfoList);

		oResult = m_pHidHndl->GetDeviceInfos(p_rDeviceInfoList);
    }

    return oResult;
}

BOOL CGatewayUsbToHidDrv::DeleteDeviceInfoList(tHidDeviceInfoList& p_rDeviceInfoList)
{
    BOOL oResult = TRUE;
    CHidDeviceInfo* pDeviceInfo(0);
        
	for(tHidDeviceInfoList::iterator it=p_rDeviceInfoList.begin(); it!=p_rDeviceInfoList.end(); it++)
    {
        pDeviceInfo = (*it);
        delete pDeviceInfo;
    }

    p_rDeviceInfoList.clear();
    return oResult;
}

BOOL CGatewayUsbToHidDrv::InitUsbDeviceInfoHandling(CHidDeviceInfoHandling* p_pUsbDeviceInfoHandling)
{
    BOOL oResult(1);

    m_pUsbDeviceInfoHandling = p_pUsbDeviceInfoHandling;

    return oResult;
}
#endif //_MMC_I_HID
