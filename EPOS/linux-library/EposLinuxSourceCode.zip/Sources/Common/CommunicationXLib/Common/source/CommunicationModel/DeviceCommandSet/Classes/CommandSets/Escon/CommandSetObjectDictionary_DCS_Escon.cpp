// CommandSetObjectDictionary_DCS_Escon.cpp: Implementierung der Klasse CCommandSetObjectDictionary_DCS_Escon.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CommandSetObjectDictionary_DCS_Escon.h"

#ifdef _MMC_DCS_ESCON

#include <CommunicationModel/CommonLayer/Classes/Commands/DeviceCommandSet/Command_DCS_Escon.h>
#include <CommunicationModel/CommonLayer/Classes/Commands/DeviceCommandSet/DcsEsconDef.h>

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////
CCommandSetObjectDictionary_DCS_Escon::CCommandSetObjectDictionary_DCS_Escon()
{
    m_strCommandSetName = COMMAND_SET_OBJECT_DICTIONARY;

    m_pCommand_WriteObject = 0;
    m_pCommand_InitiateSegmentedWrite = 0;
    m_pCommand_SegmentedWrite = 0;
    m_pCommand_ReadObject = 0;
    m_pCommand_InitiateSegmentedRead = 0;
    m_pCommand_SegmentedRead = 0;
    m_pCommand_AbortSegmentedTransfer = 0;

    InitCommands();
}

CCommandSetObjectDictionary_DCS_Escon::~CCommandSetObjectDictionary_DCS_Escon()
{
    DeleteCommands();
}

BOOL CCommandSetObjectDictionary_DCS_Escon::DCS_InitiateSegmentedRead(CLayerManagerBase* p_pManager, HANDLE p_hHandle, HANDLE p_hTransactionHandle, WORD p_usNodeId, WORD p_usIndex, WORD p_usSubIndex, CErrorInfo* p_pErrorInfo)
{
    DWORD ulDeviceErrorCode;
    BYTE ubSubIndex = (BYTE)p_usSubIndex;
    BYTE ubNodeId = (BYTE)p_usNodeId;
    BOOL oResult(0);

    if(m_pCommand_InitiateSegmentedRead)
    {
        //Set Parameter Data
        m_pCommand_InitiateSegmentedRead->ResetStatus();
        m_pCommand_InitiateSegmentedRead->SetParameterData(0, &p_usIndex, sizeof(p_usIndex));
        m_pCommand_InitiateSegmentedRead->SetParameterData(1, &ubSubIndex, sizeof(ubSubIndex));
        m_pCommand_InitiateSegmentedRead->SetParameterData(2, &ubNodeId, sizeof(ubNodeId));

        //Execute command
        oResult = m_pCommand_InitiateSegmentedRead->Execute(p_pManager, p_hHandle, p_hTransactionHandle);

        //Get ReturnParameter Data
        m_pCommand_InitiateSegmentedRead->GetReturnParameterData(0, &ulDeviceErrorCode, sizeof(ulDeviceErrorCode));

        //Get ErrorCode
        m_pCommand_InitiateSegmentedRead->GetErrorInfo(p_pErrorInfo);
    }

    return oResult;
}

BOOL CCommandSetObjectDictionary_DCS_Escon::DCS_InitiateSegmentedWrite(CLayerManagerBase* p_pManager, HANDLE p_hHandle, HANDLE p_hTransactionHandle, WORD p_usNodeId, WORD p_usIndex, WORD p_usSubIndex, DWORD p_ulObjectLength, CErrorInfo* p_pErrorInfo)
{
    DWORD ulDeviceErrorCode;
    BYTE ubSubIndex = (BYTE)p_usSubIndex;
    BYTE ubNodeId = (BYTE)p_usNodeId;
    BOOL oResult(0);

    if(m_pCommand_InitiateSegmentedWrite)
    {
        //Set Parameter Data
        m_pCommand_InitiateSegmentedWrite->ResetStatus();
        m_pCommand_InitiateSegmentedWrite->SetParameterData(0, &p_usIndex, sizeof(p_usIndex));
        m_pCommand_InitiateSegmentedWrite->SetParameterData(1, &ubSubIndex, sizeof(ubSubIndex));
        m_pCommand_InitiateSegmentedWrite->SetParameterData(2, &ubNodeId, sizeof(ubNodeId));
        m_pCommand_InitiateSegmentedWrite->SetParameterData(3, &p_ulObjectLength, sizeof(p_ulObjectLength));

        //Execute command
        oResult = m_pCommand_InitiateSegmentedWrite->Execute(p_pManager, p_hHandle, p_hTransactionHandle);

        //Get ReturnParameter Data
        m_pCommand_InitiateSegmentedWrite->GetReturnParameterData(0, &ulDeviceErrorCode, sizeof(ulDeviceErrorCode));

        //Get ErrorCode
        m_pCommand_InitiateSegmentedWrite->GetErrorInfo(p_pErrorInfo);
    }

    return oResult;
}

BOOL CCommandSetObjectDictionary_DCS_Escon::DCS_AbortSegmentedTransfer(CLayerManagerBase* p_pManager, HANDLE p_hHandle, HANDLE p_hTransactionHandle, WORD p_usNodeId, WORD p_usIndex, WORD p_usSubIndex, DWORD p_ulAbortCode, CErrorInfo* p_pErrorInfo)
{
    BYTE ubSubIndex = (BYTE)p_usSubIndex;
    BOOL oResult(0);

    if(m_pCommand_AbortSegmentedTransfer)
    {
        //Set Parameter Data
        m_pCommand_AbortSegmentedTransfer->ResetStatus();
        m_pCommand_AbortSegmentedTransfer->SetParameterData(0, &p_usNodeId, sizeof(p_usNodeId));
        m_pCommand_AbortSegmentedTransfer->SetParameterData(1, &p_usIndex, sizeof(p_usIndex));
        m_pCommand_AbortSegmentedTransfer->SetParameterData(2, &ubSubIndex, sizeof(ubSubIndex));
        m_pCommand_AbortSegmentedTransfer->SetParameterData(3, &p_ulAbortCode, sizeof(p_ulAbortCode));

        //Execute command
        oResult = m_pCommand_AbortSegmentedTransfer->Execute(p_pManager, p_hHandle, p_hTransactionHandle);

        //Get ErrorCode
        m_pCommand_AbortSegmentedTransfer->GetErrorInfo(p_pErrorInfo);
    }

    return oResult;
}

BOOL CCommandSetObjectDictionary_DCS_Escon::DCS_ReadObject(CLayerManagerBase* p_pManager, HANDLE p_hHandle, HANDLE p_hTransactionHandle, WORD p_usNodeId, WORD p_usIndex, WORD p_usSubIndex, BYTE* p_pubObjectBuffer, DWORD p_ulObjectLength, CErrorInfo* p_pErrorInfo)
{
    DWORD ulDeviceErrorCode;
    BYTE ubSubIndex = (BYTE)p_usSubIndex;
    BYTE ubNodeId = (BYTE)p_usNodeId;
    BOOL oResult(0);

    if(m_pCommand_ReadObject)
    {
        //Set Parameter Data
        m_pCommand_ReadObject->ResetStatus();
        m_pCommand_ReadObject->SetParameterData(0, &p_usIndex, sizeof(p_usIndex));
        m_pCommand_ReadObject->SetParameterData(1, &ubSubIndex, sizeof(ubSubIndex));
        m_pCommand_ReadObject->SetParameterData(2, &ubNodeId, sizeof(ubNodeId));
        m_pCommand_ReadObject->SetParameterData(3, &p_ulObjectLength, sizeof(p_ulObjectLength));

        //Execute Command
        oResult = m_pCommand_ReadObject->Execute(p_pManager, p_hHandle, p_hTransactionHandle);

        //Get ReturnParameter Data
        m_pCommand_ReadObject->GetReturnParameterData(0, &ulDeviceErrorCode, sizeof(ulDeviceErrorCode));
        m_pCommand_ReadObject->GetReturnParameterData(1, p_pubObjectBuffer, p_ulObjectLength);

        //Get ErrorCode
        m_pCommand_ReadObject->GetErrorInfo(p_pErrorInfo);
    }

    return oResult;
}

BOOL CCommandSetObjectDictionary_DCS_Escon::DCS_SegmentedRead(CLayerManagerBase* p_pManager, HANDLE p_hHandle, HANDLE p_hTransactionHandle, WORD p_usNodeId, BOOL p_oToggle, BOOL* p_poMoreSegments, BYTE* p_pubSegmentBuffer, DWORD p_ulSegmentBufferLength, DWORD* p_pulSegmentLengthRead, CErrorInfo* p_pErrorInfo)
{
    DWORD ulDeviceErrorCode(0);
    UEsconControlByte controlByte;
    BYTE ubDummyByte = 0;
    BOOL oResult(0);

    if(m_pCommand_SegmentedRead)
    {
        //Prepare ControlByte
        controlByte.bValue = 0;
        controlByte.structure.bToggle = p_oToggle;

        //Set Parameter Data
        m_pCommand_SegmentedRead->ResetStatus();
        m_pCommand_SegmentedRead->SetParameterData(0, &p_usNodeId, sizeof(p_usNodeId));
        m_pCommand_SegmentedRead->SetParameterData(1, &controlByte, sizeof(controlByte));
        m_pCommand_SegmentedRead->SetParameterData(2, &ubDummyByte, sizeof(ubDummyByte));

        //Execute Command
        oResult = m_pCommand_SegmentedRead->Execute(p_pManager, p_hHandle, p_hTransactionHandle);

        //Get ReturnParameter Data
        m_pCommand_SegmentedRead->GetReturnParameterData(0, &ulDeviceErrorCode, sizeof(ulDeviceErrorCode));
        m_pCommand_SegmentedRead->GetReturnParameterData(1, &controlByte, sizeof(controlByte));
        m_pCommand_SegmentedRead->GetReturnParameterData(2, p_pubSegmentBuffer, p_ulSegmentBufferLength);

        //Get ErrorCode
        m_pCommand_SegmentedRead->GetErrorInfo(p_pErrorInfo);

        //Restore ControlByte
        if(p_pulSegmentLengthRead) *p_pulSegmentLengthRead = controlByte.structure.bLength;
        if(p_poMoreSegments) *p_poMoreSegments = controlByte.structure.bMoreSegments;
    }

    return oResult;
}

BOOL CCommandSetObjectDictionary_DCS_Escon::DCS_SegmentedWrite(CLayerManagerBase* p_pManager, HANDLE p_hHandle, HANDLE p_hTransactionHandle, WORD p_usNodeId, BOOL p_oToggle, BOOL p_oMoreSegments, BYTE* p_pubSegmentBuffer, DWORD p_ulSegmentLength, DWORD* p_pulSegmentLengthWritten, CErrorInfo* p_pErrorInfo)
{
    DWORD ulDeviceErrorCode(0);
    UEsconControlByte controlByte;
    BOOL oResult(0);

    if(m_pCommand_SegmentedWrite)
    {
        //Prepare ControlByte
        controlByte.bValue = 0;
        controlByte.structure.bLength = p_ulSegmentLength;
        controlByte.structure.bToggle = p_oToggle;
        controlByte.structure.bMoreSegments = p_oMoreSegments;

        //Set Parameter Data
        m_pCommand_SegmentedWrite->ResetStatus();
        m_pCommand_SegmentedWrite->SetParameterData(0, &p_usNodeId, sizeof(p_usNodeId));
        m_pCommand_SegmentedWrite->SetParameterData(1, &controlByte, sizeof(controlByte));
        m_pCommand_SegmentedWrite->SetParameterData(2, p_pubSegmentBuffer, p_ulSegmentLength);

        //Execute Command
        oResult = m_pCommand_SegmentedWrite->Execute(p_pManager, p_hHandle, p_hTransactionHandle);

        //Get ReturnParameter Data
        m_pCommand_SegmentedWrite->GetReturnParameterData(0, &ulDeviceErrorCode, sizeof(ulDeviceErrorCode));
        m_pCommand_SegmentedWrite->GetReturnParameterData(1, &controlByte, sizeof(controlByte));

        //Restore ControlByte
        if(p_pulSegmentLengthWritten) *p_pulSegmentLengthWritten = controlByte.structure.bLength;

        //Get ErrorCode
        m_pCommand_SegmentedWrite->GetErrorInfo(p_pErrorInfo);
    }

    return oResult;
}

BOOL CCommandSetObjectDictionary_DCS_Escon::DCS_WriteObject(CLayerManagerBase* p_pManager, HANDLE p_hHandle, HANDLE p_hTransactionHandle, WORD p_usNodeId, WORD p_usIndex, WORD p_usSubIndex, BYTE* p_pubObjectBuffer, DWORD p_ulObjectLength, CErrorInfo* p_pErrorInfo)
{
    DWORD ulDeviceErrorCode(0);
    BYTE ubSubIndex = (BYTE)p_usSubIndex;
    BYTE ubNodeId = (BYTE)p_usNodeId;
    BOOL oResult(0);

    if(m_pCommand_WriteObject)
    {
        //Set Parameter Data
        m_pCommand_WriteObject->ResetStatus();
        m_pCommand_WriteObject->SetParameterData(0, &p_usIndex, sizeof(p_usIndex));
        m_pCommand_WriteObject->SetParameterData(1, &ubSubIndex, sizeof(ubSubIndex));
        m_pCommand_WriteObject->SetParameterData(2, &ubNodeId, sizeof(ubNodeId));
        m_pCommand_WriteObject->SetParameterData(3, p_pubObjectBuffer, p_ulObjectLength);
        m_pCommand_WriteObject->SetParameterData(4, &p_ulObjectLength, sizeof(p_ulObjectLength));

        //Execute Command
        oResult = m_pCommand_WriteObject->Execute(p_pManager, p_hHandle, p_hTransactionHandle);

        //Get ReturnParameter Data
        m_pCommand_WriteObject->GetReturnParameterData(0, &ulDeviceErrorCode, sizeof(ulDeviceErrorCode));

        //Get ErrorCode
        m_pCommand_WriteObject->GetErrorInfo(p_pErrorInfo);
    }

    return oResult;
}

void CCommandSetObjectDictionary_DCS_Escon::InitCommands()
{
    DeleteCommands();

    //WriteObject
    m_pCommand_WriteObject = new CCommand_DCS_Escon();
    m_pCommand_WriteObject->InitCommand(ESCON_WRITE_OBJECT);

    //ReadObject
    m_pCommand_ReadObject = new CCommand_DCS_Escon();
    m_pCommand_ReadObject->InitCommand(ESCON_READ_OBJECT);

    //InitiateSegmentedWrite
    m_pCommand_InitiateSegmentedWrite = new CCommand_DCS_Escon();
    m_pCommand_InitiateSegmentedWrite->InitCommand(ESCON_INITIATE_SEGMENT_WRITE);

    //InitiateSegmentedRead
    m_pCommand_InitiateSegmentedRead = new CCommand_DCS_Escon();
    m_pCommand_InitiateSegmentedRead->InitCommand(ESCON_INITIATE_SEGMENT_READ);

    //SegmentedWrite
    m_pCommand_SegmentedWrite = new CCommand_DCS_Escon();
    m_pCommand_SegmentedWrite->InitCommand(ESCON_SEGMENT_WRITE);

    //SegmentedRead
    m_pCommand_SegmentedRead = new CCommand_DCS_Escon();
    m_pCommand_SegmentedRead->InitCommand(ESCON_SEGMENT_READ);

    //AbortSegmentedTransfer
    m_pCommand_AbortSegmentedTransfer = new CCommand_DCS_Escon();
    m_pCommand_AbortSegmentedTransfer->InitCommand(ESCON_ABORT_SEGMENT_TRANSFER);
}

void CCommandSetObjectDictionary_DCS_Escon::DeleteCommands()
{
    //WriteObject
    if(m_pCommand_WriteObject)
    {
        delete m_pCommand_WriteObject;
        m_pCommand_WriteObject = 0;
    }

    //InitiateSegmentedWrite
    if(m_pCommand_InitiateSegmentedWrite)
    {
        delete m_pCommand_InitiateSegmentedWrite;
        m_pCommand_InitiateSegmentedWrite = 0;
    }

    //SegmentedWrite
    if(m_pCommand_SegmentedWrite)
    {
        delete m_pCommand_SegmentedWrite;
        m_pCommand_SegmentedWrite = 0;
    }

    //ReadObject
    if(m_pCommand_ReadObject)
    {
        delete m_pCommand_ReadObject;
        m_pCommand_ReadObject = 0;
    }

    //InitateSegmentedRead
    if(m_pCommand_InitiateSegmentedRead)
    {
        delete m_pCommand_InitiateSegmentedRead;
        m_pCommand_InitiateSegmentedRead = 0;
    }

    //SegmentedRead
    if(m_pCommand_SegmentedRead)
    {
        delete m_pCommand_SegmentedRead;
        m_pCommand_SegmentedRead = 0;
    }

    //AbortSegmentedTransfer
    if(m_pCommand_AbortSegmentedTransfer)
    {
        delete m_pCommand_AbortSegmentedTransfer;
        m_pCommand_AbortSegmentedTransfer = 0;
    }
}

void CCommandSetObjectDictionary_DCS_Escon::ResetJournalManager()
{
    if(m_pCommand_WriteObject) m_pCommand_WriteObject->ResetJournalManager();
    if(m_pCommand_InitiateSegmentedWrite) m_pCommand_InitiateSegmentedWrite->ResetJournalManager();
    if(m_pCommand_SegmentedWrite) m_pCommand_SegmentedWrite->ResetJournalManager();
    if(m_pCommand_ReadObject) m_pCommand_ReadObject->ResetJournalManager();
    if(m_pCommand_InitiateSegmentedRead) m_pCommand_InitiateSegmentedRead->ResetJournalManager();
    if(m_pCommand_SegmentedRead) m_pCommand_SegmentedRead->ResetJournalManager();
    if(m_pCommand_AbortSegmentedTransfer) m_pCommand_AbortSegmentedTransfer->ResetJournalManager();
}

void CCommandSetObjectDictionary_DCS_Escon::InitJournalManager(CJournalManagerBase* p_pJournalManager)
{
    if(m_pCommand_WriteObject) m_pCommand_WriteObject->InitJournalManager(p_pJournalManager);
    if(m_pCommand_InitiateSegmentedWrite) m_pCommand_InitiateSegmentedWrite->InitJournalManager(p_pJournalManager);
    if(m_pCommand_SegmentedWrite) m_pCommand_SegmentedWrite->InitJournalManager(p_pJournalManager);
    if(m_pCommand_ReadObject) m_pCommand_ReadObject->InitJournalManager(p_pJournalManager);
    if(m_pCommand_InitiateSegmentedRead) m_pCommand_InitiateSegmentedRead->InitJournalManager(p_pJournalManager);
    if(m_pCommand_SegmentedRead) m_pCommand_SegmentedRead->InitJournalManager(p_pJournalManager);
    if(m_pCommand_AbortSegmentedTransfer) m_pCommand_AbortSegmentedTransfer->InitJournalManager(p_pJournalManager);
}

BOOL CCommandSetObjectDictionary_DCS_Escon::InitGateway(CGateway *p_pGateway)
{
    if(m_pCommand_WriteObject && !m_pCommand_WriteObject->InitGateway(p_pGateway)) return 0;
    if(m_pCommand_InitiateSegmentedWrite && !m_pCommand_InitiateSegmentedWrite->InitGateway(p_pGateway)) return 0;
    if(m_pCommand_SegmentedWrite && !m_pCommand_SegmentedWrite->InitGateway(p_pGateway)) return 0;
    if(m_pCommand_ReadObject && !m_pCommand_ReadObject->InitGateway(p_pGateway)) return 0;
    if(m_pCommand_InitiateSegmentedRead && !m_pCommand_InitiateSegmentedRead->InitGateway(p_pGateway)) return 0;
    if(m_pCommand_SegmentedRead && !m_pCommand_SegmentedRead->InitGateway(p_pGateway)) return 0;
    if(m_pCommand_AbortSegmentedTransfer && !m_pCommand_AbortSegmentedTransfer->InitGateway(p_pGateway)) return 0;
    return 1;
}

CXXMLFile::CElementPart* CCommandSetObjectDictionary_DCS_Escon::StoreToXMLFile(CXXMLFile* p_pFile, CXXMLFile::CElementPart* p_pParentElement)
{
    CXXMLFile::CElement* pElement;
    BOOL oCheckVisibility = 0;

    if(p_pFile && p_pParentElement)
    {
        //CommandSet Elements
        pElement = (CXXMLFile::CElement*)p_pFile->AddElement(p_pParentElement);
        p_pFile->SetText(pElement, "CommandSet");
        pElement->AttributeToValue["Name"] = m_strCommandSetName;

        //Command Elements
        if(m_pCommand_ReadObject && !m_pCommand_ReadObject->StoreToXMLFile(p_pFile, pElement, oCheckVisibility)) return 0;
        if(m_pCommand_WriteObject && !m_pCommand_WriteObject->StoreToXMLFile(p_pFile, pElement, oCheckVisibility)) return 0;
        if(m_pCommand_InitiateSegmentedRead && !m_pCommand_InitiateSegmentedRead->StoreToXMLFile(p_pFile, pElement, oCheckVisibility)) return 0;
        if(m_pCommand_SegmentedRead && !m_pCommand_SegmentedRead->StoreToXMLFile(p_pFile, pElement, oCheckVisibility)) return 0;
        if(m_pCommand_InitiateSegmentedWrite && !m_pCommand_InitiateSegmentedWrite->StoreToXMLFile(p_pFile, pElement, oCheckVisibility)) return 0;
        if(m_pCommand_SegmentedWrite && !m_pCommand_SegmentedWrite->StoreToXMLFile(p_pFile, pElement, oCheckVisibility)) return 0;
        if(m_pCommand_AbortSegmentedTransfer && !m_pCommand_AbortSegmentedTransfer->StoreToXMLFile(p_pFile, pElement, oCheckVisibility)) return 0;

        return pElement;
    }

    return 0;
}
#endif //_MMC_DCS_ESCON
