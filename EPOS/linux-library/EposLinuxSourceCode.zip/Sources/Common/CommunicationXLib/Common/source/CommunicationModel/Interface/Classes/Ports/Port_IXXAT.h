// Port_IXXAT.h: Schnittstelle f�r die Klasse CPort_IXXAT.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PORT_IXXAT_H__F9FC9D8C_45C9_424E_BD75_0D48DE86CCCA__INCLUDED_)
#define AFX_PORT_IXXAT_H__F9FC9D8C_45C9_424E_BD75_0D48DE86CCCA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <MmcDefinitions.h>
#ifdef _MMC_I_IXXAT

#include "BaseClasses/PortBase.h"

class CCommand_I_CAN;
class CJournalManagerBase;

class CPort_IXXAT : public CPortBase
{
public:
	CPort_IXXAT();
	CPort_IXXAT(CPort_IXXAT& rObject);
	virtual ~CPort_IXXAT();
	CPortBase* Clone();

	//Funktionalit�t
	BOOL GetCommands(CStdString* pCommandInfo);

	BOOL I_TransmitCanFrame(HANDLE hTransactionHandle,DWORD dCobId,BOOL oRtr,BYTE uDlc,void* pDataBuffer,DWORD dDataBufferLength,CErrorInfo* pErrorInfo = NULL);
	BOOL I_ReceiveCanFrame(HANDLE hTransactionHandle,DWORD* pdCobId,BOOL* poRtr,BYTE* puDlc,void* pDataBuffer,DWORD dDataBufferLength,CErrorInfo* pErrorInfo = NULL);
	BOOL I_ReceiveFilteredCanFrame(HANDLE hTransactionHandle,DWORD dCobIdFilter,BOOL oRtrFilter,DWORD* pdCobId,BOOL* poRtr,BYTE* puDlc,void* pDataBuffer,DWORD dDataBufferLength,CErrorInfo* pErrorInfo = NULL);

//JournalManager
    virtual void InitJournalManager(CJournalManagerBase *pJournalManager);
    virtual void ResetJournalManager();

private:
	BOOL InitErrorHandling();
	void SetDefault();
	void ResetPortMembers();

	void DeleteCommands();
	void InitCommands();
	void InitCommands(CGatewayIToDrv* pGateway);
	BOOL InitGateway(CGatewayIToDrv* pGateway);

	//ParameterSet
	BOOL InitParameterSet();

private:
	CCommand_I_CAN* m_pCommand_TransmitCanFrame;
	CCommand_I_CAN* m_pCommand_ReceiveCanFrame;
	CCommand_I_CAN* m_pCommand_ReceiveFilteredCanFrame;
};
#endif //_MMC_I_IXXAT

#endif // !defined(AFX_PORT_IXXAT_H__F9FC9D8C_45C9_424E_BD75_0D48DE86CCCA__INCLUDED_)
