// Device_Escon.cpp: Implementierung der Klasse CDevice_Escon.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Device_Escon.h"
#ifdef _MMC_DCS_ESCON
#include <CommunicationModel/CommonLayer/Classes/Commands/DeviceCommandSet/DcsEsconDef.h>
#include "../Gateway/Escon/GatewayEsconToMaxonSerialV2.h"
#include <CommunicationModel/ProtocolStack/ProtocolStackManagerBase.h>
#include <CommunicationModel/ProtocolStack/ProtocolStackManager.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

CDevice_Escon::CDevice_Escon()
{
    InitErrorHandling();

    FillGroupList();
    m_strDeviceName = DEVICE_ESCON;
    m_pJournalManager = 0;
}

CDevice_Escon::CDevice_Escon(const CDevice_Escon& p_rObject):CDeviceBase(p_rObject)
{
    InitErrorHandling();

    FillGroupList();
    m_strDeviceName = p_rObject.m_strDeviceName;

    InitJournalManager(p_rObject.m_pJournalManager);
    InitGroupList(m_pGateway);
}

CDeviceBase* CDevice_Escon::Clone()
{
    CDevice_Escon* pDevice;

    pDevice = new CDevice_Escon(*this);
    return pDevice;
}

CDevice_Escon::~CDevice_Escon()
{
    DeleteGroupList();
}

BOOL CDevice_Escon::InitDevice(CErrorInfo* p_pErrorInfo)
{
    BOOL oResult = 0;

    //Klassenstruktur f�r Protocolstack Escon aufbauen
    if(!InitDevice(PROTOCOL_MAXON_SERIAL_V2, p_pErrorInfo))
    {
        oResult = 0;
    }

    return oResult;
}

BOOL CDevice_Escon::InitDevice(CStdString p_ProtocolStackName, CErrorInfo* p_pErrorInfo)
{
    CProtocolStackManagerBase* pManager = 0;
    BOOL oNewCreated = 0;
    BOOL oResult = 0;

    if(p_ProtocolStackName.IsEmpty())
    {
        //Don't create a protocol stack
        oResult = 1;
    }
    else
    {
        //Is Manager already existing
        if(!FindCorrectManager(p_ProtocolStackName, &pManager) && !GetFirstManager(&pManager))
        {
            //Create new Manager
            pManager = (CProtocolStackManagerBase*) new CProtocolStackManager(m_lInstanceValue);
            oNewCreated = 1;
        }

        //Klassenstruktur f�r Device aufbauen
        if((VerifyGateway(p_ProtocolStackName)) && (pManager->PS_InitProtocolStack(p_ProtocolStackName, p_pErrorInfo)))
        {
            //Default Settings
            CDeviceBase::InitDefaultProtocolStackSettings(pManager, p_ProtocolStackName);

            if(oNewCreated) m_ProtocolStackManagerList.push_back(pManager);
            oResult = 1;
        }
        else
        {
            if(oNewCreated) delete pManager;
            oResult = 0;
        }
    }

    return oResult;
}

BOOL CDevice_Escon::InitDevice(CStdString p_ProtocolStackName, CStdString p_InterfaceName, CErrorInfo* p_pErrorInfo)
{
    CProtocolStackManagerBase* pManager = 0;
    BOOL oNewCreated = 0;
    BOOL oResult = 0;

    if(p_ProtocolStackName.IsEmpty())
    {
        //Don't create a protocol stack
        oResult = 1;
    }
    else
    {
        //Is Manager already existing
        if(!FindCorrectManager(p_ProtocolStackName, &pManager) && !GetFirstManager(&pManager))
        {
            //Create new Manager
            pManager = (CProtocolStackManagerBase*) new CProtocolStackManager(m_lInstanceValue);
            oNewCreated = 1;
        }

        //Klassenstruktur f�r Device aufbauen
        if((VerifyGateway(p_ProtocolStackName)) && (pManager->PS_InitProtocolStack(p_ProtocolStackName, p_InterfaceName, p_pErrorInfo)))
        {
            //Default Settings
            InitDefaultProtocolStackSettings(pManager, p_ProtocolStackName, p_InterfaceName);

            if(oNewCreated) m_ProtocolStackManagerList.push_back(pManager);
            oResult = 1;
        }
        else
        {
            if(oNewCreated) delete pManager;
            oResult = 0;
        }
    }

    return oResult;
}

void CDevice_Escon::FillGroupList()
{
    m_pCommandGroupStandard = new CCommandGroupStandard_DCS_Escon();
}

BOOL CDevice_Escon::InitGateway(CStdString p_ProtocolStackName)
{
    DeleteGateway();

    //�berpr�fen welcher Gateway initialisiert werden soll!
    if(p_ProtocolStackName.CompareNoCase(PROTOCOL_MAXON_SERIAL_V2) == 0)
    {
        m_pGateway = new CGatewayEsconToMaxonSerialV2();
        if(m_pGateway->InitGateway())
        {
            InitParameterSet();
            InitGroupList(m_pGateway);
            return 1;
        }
        else
        {
            DeleteGateway();
            return 0;
        }
    }

    return 0;
}

BOOL CDevice_Escon::InitParameterSet()
{
    const BYTE DEFAULT_NODE_ID = 1;
    const BYTE DEFAULT_REMOTE_NODE_ID = 0;
    const WORD DEFAULT_REMOTE_NETWORK_ID = 0;

    BOOL oResult = 0;

    if(m_pGateway)
    {
        oResult = 1;
        if(oResult) oResult &= m_pGateway->ResetParameterSet();
        if(oResult) oResult &= m_pGateway->AddParameter(_T("NodeId"), (BYTE*)&DEFAULT_NODE_ID, sizeof(DEFAULT_NODE_ID));
        if(oResult) oResult &= m_pGateway->AddParameter(_T("RemoteNetworkId"), (BYTE*)&DEFAULT_REMOTE_NETWORK_ID, sizeof(DEFAULT_REMOTE_NETWORK_ID));
        if(oResult) oResult &= m_pGateway->AddParameter(_T("RemoteNodeId"), (BYTE*)&DEFAULT_REMOTE_NODE_ID, sizeof(DEFAULT_REMOTE_NODE_ID));

    }

    return oResult;
}

BOOL CDevice_Escon::InitGroupList(CGatewayDCStoPS* p_pGateway)
{
    if(m_pCommandGroupStandard && !m_pCommandGroupStandard->InitGateway(p_pGateway)) return 0;
    return 1;
}

BOOL CDevice_Escon::VerifyGateway(CStdString p_ProtocolStackName)
{
    //�berpr�fen welcher ProtocolStack benutzt werden darf

    //GatewayEsconToMaxonSerialV2
    if(p_ProtocolStackName.CompareNoCase(PROTOCOL_MAXON_SERIAL_V2) == 0)
    {
        return 1;
    }

    return 0;
}

void CDevice_Escon::DeleteGroupList()
{
    if(m_pCommandGroupStandard)
    {
        delete m_pCommandGroupStandard;
        m_pCommandGroupStandard = 0;
    }
}

void CDevice_Escon::InitJournalManager(CJournalManagerBase* p_pJournalManager)
{
    CDeviceBase::InitJournalManager(p_pJournalManager);
    if(m_pCommandGroupStandard) m_pCommandGroupStandard->InitJournalManager(p_pJournalManager);
}

void CDevice_Escon::ResetJournalManager()
{
    CDeviceBase::ResetJournalManager();
    if(m_pCommandGroupStandard) m_pCommandGroupStandard->ResetJournalManager();
}

BOOL CDevice_Escon::GetCommands(CStdString* p_pCommandInfo)
{
    CXXMLFile xmlFile;
    CXXMLFile::CElementPart* pElementPart;
    CXXMLFile::CElement* pElement;
    BOOL oResult(1);

    if(p_pCommandInfo)
    {
        //Root
        pElementPart = xmlFile.Root();
        if(!xmlFile.IsElement(pElementPart)) return 0;

        //CommandInfo Elements
        pElement = (CXXMLFile::CElement*)xmlFile.AddElement(pElementPart);
        xmlFile.SetText(pElement, "CommandInfo");

        //CommandGroup Elements
        if(m_pCommandGroupStandard)
        {
            if(!m_pCommandGroupStandard->StoreToXMLFile(&xmlFile, pElement)) oResult = 0;
        }

        //Write to string
        xmlFile.WriteToString(p_pCommandInfo);
        return oResult;
    }

    return 0;
}

BOOL CDevice_Escon::InitDefaultProtocolStackSettings(CProtocolStackManagerBase* p_pProtocolStackManager, CStdString p_ProtocolStackName, CStdString p_InterfaceName)
{
    BOOL oResult(0);

    if(p_pProtocolStackManager)
    {
        if(p_ProtocolStackName == PROTOCOL_CAN_OPEN)
        {
            //CANopen
        }
        else if(p_InterfaceName == INTERFACE_RS232)
        {
            //RS232
        }
        else if(p_InterfaceName == INTERFACE_USB)
        {
            //USB
            oResult = p_pProtocolStackManager->PS_InitDefaultProtocolStackSettings(p_ProtocolStackName, p_InterfaceName, DEFAULT_TRANSFER_RATE_USB, DEFAULT_TIMEOUT);
        }
    }

    return oResult;
}

BOOL CDevice_Escon::InitErrorHandling()
{
    CErrorProducer errorProducer;
    CStdString strClassName = "DeviceEscon";

    if(m_pErrorHandling)
    {
        //Init ErrorProducer
        errorProducer.Init(DEVICE_COMMAND_SET_LAYER, strClassName);
        m_pErrorHandling->InitErrorProducer(&errorProducer);

        return 1;
    }

    return 0;
}
#endif //_MMC_DCS_ESCON
