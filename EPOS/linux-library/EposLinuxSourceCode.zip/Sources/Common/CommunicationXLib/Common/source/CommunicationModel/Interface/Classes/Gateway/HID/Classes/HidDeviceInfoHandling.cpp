#include "stdafx.h"
#include "HidDeviceInfoHandling.h"
#ifdef _MMC_I_HID
#include <stdio.h>
#include <memory.h>
#include <Process/MmcProcess.h>
#include <Log/MmcLogger.h>
#include <Storage/MmcFileInfo.h>
#include <Drv/Hid/HidDeviceInfo.h>

CMmcCriticalSection CHidDeviceInfoHandling::m_CriticalSection;

CHidDeviceInfoHandling::CHidDeviceInfoHandling(void):
    m_pRegistrySemaphore(0)
{
    CreateRegistrySemaphore();
}

CHidDeviceInfoHandling::~CHidDeviceInfoHandling(void)
{
    ResetDeviceInfoList();
    ResetLockedDeviceInfoList();

    DeleteRegistrySemaphore();
}

BOOL CHidDeviceInfoHandling::CreateRegistrySemaphore()
{
    const long NUMBER_OF_ALLOWED_CLIENTS(1);

    BOOL oResult(0);
    CStdString strName(_T("Maxon-HidDeviceInfoHandling"));

    if(!m_pRegistrySemaphore)
    {
        m_pRegistrySemaphore = new CMmcSemaphore(NUMBER_OF_ALLOWED_CLIENTS, NUMBER_OF_ALLOWED_CLIENTS, strName);
        oResult = 1;
    }

    return oResult;
}

BOOL CHidDeviceInfoHandling::DeleteRegistrySemaphore()
{
    if(m_pRegistrySemaphore)
    {
        delete m_pRegistrySemaphore;
        m_pRegistrySemaphore = 0;

        return 1;
    }

    return 0;
}

CMmcCriticalSection* CHidDeviceInfoHandling::GetSyncInstance()
{
    return &m_CriticalSection;
}

CHidDeviceInfoHandling& CHidDeviceInfoHandling::operator=(CHidDeviceInfoHandling& other)
{
    if(this != &other)
    {
        CopyDeviceInfoList(other.m_DeviceInfoList, m_DeviceInfoList);
        CopyDeviceInfoList(other.m_LockedDeviceInfoList, m_LockedDeviceInfoList);
    }

    return *this;
}

BOOL CHidDeviceInfoHandling::CopyDeviceInfos(CHidDeviceInfoHandling* pOther)
{
    BOOL oResult(0);

    if(pOther)
    {
        oResult = CopyDeviceInfoList(pOther->m_DeviceInfoList, m_DeviceInfoList);
    }

    return oResult;
}

BOOL CHidDeviceInfoHandling::GetPortNames(CStdStringArray& p_rPortNames)
{    
    CHidDeviceInfo* pDeviceInfo(0);
    BOOL oResult(1);

    //Reset
    p_rPortNames.clear();

    //Sort List by PortName
    SortDeviceInfoListByPortName(m_DeviceInfoList);
    SortDeviceInfoListByPortName(m_LockedDeviceInfoList);

    //Add Port Names
	for(tHidDeviceInfoList::iterator it=m_DeviceInfoList.begin();
			it!=m_DeviceInfoList.end(); it++)
	{
		CHidDeviceInfo* pDeviceInfo = (*it);
		if(pDeviceInfo!=0)
			p_rPortNames.push_back(pDeviceInfo->GetPortName());
	}

	for(tHidDeviceInfoList::iterator it=m_LockedDeviceInfoList.begin();
			it!=m_LockedDeviceInfoList.end(); it++)
	{
		CHidDeviceInfo* pDeviceInfo = (*it);
		if(pDeviceInfo!=0)
			p_rPortNames.push_back(pDeviceInfo->GetPortName());
	}
       
    //Sort PortNames
    SortPortNames(p_rPortNames);

    return oResult;
}

BOOL CHidDeviceInfoHandling::GetLocationId(CStdString p_PortName, CStdString& p_rDevicePath, DWORD& p_rulLocationId)
{     
    BOOL oResult(0);

    //Check Port Names
    if(!oResult)
    {        
		for(tHidDeviceInfoList::iterator it=m_DeviceInfoList.begin(); it!=m_DeviceInfoList.end(); it++)
        {
            CHidDeviceInfo* pDeviceInfo = (*it);
            if(pDeviceInfo)
            {
                if(p_PortName.Compare(pDeviceInfo->GetPortName()) == 0)
                {
                    p_rulLocationId = pDeviceInfo->GetLocationId();
                    p_rDevicePath = pDeviceInfo->GetDevicePath();
                    oResult = 1;
                    break;
                }
            }
        }
    }

    //Check Locked Port Names
    if(!oResult)
    {
		for(tHidDeviceInfoList::iterator it=m_LockedDeviceInfoList.begin(); it!=m_LockedDeviceInfoList.end(); it++)
        {
            CHidDeviceInfo* pDeviceInfo = (*it);        
            if(pDeviceInfo)
            {
                if(p_PortName.Compare(pDeviceInfo->GetPortName()) == 0)
                {
                    p_rulLocationId = pDeviceInfo->GetLocationId();
                    p_rDevicePath = pDeviceInfo->GetDevicePath();
                    oResult = 1;
                    break;
                }
            }
        }
    }

    return oResult;
}

BOOL CHidDeviceInfoHandling::UpdateLocationId(tHidDeviceInfoList& p_rDeviceInfoList, CStdString p_PortName)
{
    CHidDeviceInfo* pDeviceInfo(0);
    CHidDeviceInfo* pDeviceInfoToBeUpdated(0);
    BOOL oResult(0);

    if((FindDeviceInfoByPortName(p_PortName, m_DeviceInfoList, pDeviceInfoToBeUpdated) && pDeviceInfoToBeUpdated) ||
       (FindDeviceInfoByPortName(p_PortName, m_LockedDeviceInfoList, pDeviceInfoToBeUpdated) && pDeviceInfoToBeUpdated))
    {
        if(FindDeviceInfoBySerialNumber(*pDeviceInfoToBeUpdated, p_rDeviceInfoList, pDeviceInfo) && pDeviceInfo)
        {
            pDeviceInfoToBeUpdated->Init(pDeviceInfo->GetDevicePath(), pDeviceInfo->GetLocationId(), pDeviceInfo->GetSerialNumber());
            oResult = 1;
        }
    }

    return oResult;
}

BOOL CHidDeviceInfoHandling::InitDeviceInfos(tHidDeviceInfoList& p_rDeviceInfoList)
{
	BOOL oResult(0);
    CMmcSingleLock lock(m_pRegistrySemaphore, 1);

    tPortList openPortList;

    //Read DeviceInfo List from Registry
    ReadFromRegistry();

    //Update Removed Devices
    if(UpdateRemovedDevices(p_rDeviceInfoList, openPortList))
    {
        //Update Added Devices
        if(UpdateAddedDevices(p_rDeviceInfoList, openPortList))
        {
            //Write DeviceInfo List to Registry
            WriteToRegistry();

            oResult = 1;
        }
    }

    return oResult;
}

BOOL CHidDeviceInfoHandling::UpdateDeviceInfos(tHidDeviceInfoList& p_rDeviceInfoList, tPortList& p_rOpenPortList)
{
	BOOL oResult(0);

    CMmcSingleLock lock(m_pRegistrySemaphore, 1);

    //Read DeviceInfo List from Registry
    ReadFromRegistry();

    //Update Removed Devices
    if(UpdateRemovedDevices(p_rDeviceInfoList, p_rOpenPortList))
    {
        //Update Added Devices
        if(UpdateAddedDevices(p_rDeviceInfoList, p_rOpenPortList))
        {
            //Write DeviceInfo List to Registry
            WriteToRegistry();

            oResult = 1;
        }
    }

    return oResult;
}

BOOL CHidDeviceInfoHandling::UpdatePortLocked(CStdString p_PortName, BOOL p_oLocked)
{
	BOOL oResult(0);

    CMmcSingleLock lock(m_pRegistrySemaphore, 1);

    if(UpdateRegistry(p_PortName, p_oLocked))
    {
        oResult = ReadFromRegistry();
    }

    return oResult;
}

BOOL CHidDeviceInfoHandling::UpdateRemovedDevices(tHidDeviceInfoList& p_rDeviceInfoList, tPortList& p_rOpenPortList)
{
    BOOL oResult(TRUE);
    CHidDeviceInfo* pExistingDeviceInfo(0);
    CHidDeviceInfo* pLockedDeviceInfo(0);
    
	//Check Ports
    for(tHidDeviceInfoList::iterator it=m_DeviceInfoList.begin(); it!=m_DeviceInfoList.end(); it++)
    {
        CHidDeviceInfo* pDeviceInfo = (*it);
        if(pDeviceInfo)
        {
            if(!IsPortExistingInList(*pDeviceInfo, p_rDeviceInfoList, pExistingDeviceInfo))
            {
                //Port is removed
                if(!IsPortLocked(*pDeviceInfo, pLockedDeviceInfo))
                {
                    if(DeleteFromDeviceInfoList(*pDeviceInfo))
                    {
                        //Restart Check because current iterator was deleted
                        oResult = UpdateRemovedDevices(p_rDeviceInfoList, p_rOpenPortList);
                        break;
                    }
                }
            }
        }
    }
    return oResult;
}

BOOL CHidDeviceInfoHandling::UpdateAddedDevices(tHidDeviceInfoList& p_rDeviceInfoList, tPortList& p_rOpenPortList)
{
    BOOL oResult(1);
    CHidDeviceInfo* pExistingDeviceInfo(0);
    CHidDeviceInfo* pLockedDeviceInfo(0);
    CStdString portName(_T(""));
    
    //Check Ports
	for(tHidDeviceInfoList::iterator it=p_rDeviceInfoList.begin(); it!=p_rDeviceInfoList.end(); it++)
    {
        CHidDeviceInfo* pDeviceInfo = (*it);
        if(pDeviceInfo)
        {
            if(!IsPortExistingInList(*pDeviceInfo, m_DeviceInfoList, pExistingDeviceInfo))
            {
                //Port added
                if(IsPortLocked(*pDeviceInfo, pLockedDeviceInfo) && pLockedDeviceInfo)
                {
                    //Update
                    pLockedDeviceInfo->Update(*pDeviceInfo);

                    //Reopen Port
                    if(IsPortOpen(*pLockedDeviceInfo, p_rOpenPortList))
                    {
                        ReopenPort(pLockedDeviceInfo->GetPortName(), p_rOpenPortList);
                    }

                    //Restart Check
                    UpdateAddedDevices(p_rDeviceInfoList, p_rOpenPortList);
                }
                else
                {
                    //No Handle is registered for this port
                    if(AddToDeviceInfoList(*pDeviceInfo))
                    {
                        //Restart Check
                        UpdateAddedDevices(p_rDeviceInfoList, p_rOpenPortList);
                    }
                }
            }
            else
            {
                //Update
                if(pExistingDeviceInfo) pExistingDeviceInfo->Update(*pDeviceInfo);
            }
        }
    }

    return oResult;
}

BOOL CHidDeviceInfoHandling::ReopenPort(CStdString p_PortName, tPortList& p_rOpenPortList)
{
    CStdString portName(_T(""));
    CPortBase* pPort(0);
    BOOL oResult(0);
    
	for(tPortList::iterator it=p_rOpenPortList.begin(); it!=p_rOpenPortList.end(); it++)
    {
        pPort = (*it);
        if(pPort)
        {
            //Get PortName
            if(pPort->GetPortName(&portName))
            {
                //Check PortName
                if(p_PortName.Compare(portName) == 0)
                {
                    //Reopen Port
                    oResult = pPort->ReopenPort();
                    break;
                }
            }
        }
    }

    return oResult;
}

BOOL CHidDeviceInfoHandling::IsPortExistingInList(CHidDeviceInfo& p_rDeviceInfo, tHidDeviceInfoList& p_rDeviceInfoList, CHidDeviceInfo*& p_rpExistingDeviceInfo)
{    
    BOOL oResult(0);

	for(tHidDeviceInfoList::iterator it=p_rDeviceInfoList.begin(); it!=p_rDeviceInfoList.end(); it++)
    {
        CHidDeviceInfo* pDeviceInfo = (*it);
        if(pDeviceInfo->IsEqual(p_rDeviceInfo))
        {
            p_rpExistingDeviceInfo = pDeviceInfo;
            oResult = 1;
            break;
        }
    }

    return oResult;
}

BOOL CHidDeviceInfoHandling::FindDeviceInfo(CHidDeviceInfo& p_rDeviceInfo, tHidDeviceInfoList& p_rDeviceInfoList, int& p_rIndexFound)
{
    int iIndex(0);
    BOOL oResult(0);

    for(tHidDeviceInfoList::iterator it=p_rDeviceInfoList.begin(); it!=p_rDeviceInfoList.end(); it++)
    {
        CHidDeviceInfo* pDeviceInfo = (*it);
        if(pDeviceInfo->IsLocationIdEqual(p_rDeviceInfo))
        {
            p_rIndexFound = iIndex;
            oResult = 1;
            break;
        }
        iIndex++;
    }

    return oResult;
}

BOOL CHidDeviceInfoHandling::FindDeviceInfoByLocationId(CHidDeviceInfo& p_rDeviceInfo, tHidDeviceInfoList& p_rDeviceInfoList, int& p_rIndexFound)
{
    int iIndex(0);
    BOOL oResult(0);

    for(tHidDeviceInfoList::iterator it=p_rDeviceInfoList.begin(); it!=p_rDeviceInfoList.end(); it++)
    {
        CHidDeviceInfo* pDeviceInfo = (*it);
        if(pDeviceInfo->IsLocationIdEqual(p_rDeviceInfo))
        {
            p_rIndexFound = iIndex;
            oResult = 1;
            break;
        }
        iIndex++;
    }

    return oResult;
}

BOOL CHidDeviceInfoHandling::FindDeviceInfoByLocationId(CHidDeviceInfo& p_rDeviceInfo, tHidDeviceInfoList& p_rDeviceInfoList, CHidDeviceInfo*& p_rpFoundDeviceInfo)
{
    BOOL oResult(0);

    for(tHidDeviceInfoList::iterator it=p_rDeviceInfoList.begin(); it!=p_rDeviceInfoList.end(); it++)
    {
        CHidDeviceInfo* pDeviceInfo = (*it);
        if(pDeviceInfo->IsLocationIdEqual(p_rDeviceInfo))
        {
            p_rpFoundDeviceInfo = pDeviceInfo;
            oResult = 1;
            break;
        }
    }

    return oResult;
}

BOOL CHidDeviceInfoHandling::FindDeviceInfoBySerialNumber(CHidDeviceInfo& p_rDeviceInfo, tHidDeviceInfoList& p_rDeviceInfoList, int& p_rIndexFound)
{
    int iIndex(0);
    BOOL oResult(0);

    for(tHidDeviceInfoList::iterator it=p_rDeviceInfoList.begin(); it!=p_rDeviceInfoList.end(); it++)
    {
        CHidDeviceInfo* pDeviceInfo = (*it);
        if(pDeviceInfo->IsSerialNumberEqual(p_rDeviceInfo))
        {
            p_rIndexFound = iIndex;
            oResult = 1;
            break;
        }
        iIndex++;
    }

    return oResult;
}

BOOL CHidDeviceInfoHandling::FindDeviceInfoBySerialNumber(CHidDeviceInfo& p_rDeviceInfo, tHidDeviceInfoList& p_rDeviceInfoList, CHidDeviceInfo*& p_rpFoundDeviceInfo)
{     
    BOOL oResult(0);

	for(tHidDeviceInfoList::iterator it=p_rDeviceInfoList.begin(); it!=p_rDeviceInfoList.end(); it++)
    {
        CHidDeviceInfo* pDeviceInfo = (*it);
        if(pDeviceInfo->IsSerialNumberEqual(p_rDeviceInfo))
        {
            p_rpFoundDeviceInfo = pDeviceInfo;
            oResult = 1;
            break;
        }
    }

    return oResult;

}

BOOL CHidDeviceInfoHandling::FindDeviceInfoByPortName(CStdString p_PortName, tHidDeviceInfoList& p_rDeviceInfoList, CHidDeviceInfo*& p_rpDeviceInfo)
{
    CHidDeviceInfo* pDeviceInfo(0);
    BOOL oResult(0);
    
	for(tHidDeviceInfoList::iterator it=p_rDeviceInfoList.begin(); it!=p_rDeviceInfoList.end(); it++)
    {
        pDeviceInfo = (*it);
        if(pDeviceInfo->IsPortNameEqual(p_PortName))
        {
            p_rpDeviceInfo = pDeviceInfo;
            oResult = 1;
            break;
        }        
    }

    return oResult;
}

BOOL CHidDeviceInfoHandling::IsPortOpen(CHidDeviceInfo& p_rDeviceInfo, tPortList& p_rOpenPortList)
{
    CPortBase* pPort(0);
    CStdString portName(_T(""));
    BOOL oResult(0);

	for(tPortList::iterator it=p_rOpenPortList.begin(); it!=p_rOpenPortList.end(); it++)
    {
        CPortBase* pPort = (*it);
        if(pPort->GetPortName(&portName))
        {
            if(p_rDeviceInfo.IsPortNameEqual(portName))
            {
                oResult = 1;
                break;
            }
        }
    }

    return oResult;
}

BOOL CHidDeviceInfoHandling::IsPortLocked(CHidDeviceInfo& p_rDeviceInfo, CHidDeviceInfo*& p_rpLockedDeviceInfo)
{
    BOOL oResult(1);

    if(p_rDeviceInfo.GetLocationId() == 0)
    {
        //Location Id = 0 -> SerialNumber
        if(!FindDeviceInfoBySerialNumber(p_rDeviceInfo, m_LockedDeviceInfoList, p_rpLockedDeviceInfo))
        {
             oResult = 0;
        }
    }
    else
    {
        //Location Id != 0 -> LocationId
        if(!FindDeviceInfoByLocationId(p_rDeviceInfo, m_LockedDeviceInfoList, p_rpLockedDeviceInfo))
        {
             oResult = 0;
        }
    }

    return oResult;
}

BOOL CHidDeviceInfoHandling::AddToDeviceInfoList(CHidDeviceInfo& p_rDeviceInfo)
{
    CHidDeviceInfo* pDeviceInfo(0);
    CStdString portName(_T(""));
    BOOL oResult(0);

    if(GetNextFreePortName(portName))
    {
        pDeviceInfo = new CHidDeviceInfo();
        pDeviceInfo->Init(p_rDeviceInfo);
        pDeviceInfo->SetPortName(portName);
        m_DeviceInfoList.push_back(pDeviceInfo);
        oResult = 1;
    }

    return oResult;
}

BOOL CHidDeviceInfoHandling::GetNextFreePortName(CStdString& p_rPortName)
{
    int lPortIndex(0);
    CStdString portName(_T(""));
    BOOL oResult(0);

    while(!oResult)
    {
        portName.Format("HID%i", lPortIndex);
        if(!IsPortNameUsed(portName, m_DeviceInfoList) && !IsPortNameUsed(portName, m_LockedDeviceInfoList))
        {
            p_rPortName = portName;
            oResult = 1;
        }
        lPortIndex++;
    }

    return oResult;
}

BOOL CHidDeviceInfoHandling::IsPortNameUsed(CStdString p_PortName, tHidDeviceInfoList& p_rDeviceInfoList)
{
    CStdString portName(_T(""));
    
    BOOL oResult(0);

	for( tHidDeviceInfoList::iterator it=p_rDeviceInfoList.begin(); it!=p_rDeviceInfoList.end(); it++)
	{
		CHidDeviceInfo* pDeviceInfo = (*it);
	    if(pDeviceInfo->GetPortName(portName))
        {
            if(portName.CompareNoCase(p_PortName) == 0)
            {
                oResult = 1;
                break;
            }
        }
    }

    return oResult;
}

BOOL CHidDeviceInfoHandling::DeleteFromDeviceInfoList(CHidDeviceInfo& p_rDeviceInfo)
{
    int iIndex(0);
    CHidDeviceInfo* pDeviceInfo(0);
    BOOL oResult(1);

    //Find By LocationId and SerialNumber
    if(oResult && !FindDeviceInfo(p_rDeviceInfo, m_DeviceInfoList, iIndex)) oResult = 0;

    //Remove DeviceInfo from LockedDeviceInfoList
    if(oResult)
    {
		int index = 0;
		for( tHidDeviceInfoList::iterator it = m_DeviceInfoList.begin();
			it!=m_DeviceInfoList.end(); it++ )
		{
			if( index++ == iIndex )					
			{
				pDeviceInfo = (*it);
				delete pDeviceInfo;
				m_DeviceInfoList.erase(it);
				break;
			}
			else
			{
				oResult = 0;
			}
		}
    }

    return oResult;
}

BOOL CHidDeviceInfoHandling::SortDeviceInfoListByPortName(tHidDeviceInfoList& p_rDeviceInfoList)
{    
    CHidDeviceInfo deviceInfo;
    CHidDeviceInfo* pDeviceInfo(0);
    CHidDeviceInfo* pNextDeviceInfo(0);
    BOOL oExchanged = 0;
    BOOL oResult(1);
	int index0 = 0;

    //Bubble Sort Algorithm    
    do
    {
        oExchanged = 0;
        for( tHidDeviceInfoList::iterator it0 = p_rDeviceInfoList.begin();
				it0!=p_rDeviceInfoList.end(); it0++ )			
        {
            //DeviceInfo
            int index = 0;
			for( tHidDeviceInfoList::iterator it = p_rDeviceInfoList.begin();
				it!=p_rDeviceInfoList.end(); it++ )
			{
				if( index++ == index0 )
				{
					pDeviceInfo = (*it);
				}
			}

            //Next DeviceInfo
            index = 0;
			for( tHidDeviceInfoList::iterator it = p_rDeviceInfoList.begin();
				it!=p_rDeviceInfoList.end(); it++ )
			{
				if( index++ == index0+1 )
				{
					pNextDeviceInfo = (*it);
				}
			}

            //Compare DeviceInfos
            if(pDeviceInfo && pNextDeviceInfo)
            {
                //Compare PortName
                if(pDeviceInfo->GetPortName() > pNextDeviceInfo->GetPortName())
                {
                    //Interchange Values
                    deviceInfo = *pDeviceInfo;
                    *pDeviceInfo = *pNextDeviceInfo;
                    *pNextDeviceInfo = deviceInfo;

                    oExchanged = 1;
                }
            }
        }      
		index0++;
    }
    while(oExchanged);

    return oResult;
}

BOOL CHidDeviceInfoHandling::SortDeviceInfoListByLocationId(tHidDeviceInfoList& p_rDeviceInfoList)
{
    CHidDeviceInfo deviceInfo;
    CHidDeviceInfo* pDeviceInfo(0);
    CHidDeviceInfo* pNextDeviceInfo(0);
    BOOL oExchanged = 0;
    BOOL oResult(1);
	int index0 = 0;
    //Bubble Sort Algorithm
    do
    {
        oExchanged = 0;
        for( tHidDeviceInfoList::iterator it0 = p_rDeviceInfoList.begin();
				it0!=p_rDeviceInfoList.end(); it0++ )
        {
            //DeviceInfo
            int index = 0;
			for( tHidDeviceInfoList::iterator it = p_rDeviceInfoList.begin();
				it!=p_rDeviceInfoList.end(); it++ )
			{
				if( index++ == index0 )
				{
					pDeviceInfo = (*it);
				}
			}

            //Next DeviceInfo
            index = 0;
			for( tHidDeviceInfoList::iterator it = p_rDeviceInfoList.begin();
				it!=p_rDeviceInfoList.end(); it++ )
			{
				if( index++ == index0+1 )
				{
					pNextDeviceInfo = (*it);
				}
			}

            //Compare DeviceInfos
            if(pDeviceInfo && pNextDeviceInfo)
            {
                //Compare LocationId
                if(pDeviceInfo->GetLocationId() > pNextDeviceInfo->GetLocationId())
                {
                    //Interchange Values
                    deviceInfo = *pDeviceInfo;
                    *pDeviceInfo = *pNextDeviceInfo;
                    *pNextDeviceInfo = deviceInfo;

                    oExchanged = 1;
                }
            }
        }
        index0++;
    }
    while(oExchanged);

    return oResult;
}

BOOL CHidDeviceInfoHandling::SortPortNames(CStdStringArray& p_rPortNames)
{    
    CStdString portName(_T(""));
    CStdString nextPortName(_T(""));
    BOOL oExchanged = 0;
    BOOL oResult(FALSE);
	int index0 = 0;
    
	//Bubble Sort Algorithm    
    do
    {
        oExchanged = FALSE;
		int index = 0;
		for(CStdStringArray::iterator it=p_rPortNames.begin(); it!=p_rPortNames.end(); it++)
        {
            if(it+1 != p_rPortNames.end())
            {
                //DeviceInfo
                portName = (*it);

                //Next DeviceInfo
                nextPortName = *(it+1);

                //Compare PortName
                if(portName > nextPortName)
                {
                    //Interchange Values
				    p_rPortNames[index] = nextPortName;
                    p_rPortNames[index+1] = portName;
                    oExchanged = TRUE;
                }
            }
			index++;
        }        
    }
    while(oExchanged);

    return oResult;
}

BOOL CHidDeviceInfoHandling::CopyDeviceInfoList(tHidDeviceInfoList& p_rSourceDeviceInfoList, tHidDeviceInfoList& p_rTargetDeviceInfoList)
{
    CHidDeviceInfo* pClonedDeviceInfo(0);
    BOOL oResult(0);

    if(DeleteDeviceInfoList(p_rTargetDeviceInfoList))
    {
        oResult = 1;
        for(tHidDeviceInfoList::iterator it=p_rSourceDeviceInfoList.begin(); it!=p_rSourceDeviceInfoList.end(); it++)
		{
			CHidDeviceInfo* pDeviceInfo = (*it);
		    pClonedDeviceInfo = pDeviceInfo->Clone();
            if(pClonedDeviceInfo)
                p_rTargetDeviceInfoList.push_back(pClonedDeviceInfo);            
        }
    }

    return oResult;
}

BOOL CHidDeviceInfoHandling::DeleteDeviceInfoList(tHidDeviceInfoList& p_rDeviceInfoList)
{
	for(tHidDeviceInfoList::iterator it=p_rDeviceInfoList.begin(); it!=p_rDeviceInfoList.end(); it++)
	{
		CHidDeviceInfo* pDeviceInfo = (*it);	
        delete pDeviceInfo;
    }

    p_rDeviceInfoList.clear();
    return TRUE;
}

BOOL CHidDeviceInfoHandling::AddDeviceInfo(CStdString p_PortName, CStdString p_DevicePath, DWORD p_ulLocationId, CStdString p_SerialNumber)
{
    CHidDeviceInfo* pDeviceInfo(0);
    BOOL oResult(1);

    pDeviceInfo = new CHidDeviceInfo();
    pDeviceInfo->Init(p_DevicePath, p_ulLocationId, p_SerialNumber);
    pDeviceInfo->SetPortName(p_PortName);
    m_DeviceInfoList.push_back(pDeviceInfo);

    return oResult;
}

BOOL CHidDeviceInfoHandling::ResetDeviceInfoList()
{
    BOOL oResult(0);

    oResult = DeleteDeviceInfoList(m_DeviceInfoList);

    return oResult;
}

BOOL CHidDeviceInfoHandling::ResetLockedDeviceInfoList()
{
    BOOL oResult(0);

    oResult = DeleteDeviceInfoList(m_LockedDeviceInfoList);

    return oResult;
}

BOOL CHidDeviceInfoHandling::DeleteFromRegistry()
{
	CStdString subKey = _T("");

	//Init
	GetRegistryKey(subKey);
	
	CMmcUserSettings userSettings(subKey);

	//Delete
	return userSettings.Delete(subKey);
}

BOOL CHidDeviceInfoHandling::WriteToRegistry()
{
	BOOL oResult(0);
    CStdString subKey(_T(""));
    long entryIndex(0);
    CStdString entryName(_T(""));
    CHidDeviceInfo* pDeviceInfo(0);
    BOOL oLocked = 0;

    //Init
    DeleteFromRegistry();

    GetRegistryKey(subKey);

	CMmcUserSettings userSettings(subKey);
  
	//Init
	oResult = 1;
	entryIndex = 0;

    //DeviceInfo List
    for(tHidDeviceInfoList::iterator it=m_DeviceInfoList.begin(); it!=m_DeviceInfoList.end(); it++)
	{
		CHidDeviceInfo* pDeviceInfo = (*it);	
	
        entryName.Format("HidDeviceInfo%i", entryIndex++);
        
        oLocked = 0;
        
		if(!WriteDeviceInfoToRegistry(&userSettings, entryName, pDeviceInfo, oLocked))
            oResult = 0;        
    }

    //Locked DeviceInfo List
	for(tHidDeviceInfoList::iterator it=m_LockedDeviceInfoList.begin(); it!=m_LockedDeviceInfoList.end(); it++)
	{
		CHidDeviceInfo* pDeviceInfo = (*it);	
        entryName.Format("HidDeviceInfo%i", entryIndex++);
        
        oLocked = 1;
        if(!WriteDeviceInfoToRegistry(&userSettings, entryName, pDeviceInfo, oLocked))
            oResult = 0;        
    }

    return oResult;
}

BOOL CHidDeviceInfoHandling::ReadFromRegistry()
{
	BOOL oResult(0);
    CStdString subKey(_T(""));
    DWORD dwIndex(0);
    CHidDeviceInfo* pDeviceInfo(0);
    BOOL oLocked = 0;
    
    //Init
    GetRegistryKey(subKey);

	CMmcUserSettings userSettings(subKey);

	std::list<CMmcUserSettings*> children = userSettings.GetChildren();

	for( std::list<CMmcUserSettings*>::iterator it = children.begin();
		it != children.end(); it++ )
	{
		CMmcUserSettings* pChild = (*it);
		CHidDeviceInfo* pDeviceInfo = new CHidDeviceInfo();		
		
		if(ReadDeviceInfoFromRegistry(pChild, pDeviceInfo, oLocked))
		{
			if(!oLocked)
            {
                //Device Info List
                m_DeviceInfoList.push_back(pDeviceInfo);
            }
            else
            {
                //Locked Device Info List
                m_LockedDeviceInfoList.push_back(pDeviceInfo);
            }
		}
		else
		{
			//Delete DeviceInfo
			delete pDeviceInfo;
			oResult = false;
			break;
		}

		delete pChild;
	}

    return oResult;
}

BOOL CHidDeviceInfoHandling::UpdateRegistry(CStdString p_PortName, BOOL p_oLocked)
{
	BOOL oResult = FALSE;
	CStdString subKey = _T("");
	CHidDeviceInfo deviceInfo;
	
	//Init
	GetRegistryKey(subKey);

	CMmcUserSettings userSettings(subKey);

	std::list<CMmcUserSettings*> children = userSettings.GetChildren();

	for( std::list<CMmcUserSettings*>::iterator it = children.begin();
		it != children.end(); it++ )
	{
		CMmcUserSettings* pChild = (*it);
		if(ReadDeviceInfoFromRegistry(pChild, &deviceInfo, p_oLocked))
		{
			if(deviceInfo.GetPortName() == p_PortName)
			{
				//Update Locked Flag
				oResult = WriteLockedToRegistry(pChild, p_oLocked);
				break;
			}
		}
		delete pChild;
	}

	return oResult;	
}

BOOL CHidDeviceInfoHandling::WriteDeviceInfoToRegistry(CMmcUserSettings* pUserSettings, CStdString p_ValueName, CHidDeviceInfo* p_pDeviceInfo, BOOL p_oLocked)
{
	BOOL oResult = FALSE;
	DWORD dDisposition = 0;
	CStdString portName(_T(""));
    CStdString serialNumber(_T(""));
    CStdString devicePath(_T(""));
	DWORD locationId = 0;
	DWORD locked(0);
		
	if(p_pDeviceInfo)
	{
		CMmcUserSettings userSettings(pUserSettings, p_ValueName );

		//Init
		oResult = 1;
        devicePath = p_pDeviceInfo->GetDevicePath();
        p_pDeviceInfo->GetPortName(portName);
        serialNumber = p_pDeviceInfo->GetSerialNumber();
        locationId = p_pDeviceInfo->GetLocationId();
        if(p_oLocked) locked = 1; else locked = 0;

		//Write
		if(oResult && !userSettings.Write("", portName)) oResult = FALSE;
		if(oResult && !userSettings.Write("SerialNumber", serialNumber)) oResult = FALSE;
		if(oResult && !userSettings.Write("DevicePath", devicePath)) oResult = FALSE;
		if(oResult && !userSettings.Write("LocationId", locationId)) oResult = FALSE;
		if(oResult && !userSettings.Write("Locked", locked)) oResult = FALSE;
		
	}
	return oResult;	
}

BOOL CHidDeviceInfoHandling::WriteLockedToRegistry(CMmcUserSettings* pUserSettings, BOOL p_oLocked)
{
	BOOL oResult(0);
	    
	if( pUserSettings != 0 )
	{
		DWORD locked(0);

		//Init
        oResult = 1;
        if(p_oLocked) locked = 1; else locked = 0;

		//Write
		if(oResult && !pUserSettings->Write("Locked", locked)) oResult = FALSE;
	}
	
	return oResult;
}

BOOL CHidDeviceInfoHandling::ReadDeviceInfoFromRegistry(CMmcUserSettings* pUserSettings, CHidDeviceInfo* p_pDeviceInfo, BOOL& p_roLocked)
{
	BOOL oResult = FALSE;
			
    if(p_pDeviceInfo && pUserSettings)
	{
		//Read
		CStdString portName = pUserSettings->ReadString("");
		CStdString devicePath = pUserSettings->ReadString("DevicePath");
		CStdString serialNumber = pUserSettings->ReadString("SerialNumber");

		DWORD locationId = pUserSettings->ReadULONG("LocationId");
		DWORD locked = pUserSettings->ReadULONG("Locked");

		//Return Values
		p_pDeviceInfo->SetPortName(portName);
        p_pDeviceInfo->Init(devicePath, locationId, serialNumber);
        p_roLocked = locked;
		
		return TRUE;
	}

    return FALSE;
}

BOOL CHidDeviceInfoHandling::GetRegistryKey(CStdString& p_rRegistryKey)
{
    CStdString subKey = _T("");
    BOOL oResult(0);

    //Init
    subKey.Format("%s\\%s", REGISTRY_MAXON, REGISTRY_HID_USB_HANDLING);
    p_rRegistryKey = subKey;
    oResult = 1;

    return oResult;
}

BOOL CHidDeviceInfoHandling::GetApplicationInfo(CStdString& p_rApplicationName, CStdString& p_rVersion)
{
    CStdString fileName = MmcGetModuleName();

	if( !fileName.IsEmpty() )
	{
		p_rVersion = CMmcFileInfo::GetFileVersion(fileName);
		p_rApplicationName = ExtractApplicationName(fileName);
		return TRUE;
	}
    
    return FALSE;
}

BOOL CHidDeviceInfoHandling::GetModuleVersion(CStdString& p_rVersion)
{
    CStdString fileName = MmcGetModuleName();

	if( !fileName.IsEmpty() )
	{
		p_rVersion = CMmcFileInfo::GetFileVersion(fileName);
		return TRUE;
	}
    
    return FALSE;
}

CStdString CHidDeviceInfoHandling::ExtractApplicationName(CStdString p_FileName)
{
    int iIndexStart = 0;
    int iIndexEnd = 0;
    CStdString appName(_T(""));

    iIndexStart = p_FileName.ReverseFind('\\');
    iIndexEnd = p_FileName.ReverseFind('.');
    if((iIndexStart != -1) && (iIndexEnd != -1))
    {
        if(iIndexStart < iIndexEnd)
        {
            appName = p_FileName.Mid(iIndexStart, iIndexEnd - iIndexStart);
            appName = appName.TrimLeft('\\');
        }
    }

    return appName;
}
#endif //_MMC_I_HID
