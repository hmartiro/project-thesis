// GatewayCANopenToNI.cpp: Implementierung der Klasse CGatewayCANopenToNI.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "GatewayCANopenToNI.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////
CGatewayCANopenToNI::CGatewayCANopenToNI()
{
	InitErrorHandling();
}

CGatewayCANopenToNI::~CGatewayCANopenToNI()
{
}

CGateway* CGatewayCANopenToNI::Clone()
{
	CGatewayCANopenToNI* pClonedGateway;

	pClonedGateway = new CGatewayCANopenToNI();
	*pClonedGateway = *this;

	return pClonedGateway;
}

CGatewayCANopenToNI& CGatewayCANopenToNI::operator=(CGatewayCANopenToNI& other)
{
	if(this != &other)
	{
		*((CGatewayCANopenToI*)this) = *((CGatewayCANopenToI*)&other);
	}

	return *this;
}

/************************************************************************/
BOOL CGatewayCANopenToNI::InitErrorHandling()
{
	CErrorProducer errorProducer;
	CStdString strClassName = "GatewayCANopenToNI";

	if(m_pErrorHandling)
	{
		//Init ErrorProducer
		errorProducer.Init(PROTOCOL_STACK_LAYER,strClassName);
		m_pErrorHandling->InitErrorProducer(&errorProducer);
		return TRUE;
	}

	return FALSE;
}

