// CommandGroupStandard_VCS_Move.h: Schnittstelle f�r die Klasse CommandGroupStandard_VCS_Move.
//
//////////////////////////////////////////////////////////////////////

#pragma once

#include <CommunicationModel/Common/CommunicationModelDefinitions.h>
#ifdef _MMC_VCS_MOVE

#include <Classes/XXMLFile.h>
#include "../BaseClasses/CommandGroupBase_VCS.h"

class CCommandSetConfiguration_VCS_Move;
class CCommandSetConfigurationMotor_VCS_Move;
class CCommandSetConfigurationSensor_VCS_Move;
class CCommandSetCurrentMode_VCS_Move;
class CCommandSetInputsOutputs_VCS_Move;
class CCommandSetMotionInfo_VCS_Move;
class CCommandSetPositionMode_VCS_Move;
class CCommandSetStateMachine_VCS_Move;
class CCommandSetVelocityMode_VCS_Move;

class CCommandSetObjectDictionary_VCS_CanOpen;
class CCommandSetGeneralGateway_VCS_CanOpen;

class CCommandSetErrorHandling_VCS_Common;
class CCommandSetVersion_VCS_Common;

class CCommandSetDataRecording_VCS_DataRecorder;

class CGateway;

class CCommandGroupStandard_VCS_Move : public CCommandGroupBase_VCS
{
public:
    CXXMLFile::CElementPart* StoreToXMLFile(CXXMLFile* p_pFile, CXXMLFile::CElementPart* p_pParentElement);

    CCommandGroupStandard_VCS_Move();
    virtual ~CCommandGroupStandard_VCS_Move();

//JournalManager
    virtual void InitJournalManager(CJournalManagerBase *p_pJournalManager);
    virtual void ResetJournalManager();

//Gateway
    virtual BOOL InitGateway(CGateway *p_pGateway);

private:
    void DeleteSetList();
    void FillSetList();

    CCommandSetConfiguration_VCS_Move*             m_pCommandSetConfiguration;
    CCommandSetConfigurationMotor_VCS_Move*        m_pCommandSetConfigurationMotor;
    CCommandSetConfigurationSensor_VCS_Move*       m_pCommandSetConfigurationSensor;
    CCommandSetCurrentMode_VCS_Move*               m_pCommandSetCurrentMode;
    CCommandSetInputsOutputs_VCS_Move*             m_pCommandSetInputsOutputs;
    CCommandSetMotionInfo_VCS_Move*                m_pCommandSetMotionInfo;
    CCommandSetPositionMode_VCS_Move*              m_pCommandSetPositionMode;
    CCommandSetStateMachine_VCS_Move*              m_pCommandSetStateMachine;
    CCommandSetVelocityMode_VCS_Move*              m_pCommandSetVelocityMode;

    CCommandSetObjectDictionary_VCS_CanOpen*         m_pCommandSetObjectDictionary;
    CCommandSetGeneralGateway_VCS_CanOpen*           m_pCommandSetGeneralGateway;

    CCommandSetErrorHandling_VCS_Common*             m_pCommandSetErrorHandling;
    CCommandSetVersion_VCS_Common*                     m_pCommandSetVersion;

    CCommandSetDataRecording_VCS_DataRecorder*       m_pCommandSetDataRecording;
};
#endif //_MMC_VCS_MOVE
