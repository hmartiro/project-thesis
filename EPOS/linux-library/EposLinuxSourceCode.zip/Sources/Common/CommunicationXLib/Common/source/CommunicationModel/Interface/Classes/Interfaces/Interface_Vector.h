// Interface_Vector.h: Schnittstelle f�r die Klasse CInterface_Vector.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INTERFACE_VECTOR_H__01092328_31EA_44B4_B076_B88E46C7B275__INCLUDED_)
#define AFX_INTERFACE_VECTOR_H__01092328_31EA_44B4_B076_B88E46C7B275__INCLUDED_
#include <MmcDefinitions.h>
#ifdef _MMC_I_VECTOR
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "BaseClasses/InterfaceBase.h"

class CInterface_Vector : public CInterfaceBase
{
public:
	void Init() {m_strClassType="CInterface_Vector";}
	WORD GetNbOfAvailableBoards();

//Initialisation
	BOOL InitInterface(WORD wBoardNumber,WORD wNbBoardWithOldDriver);

	BOOL I_OpenInterface(CErrorInfo* pErrorInfo = NULL);
	BOOL I_OpenInterfacePort(CPortBase* pPort,CStdString strPortName,CErrorInfo* pErrorInfo = NULL);

	BOOL I_CloseInterface(CErrorInfo* pErrorInfo = NULL);
	BOOL I_CloseInterfacePort(CPortBase* pPort,CErrorInfo* pErrorInfo = NULL);

	BOOL I_GetInterfaceSettings(CPortBase* pPort,DWORD* pdBaudrate,DWORD* pdTimeout,CErrorInfo* pErrorInfo = NULL);
	BOOL I_SetInterfaceSettings(CPortBase* pPort,DWORD dBaudrate,DWORD dTimeout,BOOL oChangeOnly,CErrorInfo* pErrorInfo = NULL);

	BOOL I_GetInterfaceMode(WORD* pwModeIndex,CErrorInfo* pErrorInfo = NULL);
	BOOL I_SetInterfaceMode(WORD wModeIndex,CErrorInfo* pErrorInfo = NULL);

	BOOL I_ResetInterface(CPortBase* pPort,CErrorInfo* pErrorInfo = NULL);

	CInterface_Vector();
	CInterface_Vector(const CInterface_Vector& rObject);
	virtual ~CInterface_Vector();
	CInterfaceBase* Clone();

//JournalManager
    virtual void InitJournalManager(CJournalManagerBase *pJournalManager);
    virtual void ResetJournalManager();

private:
	BOOL InitErrorHandling();
	BOOL InitGateway();

	//ParameterSet
	BOOL InitParameterSet();
};
#endif //_MMC_I_VECTOR
#endif // !defined(AFX_INTERFACE_VECTOR_H__01092328_31EA_44B4_B076_B88E46C7B275__INCLUDED_)
