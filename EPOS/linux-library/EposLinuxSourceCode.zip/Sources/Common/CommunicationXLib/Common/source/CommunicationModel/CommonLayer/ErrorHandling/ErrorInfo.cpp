// ErrorInfo.cpp: Implementierung der Klasse CErrorInfo.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"

#include <CommunicationModel/CommonLayer/ErrorHandling/ErrorInfo.h>
#include <CommunicationModel/CommonLayer/ErrorHandling/ErrorHandling.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

CErrorInfo::CErrorInfo()
{
	m_pError = NULL;
	m_pErrorProducer = NULL;
}

CErrorInfo::~CErrorInfo()
{
	DeleteError();
	DeleteErrorProducer();
}
#ifdef _WIN32
void CErrorInfo::Serialize(CArchive &ar)
{
	BOOL oErrorExisting;
	BOOL oErrorProducerExisting;

	if(ar.IsStoring())
	{
		//Error
		oErrorExisting = (BOOL)m_pError;
		ar << oErrorExisting;
		if(oErrorExisting)
		{
			m_pError->Serialize(ar);
		}

		//ErrorProducer
		oErrorProducerExisting = (BOOL)m_pErrorProducer;
		ar << oErrorProducerExisting;
		if(oErrorProducerExisting)
		{
			m_pErrorProducer->Serialize(ar);
		}
	}
	else
	{
		DeleteError();
		DeleteErrorProducer();

		//Error
		ar >> oErrorExisting;
		if(oErrorExisting)
		{
			m_pError = new CError();
			m_pError->Serialize(ar);
		}

		//ErrorProducer
		ar >> oErrorProducerExisting;
		if(oErrorProducerExisting)
		{
			m_pErrorProducer = new CErrorProducer();
			m_pErrorProducer->Serialize(ar);
		}
	}
}
#endif
CErrorInfo& CErrorInfo::operator=(CErrorInfo& other)
{
	if(this != &other)
	{
		DeleteError();
		DeleteErrorProducer();

		if(other.m_pError) m_pError = other.m_pError->Clone();
		if(other.m_pErrorProducer) m_pErrorProducer = other.m_pErrorProducer->Clone();
	}

	return *this;
}

CErrorInfo* CErrorInfo::Clone()
{
	CErrorInfo* pNewErrorInfo = new CErrorInfo();
	*pNewErrorInfo = *this;

	return pNewErrorInfo;
}

void CErrorInfo::DeleteError()
{
	if(m_pError)
	{
		delete m_pError;
		m_pError = NULL;
	}
}

void CErrorInfo::DeleteErrorProducer()
{
	if(m_pErrorProducer)
	{
		delete m_pErrorProducer;
		m_pErrorProducer = NULL;
	}
}

void CErrorInfo::Init(CError *pError,CErrorProducer *pErrorProducer)
{
	//Error
	DeleteError();
	if(pError) m_pError = pError->Clone();

	//ErrorProducer
	DeleteErrorProducer();
	if(pErrorProducer) m_pErrorProducer = pErrorProducer->Clone();
}

void CErrorInfo::Init(DWORD dErrorCode,CErrorProducer *pErrorProducer)
{
	CStdString strErrorDescription;

	//Error
	DeleteError();
	m_pError = new CError();
	CErrorHandling::GetErrorDescription(dErrorCode,&strErrorDescription);
	m_pError->Init(dErrorCode,strErrorDescription);

	//ErrorProducer
	DeleteErrorProducer();
	if(pErrorProducer) m_pErrorProducer = pErrorProducer->Clone();
}

void CErrorInfo::Init(DWORD dErrorCode)
{
	CStdString strErrorDescription;

	//Error
	DeleteError();
	m_pError = new CError();
	CErrorHandling::GetErrorDescription(dErrorCode,&strErrorDescription);
	m_pError->Init(dErrorCode,strErrorDescription);

	//ErrorProducer
	DeleteErrorProducer();
}


DWORD CErrorInfo::GetErrorCode()
{
	if(m_pError)
	{
		return m_pError->GetErrorCode();
	}

	return 0;
}

BOOL CErrorInfo::IsCommandNameSet()
{
	if(m_pErrorProducer)
	{
		return m_pErrorProducer->IsCommandNameSet();
	}

	return FALSE;
}

void CErrorInfo::SetCommandName(CStdString strCommandName)
{
	if(m_pErrorProducer)
	{
		m_pErrorProducer->SetCommandName(strCommandName);
	}
}

void CErrorInfo::Reset()
{
	DeleteError();
	DeleteErrorProducer();
}
