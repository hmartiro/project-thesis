// Interface_IXXAT.cpp: Implementierung der Klasse CInterface_IXXAT.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "Interface_IXXAT.h"

#ifdef _MMC_I_IXXAT

#include "../Ports/Port_IXXAT.h"
#include "../Gateway/IXXAT/GatewayIXXATtoVCIV2.h"
#include "../Gateway/IXXAT/GatewayIXXATtoVCIV3.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////
CInterface_IXXAT::CInterface_IXXAT()
{
	Init();

    InitErrorHandling();

    if(!InitInterfaceName()) m_strInterfaceName = INTERFACE_IXXAT;
    m_pJournalManager = NULL;
}

CInterface_IXXAT::CInterface_IXXAT(const CInterface_IXXAT& rObject):CInterfaceBase(rObject)
{
    InitErrorHandling();

    InitJournalManager(rObject.m_pJournalManager);
}

CInterface_IXXAT::~CInterface_IXXAT()
{
}

CInterfaceBase* CInterface_IXXAT::Clone()
{
    CInterfaceBase* pInterfaceBase = new CInterface_IXXAT(*this);
    return pInterfaceBase;
}

//********************************************************************
void CInterface_IXXAT::InitJournalManager(CJournalManagerBase *pJournalManager)
{
    CInterfaceBase::InitJournalManager(pJournalManager);
}

//********************************************************************
void CInterface_IXXAT::ResetJournalManager()
{
    CInterfaceBase::ResetJournalManager();
}

//********************************************************************
BOOL CInterface_IXXAT::InitInterface(WORD wBoardNumber, WORD wNbBoardWithOldDriver)
{
    if(CInterfaceBase::InitInterface(wBoardNumber, wNbBoardWithOldDriver))
    {
        CPortBase* pPort = new CPort_IXXAT();
        if(pPort->InitGateway(m_pGateway) && pPort->InitPort(wBoardNumber, wNbBoardWithOldDriver))
        {
            m_PortList.push_back(pPort);
            return TRUE;
        }
        delete pPort;
    }
    return FALSE;
}

//********************************************************************
BOOL CInterface_IXXAT::InitGateway()
{
    DeleteGateway();

    if(m_wModeIndex == k_IXXAT_V2)
    {
        m_pGateway = new CGatewayIXXATtoVCIV2();
    }
    else if(m_wModeIndex == k_IXXAT_V3)
    {
        m_pGateway = new CGatewayIXXATtoVCIV3();
    }

    if(m_pGateway)
    {
        if(m_pGateway->InitGateway())
        {
            InitParameterSet();
			return TRUE;
        }
        else
        {
            DeleteGateway();
            return FALSE;
        }
    }

    return FALSE;
}

BOOL CInterface_IXXAT::InitParameterSet()
{
	BOOL oResult = FALSE;

	if(m_pGateway)
	{
		oResult = TRUE;
		if(oResult) oResult &= m_pGateway->ResetParameterSet();
	}
    
    return oResult;
}

//********************************************************************
BOOL CInterface_IXXAT::I_OpenInterface(CErrorInfo* pErrorInfo)
{
    return CInterfaceBase::I_OpenInterface(pErrorInfo);
}

//********************************************************************
BOOL CInterface_IXXAT::I_OpenInterfacePort(CPortBase* pPort, CStdString strPortName, CErrorInfo* pErrorInfo)
{
    return CInterfaceBase::I_OpenInterfacePort(pPort, strPortName, pErrorInfo);
}

//********************************************************************
BOOL CInterface_IXXAT::I_CloseInterface(CErrorInfo* pErrorInfo)
{
    return CInterfaceBase::I_CloseInterface(pErrorInfo);
}

//********************************************************************
BOOL CInterface_IXXAT::I_CloseInterfacePort(CPortBase* pPort, CErrorInfo* pErrorInfo)
{
    return CInterfaceBase::I_CloseInterfacePort(pPort, pErrorInfo);
}

//********************************************************************
BOOL CInterface_IXXAT::I_SetInterfaceSettings(CPortBase* pPort, DWORD dBaudrate, DWORD dTimeout, BOOL oChangeOnly, CErrorInfo* pErrorInfo)
{
    return CInterfaceBase::I_SetInterfaceSettings(pPort, dBaudrate, dTimeout, oChangeOnly, pErrorInfo);
}

//********************************************************************
BOOL CInterface_IXXAT::I_GetInterfaceSettings(CPortBase* pPort, DWORD* pdBaudrate, DWORD* pdTimeout, CErrorInfo* pErrorInfo)
{
    return CInterfaceBase::I_GetInterfaceSettings(pPort, pdBaudrate, pdTimeout, pErrorInfo);
}

//********************************************************************
BOOL CInterface_IXXAT::I_ResetInterface(CPortBase* pPort, CErrorInfo* pErrorInfo)
{
    return CInterfaceBase::I_ResetInterface(pPort, pErrorInfo);
}

//********************************************************************
BOOL CInterface_IXXAT::I_SetInterfaceMode(WORD wModeIndex, CErrorInfo* pErrorInfo)
{
    m_wModeIndex = wModeIndex;

    return CInterfaceBase::I_SetInterfaceMode(wModeIndex, pErrorInfo);
}

//********************************************************************
BOOL CInterface_IXXAT::I_GetInterfaceMode(WORD* pwModeIndex, CErrorInfo* pErrorInfo)
{
    *pwModeIndex = m_wModeIndex;

    return CInterfaceBase::I_GetInterfaceMode(pwModeIndex, pErrorInfo);
}

//********************************************************************
BOOL CInterface_IXXAT::InitErrorHandling()
{
    CErrorProducer errorProducer;
    CStdString strClassName = "Interface_IXXAT";

    if(m_pErrorHandling)
    {
        //Init ErrorProducer
        errorProducer.Init(INTERFACE_LAYER, strClassName);
        m_pErrorHandling->InitErrorProducer(&errorProducer);
        return TRUE;
    }

    return FALSE;
}

//********************************************************************
WORD CInterface_IXXAT::GetNbOfAvailableBoards()
{
    CGatewayIToDrv* pGateway = NULL;
    WORD wCount = 0;

    if(m_wModeIndex == k_IXXAT_V2)
    {
        pGateway = new CGatewayIXXATtoVCIV2();
    }
    else if(m_wModeIndex == k_IXXAT_V3)
    {
        pGateway = new CGatewayIXXATtoVCIV3();
    }

    if(pGateway)
    {
        wCount = pGateway->GetNbOfAvailableBoards();
        delete pGateway;
    }

    return wCount;
}
#endif //_MMC_I_IXXAT
