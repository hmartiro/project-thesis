// GatewayNItoNiCanLib.cpp: Implementierung der Klasse CGatewayNItoNiCanLib.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "GatewayNItoNiCanLib.h"
#ifdef _MMC_I_NI

#include <malloc.h>
#include <Process/MmcProcess.h>
#include <Time/MmcHiResTimer.h>

#include <CommunicationModel/CommonLayer/Classes/Commands/Interface/BaseClasses/Command_I.h>
#include "../../../../CommonLayer/Classes/Commands/Interface/Command_I_CAN.h"
#include "../../../../Interface/BaseClasses/InterfaceManagerBase.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////
CGatewayNItoNiCanLib::CGatewayNItoNiCanLib()
{
	InitErrorHandling();
		
	InitDefaultBaudrateSelection();
	InitDefaultPortSettings();
}

CGatewayNItoNiCanLib::~CGatewayNItoNiCanLib()
{
	
}

BOOL CGatewayNItoNiCanLib::InitDefaultBaudrateSelection()
{
	m_BaudrateSelection.clear();
	m_BaudrateSelection.push_back(1000000);
	m_BaudrateSelection.push_back(800000);
	m_BaudrateSelection.push_back(500000);
	m_BaudrateSelection.push_back(250000);
	m_BaudrateSelection.push_back(125000);
	m_BaudrateSelection.push_back(50000);

	return TRUE;
}

BOOL CGatewayNItoNiCanLib::InitHighSpeedBaudrateSelection()
{
	m_BaudrateSelection.clear();
	m_BaudrateSelection.push_back(1000000);
	m_BaudrateSelection.push_back(800000);
	m_BaudrateSelection.push_back(500000);
	m_BaudrateSelection.push_back(250000);
	m_BaudrateSelection.push_back(125000);
	m_BaudrateSelection.push_back(50000);

	return TRUE;
}

BOOL CGatewayNItoNiCanLib::InitLowSpeedBaudrateSelection()
{
	m_BaudrateSelection.clear();
	m_BaudrateSelection.push_back(125000);
	m_BaudrateSelection.push_back(50000);
	m_BaudrateSelection.push_back(20000);

	return TRUE;
}

BOOL CGatewayNItoNiCanLib::InitSingleWireBaudrateSelection()
{
	m_BaudrateSelection.clear();
	m_BaudrateSelection.push_back(50000);
	m_BaudrateSelection.push_back(20000);

	return TRUE;
}

BOOL CGatewayNItoNiCanLib::InitDefaultPortSettings()
{
	if(m_BaudrateSelection.size() > 0)
		m_dDefaultBaudrate = m_BaudrateSelection.at(0);
	else
		m_dDefaultBaudrate = 1000000;

	m_dDefaultTimeout = 500;

	GetDefaultPortSettings(&m_dBaudrate,&m_dTimeout);

	return TRUE;
}

BOOL CGatewayNItoNiCanLib::IsPortNameSupported(CStdString strPortName)
{
	CStdString strName;

	for(std::size_t i=0;i<m_strPortArray.size();i++)
	{
		strName = m_strPortArray.at(i);
		if(strName.CompareNoCase(strPortName) == 0)
		{
			return TRUE;
		}
	}

	return FALSE;
}

BOOL CGatewayNItoNiCanLib::ProcessCommand(CCommandRoot* pCommand,CLayerManagerBase* pManager,HANDLE h_Handle,HANDLE hTransactionHandle)
{
	CCommand_I* pCommand_I;

	if(CGateway::ProcessCommand(pCommand, pManager, h_Handle, hTransactionHandle))
	{
		if(CheckLayers(pCommand,pManager))
		{
			pCommand_I = (CCommand_I*)pCommand;

			switch(pCommand->GetCommandId())
			{
				case CAN_TRANSMIT_CAN_FRAME: return Process_TransmitCanFrame(pCommand_I);
				case CAN_RECEIVE_CAN_FRAME: return Process_ReceiveCanFrame(pCommand_I);
				case CAN_RECEIVE_FILTERED_CAN_FRAME: return Process_ReceiveFilteredCanFrame(pCommand_I);
				case CAN_TRANSMIT_CAN_FRAME_EX: return Process_TransmitCanFrameEx(pCommand_I);
				case CAN_RECEIVE_CAN_FRAME_EX: return Process_ReceiveCanFrameEx(pCommand_I);
				case CAN_RECEIVE_FILTERED_CAN_FRAME_EX: return Process_ReceiveFilteredCanFrameEx(pCommand_I);
			}
		}
	}

	return FALSE;
}

BOOL CGatewayNItoNiCanLib::Process_TransmitCanFrame(CCommand_I* pCommand)
{
	//*Constants I*
	const int k_ParameterIndex_CobId = 0;
	const int k_ParameterIndex_Rtr = 1;
	const int k_ParameterIndex_Dlc = 2;
	const int k_ParameterIndex_Data = 3;
	BOOL oResult = FALSE;
	//*Variables I*
	//Parameter
	DWORD dCobId;
	BYTE oRtr;
	BYTE uDlc;
	void* pDataBuffer = NULL;
	DWORD dDataBufferLength;
	CErrorInfo errorInfo;
	BOOL oExtCobId(FALSE);

	if(pCommand)
	{
		//Lock CriticalSection
		if(!Lock(pCommand->GetTimeout())) return FALSE;

		//Prepare DataBuffer
		dDataBufferLength = pCommand->GetParameterLength(k_ParameterIndex_Data);
		if(dDataBufferLength > 0) pDataBuffer = malloc(dDataBufferLength);

		//Get I Parameter Data
		pCommand->GetParameterData(k_ParameterIndex_CobId,&dCobId,sizeof(dCobId));
		pCommand->GetParameterData(k_ParameterIndex_Rtr,&oRtr,sizeof(oRtr));
		pCommand->GetParameterData(k_ParameterIndex_Dlc,&uDlc,sizeof(uDlc));
		pCommand->GetParameterData(k_ParameterIndex_Data,pDataBuffer,dDataBufferLength);

		//Execute Command
		oResult = TransmitCanFrame(oExtCobId, dCobId,oRtr,uDlc,pDataBuffer,dDataBufferLength,&errorInfo);

		//Set PS ReturnParameter Data
		pCommand->SetStatus(oResult,&errorInfo);

		//Free DataBuffer
		if(pDataBuffer) free(pDataBuffer);

		//Unlock CriticalSection
		Unlock();
	}

	return oResult;
}

BOOL CGatewayNItoNiCanLib::Process_ReceiveCanFrame(CCommand_I* pCommand)
{
	//*Constants I*
	const int k_ReturnParameterIndex_CobId = 0;
	const int k_ReturnParameterIndex_Rtr = 1;
	const int k_ReturnParameterIndex_Dlc = 2;
	const int k_ReturnParameterIndex_Data = 3;

	//*Variables I*
	//Parameter
	DWORD dTimeout;
	//ReturnParamter
	DWORD dCobId;
	BOOL oRtr;
	BYTE uDlc;
	void* pDataBuffer = NULL;
	DWORD dDataBufferLength;
	BOOL oExtCobId(FALSE);
	BOOL oResult = FALSE;
	CErrorInfo errorInfo;

	if(pCommand)
	{
		//Lock CriticalSection
		if(!Lock(pCommand->GetTimeout())) return FALSE;

		//Get I Parameter Data
		if(pCommand->IsTimeoutValid()) dTimeout = pCommand->GetTimeout(); else dTimeout = m_dTimeout;

		//Execute Command
		oResult = ReceiveCanFrame(oExtCobId, dTimeout,&dCobId,&oRtr,&uDlc,&pDataBuffer,&dDataBufferLength,&errorInfo);

		//Set I ReturnParameter Data
		pCommand->SetStatus(oResult,&errorInfo);
		pCommand->SetReturnParameterData(k_ReturnParameterIndex_CobId,&dCobId,sizeof(dCobId));
		pCommand->SetReturnParameterData(k_ReturnParameterIndex_Rtr,&oRtr,sizeof(oRtr));
		pCommand->SetReturnParameterData(k_ReturnParameterIndex_Dlc,&uDlc,sizeof(uDlc));
		pCommand->SetReturnParameterData(k_ReturnParameterIndex_Data,pDataBuffer,dDataBufferLength);

		//Free DataBuffer
		if(pDataBuffer) free(pDataBuffer);

		//Unlock CriticalSection
		Unlock();
	}

	return oResult;
}

BOOL CGatewayNItoNiCanLib::Process_ReceiveFilteredCanFrame(CCommand_I* pCommand)
{
	//*Constants I*
	const int k_ParameterIndex_CobId = 0;
	const int k_ParameterIndex_Rtr = 1;

	const int k_ReturnParameterIndex_CobId = 0;
	const int k_ReturnParameterIndex_Rtr = 1;
	const int k_ReturnParameterIndex_Dlc = 2;
	const int k_ReturnParameterIndex_Data = 3;
	BOOL oResult = FALSE;

	//*Variables I*
	//Parameter
	DWORD dCobIdFilter;
	BYTE oRtrFilter;
	DWORD dTimeout;

	//ReturnParamter
	DWORD dCobId;
	BOOL oRtr;
	BYTE uDlc;
	void* pDataBuffer = NULL;
	DWORD dDataBufferLength;
	CErrorInfo errorInfo;
	BOOL oExtCobId(FALSE);

	if(pCommand)
	{
		
		//Lock CriticalSection
		if(!Lock(pCommand->GetTimeout())) return FALSE;

		//Get I Parameter Data
		pCommand->GetParameterData(k_ParameterIndex_CobId,&dCobIdFilter,sizeof(dCobIdFilter));
		pCommand->GetParameterData(k_ParameterIndex_Rtr,&oRtrFilter,sizeof(oRtrFilter));
		if(pCommand->IsTimeoutValid()) dTimeout = pCommand->GetTimeout(); else dTimeout = m_dTimeout;

		//Execute Command
		oResult = ReceiveFilteredCanFrame(oExtCobId,dCobIdFilter,oRtrFilter,dTimeout,&dCobId,&oRtr,&uDlc,&pDataBuffer,&dDataBufferLength,&errorInfo);

		//Set I ReturnParameter Data
		pCommand->SetStatus(oResult,&errorInfo);
		pCommand->SetReturnParameterData(k_ReturnParameterIndex_CobId,&dCobIdFilter,sizeof(dCobIdFilter));
		pCommand->SetReturnParameterData(k_ReturnParameterIndex_Rtr,&oRtrFilter,sizeof(oRtrFilter));
		pCommand->SetReturnParameterData(k_ReturnParameterIndex_Dlc,&uDlc,sizeof(uDlc));
		pCommand->SetReturnParameterData(k_ReturnParameterIndex_Data,pDataBuffer,dDataBufferLength);

		//Free DataBuffer
		if(pDataBuffer) free(pDataBuffer);

		//Unlock CriticalSection
		Unlock();
	}

	return oResult;
}

BOOL CGatewayNItoNiCanLib::Process_TransmitCanFrameEx(CCommand_I* pCommand)
{
	//*Constants I*
	const int k_ParameterIndex_CobId = 0;
	const int k_ParameterIndex_Rtr = 1;
	const int k_ParameterIndex_Dlc = 2;
	const int k_ParameterIndex_Data = 3;

	//*Variables I*
	//Parameter
	BOOL oExtCobId(TRUE);
	DWORD dCobId;
	BYTE oRtr;
	BYTE uDlc;
	void* pDataBuffer = NULL;
	DWORD dDataBufferLength;

	BOOL oResult = FALSE;
	CErrorInfo errorInfo;

	if(pCommand)
	{
		//Lock CriticalSection
		if(!Lock(pCommand->GetTimeout())) return FALSE;

		//Prepare DataBuffer
		dDataBufferLength = pCommand->GetParameterLength(k_ParameterIndex_Data);
		if(dDataBufferLength > 0) pDataBuffer = malloc(dDataBufferLength);

		//Get I Parameter Data
		pCommand->GetParameterData(k_ParameterIndex_CobId,&dCobId,sizeof(dCobId));
		pCommand->GetParameterData(k_ParameterIndex_Rtr,&oRtr,sizeof(oRtr));
		pCommand->GetParameterData(k_ParameterIndex_Dlc,&uDlc,sizeof(uDlc));
		pCommand->GetParameterData(k_ParameterIndex_Data,pDataBuffer,dDataBufferLength);

		//Execute Command
		oResult = TransmitCanFrame(oExtCobId, dCobId,oRtr,uDlc,pDataBuffer,dDataBufferLength,&errorInfo);

		//Set PS ReturnParameter Data
		pCommand->SetStatus(oResult,&errorInfo);

		//Free DataBuffer
		if(pDataBuffer) free(pDataBuffer);

		//Unlock CriticalSection
		Unlock();
	}

	return oResult;
}

BOOL CGatewayNItoNiCanLib::Process_ReceiveCanFrameEx(CCommand_I* pCommand)
{
	//*Constants I*
	const int k_ReturnParameterIndex_CobId = 0;
	const int k_ReturnParameterIndex_Rtr = 1;
	const int k_ReturnParameterIndex_Dlc = 2;
	const int k_ReturnParameterIndex_Data = 3;

	//*Variables I*
	//Parameter
	BOOL oExtCobId(TRUE);
	DWORD dTimeout;
	//ReturnParamter
	DWORD dCobId;
	BOOL oRtr;
	BYTE uDlc;
	void* pDataBuffer = NULL;
	DWORD dDataBufferLength;

	BOOL oResult = FALSE;
	CErrorInfo errorInfo;

	if(pCommand)
	{
		//Lock CriticalSection
		if(!Lock(pCommand->GetTimeout())) return FALSE;

		//Get I Parameter Data
		if(pCommand->IsTimeoutValid()) dTimeout = pCommand->GetTimeout(); else dTimeout = m_dTimeout;

		//Execute Command
		oResult = ReceiveCanFrame(oExtCobId, dTimeout,&dCobId,&oRtr,&uDlc,&pDataBuffer,&dDataBufferLength,&errorInfo);

		//Set I ReturnParameter Data
		pCommand->SetStatus(oResult,&errorInfo);
		pCommand->SetReturnParameterData(k_ReturnParameterIndex_CobId,&dCobId,sizeof(dCobId));
		pCommand->SetReturnParameterData(k_ReturnParameterIndex_Rtr,&oRtr,sizeof(oRtr));
		pCommand->SetReturnParameterData(k_ReturnParameterIndex_Dlc,&uDlc,sizeof(uDlc));
		pCommand->SetReturnParameterData(k_ReturnParameterIndex_Data,pDataBuffer,dDataBufferLength);

		//Free DataBuffer
		if(pDataBuffer) free(pDataBuffer);

		//Unlock CriticalSection
		Unlock();
	}

	return oResult;
}

BOOL CGatewayNItoNiCanLib::Process_ReceiveFilteredCanFrameEx(CCommand_I* pCommand)
{
	//*Constants I*
	const int k_ParameterIndex_CobId = 0;
	const int k_ParameterIndex_Rtr = 1;

	const int k_ReturnParameterIndex_CobId = 0;
	const int k_ReturnParameterIndex_Rtr = 1;
	const int k_ReturnParameterIndex_Dlc = 2;
	const int k_ReturnParameterIndex_Data = 3;

	//*Variables I*
	//Parameter
	BOOL oExtCobId(TRUE);
	DWORD dCobIdFilter;
	BYTE oRtrFilter;
	DWORD dTimeout;

	//ReturnParamter
	DWORD dCobId;
	BOOL oRtr;
	BYTE uDlc;
	void* pDataBuffer = NULL;
	DWORD dDataBufferLength;

	BOOL oResult = FALSE;
	CErrorInfo errorInfo;

	if(pCommand)
	{
		
		//Lock CriticalSection
		if(!Lock(pCommand->GetTimeout())) return FALSE;

		//Get I Parameter Data
		pCommand->GetParameterData(k_ParameterIndex_CobId,&dCobIdFilter,sizeof(dCobIdFilter));
		pCommand->GetParameterData(k_ParameterIndex_Rtr,&oRtrFilter,sizeof(oRtrFilter));
		if(pCommand->IsTimeoutValid()) dTimeout = pCommand->GetTimeout(); else dTimeout = m_dTimeout;

		//Execute Command
		oResult = ReceiveFilteredCanFrame(oExtCobId, dCobIdFilter,oRtrFilter,dTimeout,&dCobId,&oRtr,&uDlc,&pDataBuffer,&dDataBufferLength,&errorInfo);

		//Set I ReturnParameter Data
		pCommand->SetStatus(oResult,&errorInfo);
		pCommand->SetReturnParameterData(k_ReturnParameterIndex_CobId,&dCobIdFilter,sizeof(dCobIdFilter));
		pCommand->SetReturnParameterData(k_ReturnParameterIndex_Rtr,&oRtrFilter,sizeof(oRtrFilter));
		pCommand->SetReturnParameterData(k_ReturnParameterIndex_Dlc,&uDlc,sizeof(uDlc));
		pCommand->SetReturnParameterData(k_ReturnParameterIndex_Data,pDataBuffer,dDataBufferLength);

		//Free DataBuffer
		if(pDataBuffer) free(pDataBuffer);

		//Unlock CriticalSection
		Unlock();
	}

	return oResult;
}

BOOL CGatewayNItoNiCanLib::TransmitCanFrame(BOOL oExtCobId, DWORD dCobId,BOOL oRtr,BYTE uDlc,void* pDataBuffer,DWORD dDataBufferLength,CErrorInfo* pErrorInfo)
{
	//ResetErrorInfo
	if(pErrorInfo) pErrorInfo->Reset();

	if( !m_NiHndl.TransmitCanFrame(oExtCobId, dCobId, oRtr,uDlc, pDataBuffer,dDataBufferLength) )
	{
		if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_ExecutingCommand,pErrorInfo);
		return false;
	}
		
	return true;
}

BOOL CGatewayNItoNiCanLib::ReceiveCanFrame(BOOL oExtCobId, DWORD dTimeout,DWORD* pdCobId,BOOL* poRtr,BYTE* puDlc,void** ppDataBuffer,DWORD* pdDataBufferLength,CErrorInfo* pErrorInfo)
{
	//ResetErrorInfo
	if(pErrorInfo) pErrorInfo->Reset();

	if( !m_NiHndl.ReceiveCanFrame(oExtCobId, dTimeout,pdCobId,poRtr,puDlc,ppDataBuffer,pdDataBufferLength) )
	{
		if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_ExecutingCommand,pErrorInfo);
		return false;
	}
	
	return true;
}

BOOL CGatewayNItoNiCanLib::ReceiveFilteredCanFrame(BOOL oExtCobId, DWORD dCobIdFilter,BOOL oRtrFilter,DWORD dTimeout,DWORD* pdCobId,BOOL* poRtr,BYTE* puDlc,void** ppDataBuffer,DWORD* pdDataBufferLength,CErrorInfo* pErrorInfo)
{

	//ResetErrorInfo
	if(pErrorInfo) pErrorInfo->Reset();

	if( !m_NiHndl.ReceiveFilteredCanFrame(oExtCobId, dCobIdFilter,oRtrFilter,dTimeout,pdCobId,poRtr,puDlc,ppDataBuffer,pdDataBufferLength) )
	{
		if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_ExecutingCommand,pErrorInfo);
		return false;
	}
	
	return true;
}

CGateway* CGatewayNItoNiCanLib::Clone()
{
	CGatewayNItoNiCanLib* pClonedGateway;

	pClonedGateway = new CGatewayNItoNiCanLib();
	*pClonedGateway = *this;

	return pClonedGateway;
}

CGatewayNItoNiCanLib& CGatewayNItoNiCanLib::operator=(CGatewayNItoNiCanLib& other)
{
	if(this != &other)
	{
		*((CGatewayIToDrv*)this) = *((CGatewayIToDrv*)&other);

	}

	return *this;
}

//********************************************************************
BOOL CGatewayNItoNiCanLib::OpenPort(CStdString strPortName,CErrorInfo* pErrorInfo)
{
	return m_NiHndl.OpenPort(strPortName) ? TRUE : FALSE;
}

//********************************************************************
BOOL CGatewayNItoNiCanLib::ClosePort(CErrorInfo* pErrorInfo)
{
	return m_NiHndl.ClosePort() ? TRUE : FALSE;
}

//********************************************************************
BOOL CGatewayNItoNiCanLib::ResetPort(CErrorInfo* pErrorInfo)
{
	return m_NiHndl.ResetPort() ? TRUE : FALSE;
}

//********************************************************************
BOOL CGatewayNItoNiCanLib::GetPortSettings(DWORD* pdBaudrate,DWORD* pdTimeout,CErrorInfo* pErrorInfo)
{
	if(pdBaudrate) *pdBaudrate = m_dBaudrate;
	if(pdTimeout) *pdTimeout = m_dTimeout;

	return TRUE;
}

//********************************************************************
BOOL CGatewayNItoNiCanLib::SetPortSettings(DWORD dBaudrate,DWORD dTimeout,BOOL oChangeOnly,CErrorInfo* pErrorInfo)
{
	// Init Timing-Register (Set CAN baudrate)
	if( !IsBaudrateSupported(dBaudrate) )
		return false;

	if( !m_NiHndl.SetPortSettings(dBaudrate,dTimeout) )
	{
		if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_I_SetPortSettings,pErrorInfo);

		return false;
	}
	
	return true;
}

//********************************************************************
BOOL CGatewayNItoNiCanLib::GetPortMode(WORD* pwPortMode,CErrorInfo* pErrorInfo)
{
	if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal,pErrorInfo);
	return FALSE;
}

//********************************************************************
BOOL CGatewayNItoNiCanLib::SetPortMode(WORD wPortMode,CErrorInfo* pErrorInfo)
{
	if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal,pErrorInfo);
	return FALSE;
}

//********************************************************************
BOOL CGatewayNItoNiCanLib::InitPort(WORD wBoardNumber,WORD wNbBoardWithOldDriver)
{
	std::vector<CStdString> portList = m_NiHndl.InitPort(wBoardNumber);

	for( std::vector<CStdString>::iterator it=portList.begin(); it!=portList.end(); it++ )
		AddPortList(*it);

	return portList.size()>0;
}

BOOL CGatewayNItoNiCanLib::InitInterfaceName(CStdString* pStrInterfaceName,WORD wBoardNumber,WORD wNbBoardWithOldDriver)
{
	CStdString strInterfacePortName;

	if(InitInterfacePortName(&strInterfacePortName,wBoardNumber,wNbBoardWithOldDriver))
	{
		m_strInterfaceName = strInterfacePortName;
		if(pStrInterfaceName) *pStrInterfaceName = m_strInterfaceName;
		return TRUE;
	}

	return FALSE;
}

//********************************************************************
BOOL CGatewayNItoNiCanLib::InitInterfacePortName(CStdString* pStrInterfacePortName,WORD wBoardNumber,WORD wNbBoardWithOldDriver)
{
	if( m_NiHndl.InitInterface(wBoardNumber) )
	{
		CStdString strFormFactor = m_NiHndl.GetFormFactor();
		CStdString strTransceiverType = m_NiHndl.GetTransceiverType();

		if( strTransceiverType.IsEmpty() )
			InitHighSpeedBaudrateSelection();
		else if(strTransceiverType == "LS") 
			InitLowSpeedBaudrateSelection();
		else if(strTransceiverType == "SW") 
			InitSingleWireBaudrateSelection();
		else if(strTransceiverType == "XS") 
			InitHighSpeedBaudrateSelection();
		else
			InitDefaultBaudrateSelection();

		InitDefaultPortSettings();

		//Card Index
		CStdString strIndex,strInterfacePortName;
		strIndex.Format(" %i",wBoardNumber);

		//Format InterfaceName
		strInterfacePortName = "NI_";
		strInterfacePortName += strFormFactor;
		strInterfacePortName += strIndex;

		m_strInterfacePortName = strInterfacePortName;

		if(pStrInterfacePortName) *pStrInterfacePortName = strInterfacePortName;

		return true;
	}

	return false;
}

//********************************************************************
BOOL CGatewayNItoNiCanLib::InitErrorHandling()
{
	CErrorProducer errorProducer;
	CStdString strClassName = "GatewayNItoNiCanLib";

	if(m_pErrorHandling)
	{
		//Init ErrorProducer
		errorProducer.Init(INTERFACE_LAYER,strClassName);
		m_pErrorHandling->InitErrorProducer(&errorProducer);
		return TRUE;
	}

	return FALSE;
}

WORD CGatewayNItoNiCanLib::GetNbOfAvailableBoards()
{
	return m_NiHndl.GetNbOfAvailableBoards();
}

BOOL CGatewayNItoNiCanLib::IsBaudrateSupported(DWORD dBaudrate)
{
	DWORD dListBaudrate;

	for(std::size_t i=0;i<m_BaudrateSelection.size();i++)
	{
		dListBaudrate = m_BaudrateSelection.at(i);
		if(dListBaudrate == dBaudrate) return TRUE;
	}

	return FALSE;
}
#endif //_MMC_I_NI
