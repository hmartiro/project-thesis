// Command_I_CAN.cpp: Implementierung der Klasse CCommand_I_CAN.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Command_I_CAN.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
/////////////////////////0/////////////////////////////////////////////
CCommand_I_CAN::CCommand_I_CAN()
{
}

CCommand_I_CAN::CCommand_I_CAN(DWORD dCommandId)
{
	InitCommand(dCommandId);
}

CCommand_I_CAN::~CCommand_I_CAN()
{
}

//******************************************************************
CCommandRoot* CCommand_I_CAN::CloneCommand()
{
	CCommand_I_CAN* pNewCommand;

	pNewCommand = new CCommand_I_CAN();
	*pNewCommand = *this;

	return pNewCommand;
}

//******************************************************************
CCommand_I_CAN& CCommand_I_CAN::operator=(CCommand_I_CAN& other)
{
	if(this != &other)
	{
		*((CCommandRoot*)this) = *((CCommandRoot*)&other);
	}

	return *this;
}

//******************************************************************
BOOL CCommand_I_CAN::InitCommand(DWORD dCommandId)
{
	const DWORD k_Data_ArraySize = 8;

	ResetCommand();
	switch(dCommandId)
	{
		case CAN_TRANSMIT_CAN_FRAME:
			{
				CCommand_I::InitCommand("Transmit CAN-Frame",CAN_TRANSMIT_CAN_FRAME);
				AddParameter(0,"cobId",ODT_UINT32);
				AddParameter(1,"rtr",ODT_BOOLEAN);
				AddParameter(2,"dlc",ODT_UINT8);
				AddParameter(3,"data",ODT_UINT8,k_Data_ArraySize);
				SetDefaultParameter_TransmitCanFrame();
				return TRUE;
			};
		case CAN_RECEIVE_CAN_FRAME:
			{
				CCommand_I::InitCommand("Receive CAN-Frame",CAN_RECEIVE_CAN_FRAME);
				AddReturnParameter(0,"cobId",ODT_UINT32);
				AddReturnParameter(1,"rtr",ODT_BOOLEAN);
				AddReturnParameter(2,"dlc",ODT_UINT8);
				AddReturnParameter(3,"data",ODT_UINT8,k_Data_ArraySize);
				SetDefaultParameter_ReceiveCanFrame();
				return TRUE;
			};
		case CAN_RECEIVE_FILTERED_CAN_FRAME:
			{
				CCommand_I::InitCommand("Receive CAN-Frame",CAN_RECEIVE_FILTERED_CAN_FRAME);
				AddParameter(0,"cobIdFilter",ODT_UINT32,FALSE,TRUE);
				AddParameter(1,"rtrFilter",ODT_BOOLEAN,FALSE,TRUE);
				AddReturnParameter(0,"cobId",ODT_UINT32);
				AddReturnParameter(1,"rtr",ODT_BOOLEAN);
				AddReturnParameter(2,"dlc",ODT_UINT8);
				AddReturnParameter(3,"data",ODT_UINT8,k_Data_ArraySize);
				SetDefaultParameter_ReceiveFilteredCanFrame();
				return TRUE;
			};

		case CAN_TRANSMIT_CAN_FRAME_EX:
			{
				CCommand_I::InitCommand("Transmit CAN-FrameEx",CAN_TRANSMIT_CAN_FRAME_EX);
				AddParameter(0,"cobId",ODT_UINT32);
				AddParameter(1,"rtr",ODT_BOOLEAN);
				AddParameter(2,"dlc",ODT_UINT8);
				AddParameter(3,"data",ODT_UINT8,k_Data_ArraySize);
				SetDefaultParameter_TransmitCanFrame();
				return TRUE;
			};
		case CAN_RECEIVE_CAN_FRAME_EX:
			{
				CCommand_I::InitCommand("Receive CAN-FrameEx",CAN_RECEIVE_CAN_FRAME_EX);
				AddReturnParameter(0,"cobId",ODT_UINT32);
				AddReturnParameter(1,"rtr",ODT_BOOLEAN);
				AddReturnParameter(2,"dlc",ODT_UINT8);
				AddReturnParameter(3,"data",ODT_UINT8,k_Data_ArraySize);
				SetDefaultParameter_ReceiveCanFrame();
				return TRUE;
			};
		case CAN_RECEIVE_FILTERED_CAN_FRAME_EX:
			{
				CCommand_I::InitCommand("Receive CAN-FrameEx",CAN_RECEIVE_FILTERED_CAN_FRAME_EX);
				AddParameter(0,"cobIdFilter",ODT_UINT32,FALSE,TRUE);
				AddParameter(1,"rtrFilter",ODT_BOOLEAN,FALSE,TRUE);
				AddReturnParameter(0,"cobId",ODT_UINT32);
				AddReturnParameter(1,"rtr",ODT_BOOLEAN);
				AddReturnParameter(2,"dlc",ODT_UINT8);
				AddReturnParameter(3,"data",ODT_UINT8,k_Data_ArraySize);
				SetDefaultParameter_ReceiveFilteredCanFrame();
				return TRUE;
			};
	}

	return FALSE;
}

//**************************************************************************
void CCommand_I_CAN::SetDefaultParameter_TransmitCanFrame()
{
	DWORD dCobId = 0;
	BOOL oRtr = 0;
	BYTE uDlc = 0;
	void* pData = NULL;

	//Parameter
	SetParameterData(0,&dCobId,sizeof(dCobId));
	SetParameterData(1,&oRtr,sizeof(oRtr));
	SetParameterData(2,&uDlc,sizeof(uDlc));
	SetParameterData(3,pData,0);
}

//**************************************************************************
void CCommand_I_CAN::SetDefaultParameter_ReceiveFilteredCanFrame()
{
	DWORD dCobId = 0;
	BOOL oRtr = 0;
	BYTE uDlc = 0;
	void* pData = NULL;

	//Parameter
	SetParameterData(0,&dCobId,sizeof(dCobId));
	SetParameterData(1,&oRtr,sizeof(oRtr));

	//ReturnParameter
	SetReturnParameterData(0,&dCobId,sizeof(dCobId));
	SetReturnParameterData(1,&oRtr,sizeof(oRtr));
	SetReturnParameterData(2,&uDlc,sizeof(uDlc));
	SetReturnParameterData(3,pData,0);
}

//**************************************************************************
void CCommand_I_CAN::SetDefaultParameter_ReceiveCanFrame()
{
	DWORD dCobId = 0;
	BOOL oRtr = 0;
	BYTE uDlc = 0;
	void* pData = NULL;

	//ReturnParameter
	SetReturnParameterData(0,&dCobId,sizeof(dCobId));
	SetReturnParameterData(1,&oRtr,sizeof(oRtr));
	SetReturnParameterData(2,&uDlc,sizeof(uDlc));
	SetReturnParameterData(3,pData,0);
}
