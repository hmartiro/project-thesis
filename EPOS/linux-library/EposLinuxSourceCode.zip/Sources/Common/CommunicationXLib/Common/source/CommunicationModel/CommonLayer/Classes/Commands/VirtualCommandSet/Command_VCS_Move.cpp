// Command_VCS_Move.cpp: Implementierung der Klasse CCommand_VCS_Move.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <CommunicationModel/CommonLayer/Classes/Commands/VirtualCommandSet/Command_VCS_Move.h>
#ifdef _MMC_VCS_MOVE
#include <CommunicationModel/CommonLayer/Classes/Commands/VirtualCommandSet/Command_VCS_InputsOutputs.h>
//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
/////////////////////////0////////////////////////////////////////////

CCommand_VCS_Move::CCommand_VCS_Move()
{
}

CCommand_VCS_Move::CCommand_VCS_Move(DWORD p_ulCommandId)
{
    InitCommand(p_ulCommandId);
}

CCommand_VCS_Move::~CCommand_VCS_Move()
{
}

CCommandRoot*CCommand_VCS_Move::CloneCommand()
{
    CCommand_VCS_Move* pNewCommand;

    pNewCommand = new CCommand_VCS_Move();
    *pNewCommand = *this;

    return pNewCommand;
}

CCommand_VCS_Move& CCommand_VCS_Move::operator=(CCommand_VCS_Move& other)
{
    if(this != &other)
    {
        *((CCommandRoot*)this) = *((CCommandRoot*)&other);
    }

    return *this;
}

BOOL CCommand_VCS_Move::InitCommand(DWORD p_ulCommandId)
{
    ResetCommand();

    if(InitCommand_Configuration(p_ulCommandId)) return 1;
    if(InitCommand_ConfigurationMotor(p_ulCommandId)) return 1;
    if(InitCommand_ConfigurationSensor(p_ulCommandId)) return 1;
    if(InitCommand_CurrentMode(p_ulCommandId)) return 1;
    if(InitCommand_InputsOutputs(p_ulCommandId)) return 1;
    if(InitCommand_MotionInfo(p_ulCommandId)) return 1;
    if(InitCommand_PositionMode(p_ulCommandId)) return 1;
    if(InitCommand_StateMachine(p_ulCommandId)) return 1;
    if(InitCommand_VelocityMode(p_ulCommandId)) return 1;
    if(InitCommand_FirmwareDownload(p_ulCommandId)) return 1;

    return 0;
}

BOOL CCommand_VCS_Move::InitCommand_Configuration(DWORD p_ulCommandId)
{
    switch(p_ulCommandId)
    {
        case MOVE_GET_CURRENT_REGULATOR_GAIN:
            {
                CCommand_VCS::InitCommand("GetCurrentRegulatorGain", MOVE_GET_CURRENT_REGULATOR_GAIN);
                AddReturnParameter(0, "P", ODT_UINT16);
                AddReturnParameter(1, "I", ODT_UINT16);
                SetDefaultParameter_GetCurrentRegulatorGain();
                return 1;
            };
        case MOVE_GET_SPEED_REGULATOR_GAIN:
            {
                CCommand_VCS::InitCommand("GetVelocityRegulatorGain", MOVE_GET_SPEED_REGULATOR_GAIN);
                AddReturnParameter(0, "P", ODT_UINT16);
                AddReturnParameter(1, "I", ODT_UINT16);
                SetDefaultParameter_GetVelocityRegulatorGain();
                return 1;
            };
        case MOVE_GET_MAX_FOLLOWING_ERROR:
            {
                CCommand_VCS::InitCommand("GetMaxFollowingError", MOVE_GET_MAX_FOLLOWING_ERROR);
                AddReturnParameter(0, "MaxFollowingError", ODT_UINT32);
                SetDefaultParameter_GetMaxFollowingError();
                return 1;
            };
        case MOVE_GET_MAX_PROFILE_VELOCITY:
            {
                CCommand_VCS::InitCommand("GetMaxProfileVelocity", MOVE_GET_MAX_PROFILE_VELOCITY);
                AddReturnParameter(0, "MaxProfileVelocity", ODT_UINT32);
                SetDefaultParameter_GetMaxProfileVelocity();
                return 1;
            };
        case MOVE_GET_MAX_ACCELERATION:
            {
                CCommand_VCS::InitCommand("GetMaxAcceleration", MOVE_GET_MAX_ACCELERATION);
                AddReturnParameter(0, "MaxAcceleration", ODT_UINT32);
                SetDefaultParameter_GetMaxAcceleration();
                return 1;
            };
        case MOVE_GET_VELOCITY_UNITS:
            {
                CCommand_VCS::InitCommand("GetVelocityUnits", MOVE_GET_VELOCITY_UNITS);
                AddReturnParameter(0, "velocityDimension", ODT_UINT8);
                AddReturnParameter(1, "velocityNotation", ODT_UINT8);
                SetDefaultParameter_GetVelocityUnits();
                return 1;
            };
        case MOVE_SET_CURRENT_REGULATOR_GAIN:
            {
                CCommand_VCS::InitCommand("SetCurrentRegulatorGain", MOVE_SET_CURRENT_REGULATOR_GAIN);
                AddParameter(0, "P", ODT_UINT16);
                AddParameter(1, "I", ODT_UINT16);
                SetDefaultParameter_SetCurrentRegulatorGain();
                return 1;
            };
        case MOVE_SET_SPEED_REGULATOR_GAIN:
            {
                CCommand_VCS::InitCommand("SetVelocityRegulatorGain", MOVE_SET_SPEED_REGULATOR_GAIN);
                AddParameter(0, "P", ODT_UINT16);
                AddParameter(1, "I", ODT_UINT16);
                SetDefaultParameter_SetVelocityRegulatorGain();
                return 1;
            };
        case MOVE_SET_MAX_FOLLOWING_ERROR:
            {
                CCommand_VCS::InitCommand("SetMaxFollowingError", MOVE_SET_MAX_FOLLOWING_ERROR);
                AddParameter(0, "MaxFollowingError", ODT_UINT32);
                SetDefaultParameter_SetMaxFollowingError();
                return 1;
            };
        case MOVE_SET_MAX_PROFILE_VELOCITY:
            {
                CCommand_VCS::InitCommand("SetMaxProfileVelocity", MOVE_SET_MAX_PROFILE_VELOCITY);
                AddParameter(0, "MaxProfileVelocity", ODT_UINT32);
                SetDefaultParameter_SetMaxProfileVelocity();
                return 1;
            };
        case MOVE_SET_MAX_ACCELERATION:
            {
                CCommand_VCS::InitCommand("SetMaxAcceleration", MOVE_SET_MAX_ACCELERATION);
                AddParameter(0, "MaxAcceleration", ODT_UINT32);
                SetDefaultParameter_SetMaxAcceleration();
                return 1;
            };
        case MOVE_SET_VELOCITY_UNITS:
            {
                CCommand_VCS::InitCommand("SetVelocityUnits", MOVE_SET_VELOCITY_UNITS);
                AddParameter(0, "velocityDimensionIndex", ODT_UINT8);
                AddParameter(1, "velocityNotationIndex", ODT_INT8);
                SetDefaultParameter_SetVelocityUnits();
                return 1;
            };
    }

    return 0;
}

BOOL CCommand_VCS_Move::InitCommand_ConfigurationMotor(DWORD p_ulCommandId)
{
    switch(p_ulCommandId)
    {
        case MOVE_GET_MOTOR_PARAMETER:
            {
                CCommand_VCS::InitCommand("GetMotorParameter", MOVE_GET_MOTOR_PARAMETER);
                AddReturnParameter(0, "motorType", ODT_UINT16);
                AddReturnParameter(1, "continuousCurrent", ODT_UINT16);
                AddReturnParameter(2, "peakCurrent", ODT_UINT16);
                AddReturnParameter(3, "polePair", ODT_UINT8);
                AddReturnParameter(4, "thermalTimeConstant", ODT_UINT16);
                SetDefaultParameter_GetMotorParameter();
                return 1;
            };
        case MOVE_GET_MOTOR_TYPE:
            {
                CCommand_VCS::InitCommand("GetMotorType", MOVE_GET_MOTOR_TYPE);
                AddReturnParameter(0, "motorType", ODT_UINT16);
                SetDefaultParameter_GetMotorType();
                return 1;
            };
        case MOVE_GET_DC_MOTOR_PARAMETER:
            {
                CCommand_VCS::InitCommand("GetDcMotorParameter", MOVE_GET_DC_MOTOR_PARAMETER);
                AddReturnParameter(0, "nominalCurrent", ODT_UINT16);
                AddReturnParameter(1, "maxOutputCurrent", ODT_UINT16);
                AddReturnParameter(2, "thermalTimeConstant", ODT_UINT16);
                SetDefaultParameter_GetDcMotorParameter();
                return 1;
            };
        case MOVE_GET_EC_MOTOR_PARAMETER:
            {
                CCommand_VCS::InitCommand("GetEcMotorParameter", MOVE_GET_EC_MOTOR_PARAMETER);
                AddReturnParameter(0, "nominalCurrent", ODT_UINT16);
                AddReturnParameter(1, "maxOutputCurrent", ODT_UINT16);
                AddReturnParameter(2, "thermalTimeConstant", ODT_UINT16);
                AddReturnParameter(3, "nbOfPolePairs", ODT_UINT8);
                SetDefaultParameter_GetEcMotorParameter();
                return 1;
            };
        case MOVE_SET_MOTOR_PARAMETER:
            {
                CCommand_VCS::InitCommand("SetMotorParameter", MOVE_SET_MOTOR_PARAMETER);
                AddParameter(0, "motorType", ODT_UINT16);
                AddParameter(1, "continuousCurrent", ODT_UINT16);
                AddParameter(2, "peakCurrent", ODT_UINT16);
                AddParameter(3, "polePair", ODT_UINT8);
                AddParameter(4, "thermalTimeConstant", ODT_UINT16);
                SetDefaultParameter_SetMotorParameter();
                return 1;
            };
        case MOVE_SET_MOTOR_TYPE:
            {
                CCommand_VCS::InitCommand("SetMotorType", MOVE_SET_MOTOR_TYPE);
                AddParameter(0, "motorType", ODT_UINT16);
                SetDefaultParameter_SetMotorType();
                return 1;
            };
        case MOVE_SET_DC_MOTOR_PARAMETER:
            {
                CCommand_VCS::InitCommand("SetDcMotorParameter", MOVE_SET_DC_MOTOR_PARAMETER);
                AddParameter(0, "nominalCurrent", ODT_UINT16);
                AddParameter(1, "maxOutputCurrent", ODT_UINT16);
                AddParameter(2, "thermalTimeConstant", ODT_UINT16);
                SetDefaultParameter_SetDcMotorParameter();
                return 1;
            };
        case MOVE_SET_EC_MOTOR_PARAMETER:
            {
                CCommand_VCS::InitCommand("SetEcMotorParameter", MOVE_SET_EC_MOTOR_PARAMETER);
                AddParameter(0, "nominalCurrent", ODT_UINT16);
                AddParameter(1, "maxOutputCurrent", ODT_UINT16);
                AddParameter(2, "thermalTimeConstant", ODT_UINT16);
                AddParameter(3, "nbOfPolePairs", ODT_UINT8);
                SetDefaultParameter_SetEcMotorParameter();
                return 1;
            };
    }

    return 0;
}

BOOL CCommand_VCS_Move::InitCommand_ConfigurationSensor(DWORD p_ulCommandId)
{
    switch(p_ulCommandId)
    {
        case MOVE_GET_ENCODER_PARAMETER:
            {
                CCommand_VCS::InitCommand("GetEncoderParameter", MOVE_GET_ENCODER_PARAMETER);
                AddReturnParameter(0, "counts", ODT_UINT16);
                AddReturnParameter(1, "positionSensorType", ODT_UINT16);
                SetDefaultParameter_GetEncoderParameter();
                return 1;
            };
        case MOVE_GET_SENSOR_TYPE:
            {
                CCommand_VCS::InitCommand("GetSensorType", MOVE_GET_SENSOR_TYPE);
                AddReturnParameter(0, "sensorType", ODT_UINT16);
                SetDefaultParameter_GetSensorType();
                return 1;
            };
        case MOVE_GET_INC_ENCODER_PARAMETER:
            {
                CCommand_VCS::InitCommand("GetIncEncoderParameter", MOVE_GET_INC_ENCODER_PARAMETER);
                AddReturnParameter(0, "encoderResolution", ODT_UINT32);
                AddReturnParameter(1, "invertedPolarity", ODT_BOOLEAN);
                SetDefaultParameter_GetIncEncoderParameter();
                return 1;
            };
        case MOVE_GET_HALL_SENSOR_PARAMETER:
            {
                CCommand_VCS::InitCommand("GetEncoderParameter", MOVE_GET_HALL_SENSOR_PARAMETER);
                AddReturnParameter(0, "invertedPolarity", ODT_BOOLEAN);
                SetDefaultParameter_GetHallSensorParameter();
                return 1;
            };
        case MOVE_GET_SSI_ABS_ENCODER_PARAMETER:
            {
                CCommand_VCS::InitCommand("GetSsiAbsEncoderParameter", MOVE_GET_SSI_ABS_ENCODER_PARAMETER);
                AddReturnParameter(0, "dataRate", ODT_UINT16);
                AddReturnParameter(1, "nbOfMultiTurnDataBits", ODT_UINT16);
                AddReturnParameter(2, "nbOfSingleTurnDataBits", ODT_UINT16);
                AddReturnParameter(3, "invertedPolarity", ODT_BOOLEAN);
                SetDefaultParameter_GetSsiAbsEncoderParameter();
                return 1;
            };
        case MOVE_SET_ENCODER_PARAMETER:
            {
                CCommand_VCS::InitCommand("SetEncoderParameter", MOVE_SET_ENCODER_PARAMETER);
                AddParameter(0, "counts", ODT_UINT16);
                AddParameter(1, "positionSensorType", ODT_UINT16);
                SetDefaultParameter_SetEncoderParameter();
                return 1;
            };
        case MOVE_SET_SENSOR_TYPE:
            {
                CCommand_VCS::InitCommand("SetSensorType", MOVE_SET_SENSOR_TYPE);
                AddParameter(0, "sensorType", ODT_UINT16);
                SetDefaultParameter_SetSensorType();
                return 1;
            };
        case MOVE_SET_INC_ENCODER_PARAMETER:
            {
                CCommand_VCS::InitCommand("SetIncEncoderParameter", MOVE_SET_INC_ENCODER_PARAMETER);
                AddParameter(0, "encoderResolution", ODT_UINT32);
                AddParameter(1, "invertedPolarity", ODT_BOOLEAN);
                SetDefaultParameter_SetIncEncoderParameter();
                return 1;
            };
        case MOVE_SET_HALL_SENSOR_PARAMETER:
            {
                CCommand_VCS::InitCommand("SetEncoderParameter", MOVE_SET_HALL_SENSOR_PARAMETER);
                AddParameter(0, "invertedPolarity", ODT_BOOLEAN);
                SetDefaultParameter_SetHallSensorParameter();
                return 1;
            };
        case MOVE_SET_SSI_ABS_ENCODER_PARAMETER:
            {
                CCommand_VCS::InitCommand("SetSsiAbsEncoderParameter", MOVE_SET_SSI_ABS_ENCODER_PARAMETER);
                AddParameter(0, "dataRate", ODT_UINT16);
                AddParameter(1, "nbOfMultiTurnDataBits", ODT_UINT16);
                AddParameter(2, "nbOfSingleTurnDataBits", ODT_UINT16);
                AddParameter(3, "invertedPolarity", ODT_BOOLEAN);
                SetDefaultParameter_SetSsiAbsEncoderParameter();
                return 1;
            };
    }

    return 0;
}

BOOL CCommand_VCS_Move::InitCommand_CurrentMode(DWORD p_ulCommandId)
{
    switch(p_ulCommandId)
    {
        case MOVE_GET_CURRENT_MUST:
            {
                CCommand_VCS::InitCommand("GetCurrentMust", MOVE_GET_CURRENT_MUST);
                AddReturnParameter(0, "currentMust", ODT_INT16);
                SetDefaultParameter_GetCurrentMust();
                return 1;
            };
        case MOVE_SET_CURRENT_MUST:
            {
                CCommand_VCS::InitCommand("SetCurrentMust", MOVE_SET_CURRENT_MUST);
                AddParameter(0, "currentMust", ODT_INT16);
                SetDefaultParameter_SetCurrentMust();
                return 1;
            };
        case MOVE_ACTIVATE_ANALOG_CURRENT_SETPOINT:
            {
                CCommand_VCS::InitCommand("ActivateAnalogCurrentSetpoint", MOVE_ACTIVATE_ANALOG_CURRENT_SETPOINT);
                AddParameter(0, "analogInputNumber", ODT_UINT16);
                AddParameter(1, "scaling", ODT_FLOAT);
                AddParameter(2, "offset", ODT_INT16);
                SetDefaultParameter_ActivateAnalogCurrentSetpoint();
                return 1;
            };
        case MOVE_DEACTIVATE_ANALOG_CURRENT_SETPOINT:
            {
                CCommand_VCS::InitCommand("DeactivateAnalogCurrentSetpoint", MOVE_DEACTIVATE_ANALOG_CURRENT_SETPOINT);
                AddParameter(0, "analogInputNumber", ODT_UINT16);
                SetDefaultParameter_DeactivateAnalogCurrentSetpoint();
                return 1;
            };
        case MOVE_ENABLE_ANALOG_CURRENT_SETPOINT:
            {
                CCommand_VCS::InitCommand("EnableAnalogCurrentSetpoint", MOVE_ENABLE_ANALOG_CURRENT_SETPOINT);
                SetDefaultParameter_EnableAnalogCurrentSetpoint();
                return 1;
            };
        case MOVE_DISABLE_ANALOG_CURRENT_SETPOINT:
            {
                CCommand_VCS::InitCommand("DisableAnalogCurrentSetpoint", MOVE_DISABLE_ANALOG_CURRENT_SETPOINT);
                SetDefaultParameter_DisableAnalogCurrentSetpoint();
                return 1;
            };
    }

    return 0;
}

BOOL CCommand_VCS_Move::InitCommand_FirmwareDownload(DWORD p_ulCommandId)
{
    switch(p_ulCommandId)
    {
        case MOVE_GET_BASE_SECTOR_VERSION:
            {
                CCommand_VCS::InitCommand("GetBaseSectorVersion", MOVE_GET_BASE_SECTOR_VERSION);
                AddReturnParameter(0, "baseSectorVersion", ODT_UINT16);
                SetDefaultParameter_GetBaseSectorVersion();
                return 1;
            };
        case MOVE_GET_SERIAL_NUMBER:
            {
                CCommand_VCS::InitCommand("GetSerialNumber", MOVE_GET_SERIAL_NUMBER);
                AddReturnParameter(0, "serialNumber", ODT_UINT64);
                SetDefaultParameter_GetSerialNumber();
                return 1;
            };
    }

    return 0;
}

BOOL CCommand_VCS_Move::InitCommand_InputsOutputs(DWORD p_ulCommandId)
{
    switch(p_ulCommandId)
    {
        case IO_DIGITAL_INPUT_CONFIGURATION:
            {
                CCommand_VCS::InitCommand("DigitalInputConfiguration", IO_DIGITAL_INPUT_CONFIGURATION);
                AddParameter(0, "inputNb", ODT_UINT16);
                AddParameter(1, "configuration", ODT_UINT16);
                AddParameter(2, "mask", ODT_BOOLEAN);
                AddParameter(3, "polarity", ODT_BOOLEAN);
                AddParameter(4, "executionMask", ODT_BOOLEAN);
                SetDefaultParameter_DigitalInputConfiguration();
                return 1;
            };
        case IO_DIGITAL_OUTPUT_CONFIGURATION:
            {
                CCommand_VCS::InitCommand("DigitalOutputConfiguration", IO_DIGITAL_OUTPUT_CONFIGURATION);
                AddParameter(0, "outputNb", ODT_UINT16);
                AddParameter(1, "configuration", ODT_UINT16);
                AddParameter(2, "state", ODT_BOOLEAN);
                AddParameter(3, "mask", ODT_BOOLEAN);
                AddParameter(4, "polarity", ODT_BOOLEAN);
                SetDefaultParameter_DigitalOutputConfiguration();
                return 1;
            };
        case IO_ANALOG_INPUT_CONFIGURATION:
            {
                CCommand_VCS::InitCommand("AnalogInputConfiguration", IO_ANALOG_INPUT_CONFIGURATION);
                AddParameter(0, "inputNb", ODT_UINT16);
                AddParameter(1, "configuration", ODT_UINT16);
                AddParameter(2, "executionMask", ODT_BOOLEAN);
                SetDefaultParameter_AnalogInputConfiguration();
                return 1;
            };
        case IO_GET_ALL_DIGITAL_INPUTS:
            {
                CCommand_VCS::InitCommand("GetAllDigitalInputs", IO_GET_ALL_DIGITAL_INPUTS);
                AddReturnParameter(0, "inputs", ODT_UINT16);
                SetDefaultParameter_GetAllDigitalInputs();
                return 1;
            };
        case IO_GET_ALL_DIGITAL_OUTPUTS:
            {
                CCommand_VCS::InitCommand("GetAllDigitalOutputs", IO_GET_ALL_DIGITAL_OUTPUTS);
                AddReturnParameter(0, "outputs", ODT_UINT16);
                SetDefaultParameter_GetAllDigitalOutputs();
                return 1;
            };
        case IO_GET_ANALOG_INPUT:
            {
                CCommand_VCS::InitCommand("GetAnalogInput", IO_GET_ANALOG_INPUT);
                AddParameter(0, "number", ODT_UINT16);
                AddReturnParameter(0, "analog", ODT_UINT16);
                SetDefaultParameter_GetAnalogInput();
                return 1;
            };
        case IO_SET_ALL_DIGITAL_OUTPUTS:
            {
                CCommand_VCS::InitCommand("SetAllDigitalOutputs", IO_SET_ALL_DIGITAL_OUTPUTS);
                AddParameter(0, "outputs", ODT_UINT16);
                SetDefaultParameter_SetAllDigitalOutputs();
                return 1;
            };
        case IO_SET_ANALOG_OUTPUT:
            {
                CCommand_VCS::InitCommand("SetAnalogOutput", IO_SET_ANALOG_OUTPUT);
                AddParameter(0, "number", ODT_UINT16);
                AddParameter(1, "outputValue", ODT_UINT16);
                SetDefaultParameter_SetAnalogOutput();
                return 1;
            };
    }

    return 0;
}

BOOL CCommand_VCS_Move::InitCommand_MotionInfo(DWORD p_ulCommandId)
{
    switch(p_ulCommandId)
    {
        case MOVE_GET_CURRENT_IS:
            {
                CCommand_VCS::InitCommand("GetCurrentIs", MOVE_GET_CURRENT_IS);
                AddReturnParameter(0, "currentIs", ODT_INT16);
                SetDefaultParameter_GetCurrentIs();
                return 1;
            };
        case MOVE_GET_MOVEMENT_STATE:
            {
                CCommand_VCS::InitCommand("GetMovementState", MOVE_GET_MOVEMENT_STATE);
                AddReturnParameter(0, "targetReached", ODT_BOOLEAN);
                SetDefaultParameter_GetMovementState();
                return 1;
            };
        case MOVE_GET_POSITION_IS:
            {
                CCommand_VCS::InitCommand("GetPositionIs", MOVE_GET_POSITION_IS);
                AddReturnParameter(0, "positionIs", ODT_INT32);
                SetDefaultParameter_GetPositionIs();
                return 1;
            };
        case MOVE_GET_VELOCITY_IS:
            {
                CCommand_VCS::InitCommand("GetVelocityIs", MOVE_GET_VELOCITY_IS);
                AddReturnParameter(0, "velocityIs", ODT_INT32);
                SetDefaultParameter_GetVelocityIs();
                return 1;
            };
    }

    return 0;
}

BOOL CCommand_VCS_Move::InitCommand_PositionMode(DWORD p_ulCommandId)
{
    switch(p_ulCommandId)
    {
        case MOVE_GET_POSITION_MUST:
            {
                CCommand_VCS::InitCommand("GetPositionMust", MOVE_GET_POSITION_MUST);
                AddReturnParameter(0, "positionMust", ODT_INT32);
                SetDefaultParameter_GetPositionMust();
                return 1;
            };
        case MOVE_SET_POSITION_MUST:
            {
                CCommand_VCS::InitCommand("SetPositionMust", MOVE_SET_POSITION_MUST);
                AddParameter(0, "positionMust", ODT_INT32);
                SetDefaultParameter_SetPositionMust();
                return 1;
            };
        case MOVE_ACTIVATE_ANALOG_POSITION_SETPOINT:
            {
                CCommand_VCS::InitCommand("ActivateAnalogPositionSetpoint", MOVE_ACTIVATE_ANALOG_POSITION_SETPOINT);
                AddParameter(0, "analogInputNumber", ODT_UINT16);
                AddParameter(1, "scaling", ODT_FLOAT);
                AddParameter(2, "offset", ODT_INT32);
                SetDefaultParameter_ActivateAnalogPositionSetpoint();
                return 1;
            };
        case MOVE_DEACTIVATE_ANALOG_POSITION_SETPOINT:
            {
                CCommand_VCS::InitCommand("DeactivateAnalogPositionSetpoint", MOVE_DEACTIVATE_ANALOG_POSITION_SETPOINT);
                AddParameter(0, "analogInputNumber", ODT_UINT16);
                SetDefaultParameter_DeactivateAnalogPositionSetpoint();
                return 1;
            };
        case MOVE_ENABLE_ANALOG_POSITION_SETPOINT:
            {
                CCommand_VCS::InitCommand("EnableAnalogPositionSetpoint", MOVE_ENABLE_ANALOG_POSITION_SETPOINT);
                SetDefaultParameter_EnableAnalogPositionSetpoint();
                return 1;
            };
        case MOVE_DISABLE_ANALOG_POSITION_SETPOINT:
            {
                CCommand_VCS::InitCommand("DisableAnalogPositionSetpoint", MOVE_DISABLE_ANALOG_POSITION_SETPOINT);
                SetDefaultParameter_DisableAnalogPositionSetpoint();
                return 1;
            };
    }

    return 0;
}

BOOL CCommand_VCS_Move::InitCommand_StateMachine(DWORD p_ulCommandId)
{
    switch(p_ulCommandId)
    {
        case MOVE_CLEAR_FAULT:
            {
                CCommand_VCS::InitCommand("ClearFault", MOVE_CLEAR_FAULT);
                SetDefaultParameter_ClearFault();
                return 1;
            };
        case MOVE_GET_DISABLE_STATE:
            {
                CCommand_VCS::InitCommand("GetDisableState", MOVE_GET_DISABLE_STATE);
                AddReturnParameter(0, "disabled", ODT_BOOLEAN);
                SetDefaultParameter_GetDisableState();
                return 1;
            };
        case MOVE_GET_ENABLE_STATE:
            {
                CCommand_VCS::InitCommand("GetEnableState", MOVE_GET_ENABLE_STATE);
                AddReturnParameter(0, "enabled", ODT_BOOLEAN);
                SetDefaultParameter_GetEnableState();
                return 1;
            };
        case MOVE_GET_FAULT_STATE:
            {
                CCommand_VCS::InitCommand("GetFaultState", MOVE_GET_FAULT_STATE);
                AddReturnParameter(0, "isInFault", ODT_BOOLEAN);
                SetDefaultParameter_GetFaultState();
                return 1;
            };
        case MOVE_GET_OPERATION_MODE:
            {
                CCommand_VCS::InitCommand("GetOperationMode", MOVE_GET_OPERATION_MODE);
                AddReturnParameter(0, "mode", ODT_INT8);
                SetDefaultParameter_GetOperationMode();
                return 1;
            };
        case MOVE_GET_QUICK_STOP_STATE:
            {
                CCommand_VCS::InitCommand("GetQuickStopState", MOVE_GET_QUICK_STOP_STATE);
                AddReturnParameter(0, "isQuickStoped", ODT_BOOLEAN);
                SetDefaultParameter_GetQuickStopState();
                return 1;
            };
        case MOVE_SET_DISABLE_STATE:
            {
                CCommand_VCS::InitCommand("SetDisableState", MOVE_SET_DISABLE_STATE);
                SetDefaultParameter_SetDisableState();
                return 1;
            };
        case MOVE_SET_ENABLE_STATE:
            {
                CCommand_VCS::InitCommand("SetEnableState", MOVE_SET_ENABLE_STATE);
                SetDefaultParameter_SetEnableState();
                return 1;
            };
        case MOVE_SET_OPERATION_MODE:
            {
                CCommand_VCS::InitCommand("SetOperationMode", MOVE_SET_OPERATION_MODE);
                AddParameter(0, "mode", ODT_INT8);
                SetDefaultParameter_SetOperationMode();
                return 1;
            };
        case MOVE_SET_QUICK_STOP_STATE:
            {
                CCommand_VCS::InitCommand("SetQuickStopState", MOVE_SET_QUICK_STOP_STATE);
                SetDefaultParameter_SetQuickStopState();
                return 1;
            };
    }

    return 0;
}

BOOL CCommand_VCS_Move::InitCommand_VelocityMode(DWORD p_ulCommandId)
{
    switch(p_ulCommandId)
    {
        case MOVE_GET_VELOCITY_MUST:
            {
                CCommand_VCS::InitCommand("GetVelocityMust", MOVE_GET_VELOCITY_MUST);
                AddReturnParameter(0, "velocityMust", ODT_INT32);
                SetDefaultParameter_GetVelocityMust();
                return 1;
            };
        case MOVE_SET_VELOCITY_MUST:
            {
                CCommand_VCS::InitCommand("SetVelocityMust", MOVE_SET_VELOCITY_MUST);
                AddParameter(0, "velocityMust", ODT_INT32);
                SetDefaultParameter_SetVelocityMust();
                return 1;
            };
        case MOVE_ACTIVATE_ANALOG_VELOCITY_SETPOINT:
            {
                CCommand_VCS::InitCommand("ActivateAnalogVelocitySetpoint", MOVE_ACTIVATE_ANALOG_VELOCITY_SETPOINT);
                AddParameter(0, "analogInputNumber", ODT_UINT16);
                AddParameter(1, "scaling", ODT_FLOAT);
                AddParameter(2, "offset", ODT_INT32);
                SetDefaultParameter_ActivateAnalogVelocitySetpoint();
                return 1;
            };
        case MOVE_DEACTIVATE_ANALOG_VELOCITY_SETPOINT:
            {
                CCommand_VCS::InitCommand("DeactivateAnalogVelocitySetpoint", MOVE_DEACTIVATE_ANALOG_VELOCITY_SETPOINT);
                AddParameter(0, "analogInputNumber", ODT_UINT16);
                SetDefaultParameter_DeactivateAnalogVelocitySetpoint();
                return 1;
            };
        case MOVE_ENABLE_ANALOG_VELOCITY_SETPOINT:
            {
                CCommand_VCS::InitCommand("EnableAnalogVelocitySetpoint", MOVE_ENABLE_ANALOG_VELOCITY_SETPOINT);
                SetDefaultParameter_EnableAnalogVelocitySetpoint();
                return 1;
            };
        case MOVE_DISABLE_ANALOG_VELOCITY_SETPOINT:
            {
                CCommand_VCS::InitCommand("DisableAnalogVelocitySetpoint", MOVE_DISABLE_ANALOG_VELOCITY_SETPOINT);
                SetDefaultParameter_DisableAnalogVelocitySetpoint();
                return 1;
            };
    }

    return 0;
}

void CCommand_VCS_Move::SetDefaultParameter_GetCurrentRegulatorGain()
{
    WORD usP(100);
    WORD usI(100);

    //Parameter

    //ReturnParameter
    SetReturnParameterData(0, &usP, sizeof(usP));
    SetReturnParameterData(1, &usI, sizeof(usI));
}

void CCommand_VCS_Move::SetDefaultParameter_GetEncoderParameter()
{
    WORD usCounts = 500;
    WORD usPositionSensorType(1);

    //Parameter

    //ReturnParameter
    SetReturnParameterData(0, &usCounts, sizeof(usCounts));
    SetReturnParameterData(1, &usPositionSensorType, sizeof(usPositionSensorType));
}

void CCommand_VCS_Move::SetDefaultParameter_GetSensorType()
{
    WORD usSensorType(1);

    //Parameter

    //ReturnParameter
    SetReturnParameterData(0, &usSensorType, sizeof(usSensorType));
}

void CCommand_VCS_Move::SetDefaultParameter_GetIncEncoderParameter()
{
    WORD usEncoderResolution = 500;
    BOOL oInvertedPolarity(0);

    //Parameter

    //ReturnParameter
    SetReturnParameterData(0, &usEncoderResolution, sizeof(usEncoderResolution));
    SetReturnParameterData(1, &oInvertedPolarity, sizeof(oInvertedPolarity));
}

void CCommand_VCS_Move::SetDefaultParameter_GetHallSensorParameter()
{
    BOOL oInvertedPolarity(0);

    //Parameter

    //ReturnParameter
    SetReturnParameterData(0, &oInvertedPolarity, sizeof(oInvertedPolarity));
}

void CCommand_VCS_Move::SetDefaultParameter_GetSsiAbsEncoderParameter()
{
    WORD usDataRate = 500;
    WORD usNbOfMultiTurnDataBits = 12;
    WORD usNbOfSingleTurnDataBits = 13;
    BOOL oInvertedPolarity(0);

    //Parameter

    //ReturnParameter
    SetReturnParameterData(0, &usDataRate, sizeof(usDataRate));
    SetReturnParameterData(1, &usNbOfMultiTurnDataBits, sizeof(usNbOfMultiTurnDataBits));
    SetReturnParameterData(2, &usNbOfSingleTurnDataBits, sizeof(usNbOfSingleTurnDataBits));
    SetReturnParameterData(3, &oInvertedPolarity, sizeof(oInvertedPolarity));
}

void CCommand_VCS_Move::SetDefaultParameter_GetMotorParameter()
{
    WORD usMotorType(10);
    WORD usContinuousCurrent(1);
    WORD usMaxOutputCurrent(1);
    BYTE ubNbOfPolePairs(1);
    WORD usThermalTimeConstant(40);

    //Parameter

    //ReturnParameter
    SetReturnParameterData(0, &usMotorType, sizeof(usMotorType));
    SetReturnParameterData(1, &usContinuousCurrent, sizeof(usContinuousCurrent));
    SetReturnParameterData(2, &usMaxOutputCurrent, sizeof(usMaxOutputCurrent));
    SetReturnParameterData(3, &ubNbOfPolePairs, sizeof(ubNbOfPolePairs));
    SetReturnParameterData(4, &usThermalTimeConstant, sizeof(usThermalTimeConstant));
}

void CCommand_VCS_Move::SetDefaultParameter_GetMotorType()
{
    WORD usMotorType(10);

    //Parameter

    //ReturnParameter
    SetReturnParameterData(0, &usMotorType, sizeof(usMotorType));
}

void CCommand_VCS_Move::SetDefaultParameter_GetDcMotorParameter()
{
    WORD usContinuousCurrent(1);
    WORD usMaxOutputCurrent(1);
    WORD usThermalTimeConstant(40);

    //Parameter

    //ReturnParameter
    SetReturnParameterData(0, &usContinuousCurrent, sizeof(usContinuousCurrent));
    SetReturnParameterData(1, &usMaxOutputCurrent, sizeof(usMaxOutputCurrent));
    SetReturnParameterData(2, &usThermalTimeConstant, sizeof(usThermalTimeConstant));
}

void CCommand_VCS_Move::SetDefaultParameter_GetEcMotorParameter()
{
    WORD usContinuousCurrent(1);
    WORD usMaxOutputCurrent(1);
    BYTE ubNbOfPolePairs(1);
    WORD usThermalTimeConstant(40);

    //Parameter

    //ReturnParameter
    SetReturnParameterData(0, &usContinuousCurrent, sizeof(usContinuousCurrent));
    SetReturnParameterData(1, &usMaxOutputCurrent, sizeof(usMaxOutputCurrent));
    SetReturnParameterData(2, &usThermalTimeConstant, sizeof(usThermalTimeConstant));
    SetReturnParameterData(3, &ubNbOfPolePairs, sizeof(ubNbOfPolePairs));
}

void CCommand_VCS_Move::SetDefaultParameter_GetVelocityRegulatorGain()
{
    BYTE uPortNumber(0);
    WORD wNodeId(1);
    WORD usP(100);
    WORD usI(100);

    //Parameter
    SetParameterData(0, &uPortNumber, sizeof(uPortNumber));
    SetParameterData(1, &wNodeId, sizeof(wNodeId));

    //ReturnParameter
    SetReturnParameterData(0, &usP, sizeof(usP));
    SetReturnParameterData(1, &usI, sizeof(usI));
}

void CCommand_VCS_Move::SetDefaultParameter_GetMaxFollowingError()
{
    BYTE uPortNumber(0);
    WORD wNodeId(1);
    DWORD ulMaxFollowingError = 2000;

    //Parameter
    SetParameterData(0, &uPortNumber, sizeof(uPortNumber));
    SetParameterData(1, &wNodeId, sizeof(wNodeId));

    //ReturnParameter
    SetReturnParameterData(0, &ulMaxFollowingError, sizeof(ulMaxFollowingError));
}

void CCommand_VCS_Move::SetDefaultParameter_GetMaxProfileVelocity()
{
    BYTE uPortNumber(0);
    WORD wNodeId(1);
    DWORD ulMaxProfileVelocity = 25000;

    //Parameter
    SetParameterData(0, &uPortNumber, sizeof(uPortNumber));
    SetParameterData(1, &wNodeId, sizeof(wNodeId));

    //ReturnParameter
    SetReturnParameterData(0, &ulMaxProfileVelocity, sizeof(ulMaxProfileVelocity));
}

void CCommand_VCS_Move::SetDefaultParameter_GetMaxAcceleration()
{
    BYTE uPortNumber(0);
    WORD wNodeId(1);
    DWORD ulMaxAcceleration = UINT_MAX;

    //Parameter
    SetParameterData(0, &uPortNumber, sizeof(uPortNumber));
    SetParameterData(1, &wNodeId, sizeof(wNodeId));

    //ReturnParameter
    SetReturnParameterData(0, &ulMaxAcceleration, sizeof(ulMaxAcceleration));
}

void CCommand_VCS_Move::SetDefaultParameter_GetVelocityUnits()
{
    BYTE ubVelocityDimension = 0xA4;
    char bVelocityNotation(0);

    //ReturnParameter
    SetReturnParameterData(0, &ubVelocityDimension, sizeof(ubVelocityDimension));
    SetReturnParameterData(1, &bVelocityNotation, sizeof(bVelocityNotation));
}

void CCommand_VCS_Move::SetDefaultParameter_SetCurrentRegulatorGain()
{
    WORD usP(100);
    WORD usI(100);

    //Parameter
    SetParameterData(0, &usP, sizeof(usP));
    SetParameterData(1, &usI, sizeof(usI));
}

void CCommand_VCS_Move::SetDefaultParameter_SetEncoderParameter()
{
    WORD usCounts = 500;
    WORD usPositionSensorType(1);

    //Parameter
    SetParameterData(0, &usCounts, sizeof(usCounts));
    SetParameterData(1, &usPositionSensorType, sizeof(usPositionSensorType));
}

void CCommand_VCS_Move::SetDefaultParameter_SetSensorType()
{
    WORD usSensorType(1);

    //Parameter
    SetParameterData(0, &usSensorType, sizeof(usSensorType));
}

void CCommand_VCS_Move::SetDefaultParameter_SetIncEncoderParameter()
{
    WORD usEncoderResolution = 500;
    BOOL oInvertedPolarity(0);

    //Parameter
    SetParameterData(0, &usEncoderResolution, sizeof(usEncoderResolution));
    SetParameterData(1, &oInvertedPolarity, sizeof(oInvertedPolarity));
}

void CCommand_VCS_Move::SetDefaultParameter_SetHallSensorParameter()
{
    BOOL oInvertedPolarity(0);

    //Parameter
    SetParameterData(0, &oInvertedPolarity, sizeof(oInvertedPolarity));
}

void CCommand_VCS_Move::SetDefaultParameter_SetSsiAbsEncoderParameter()
{
    WORD usDataRate = 500;
    WORD usNbOfMultiTurnDataBits = 12;
    WORD usNbOfSingleTurnDataBits = 13;
    BOOL oInvertedPolarity(0);

    //Parameter
    SetParameterData(0, &usDataRate, sizeof(usDataRate));
    SetParameterData(1, &usNbOfMultiTurnDataBits, sizeof(usNbOfMultiTurnDataBits));
    SetParameterData(2, &usNbOfSingleTurnDataBits, sizeof(usNbOfSingleTurnDataBits));
    SetParameterData(3, &oInvertedPolarity, sizeof(oInvertedPolarity));
}

void CCommand_VCS_Move::SetDefaultParameter_SetMotorParameter()
{
    WORD usMotorType(10);
    WORD usContinuousCurrent(1);
    WORD usMaxOutputCurrent(1);
    BYTE ubNbOfPolePairs(1);
    WORD usThermalTimeConstant(40);

    //Parameter
    SetParameterData(0, &usMotorType, sizeof(usMotorType));
    SetParameterData(1, &usContinuousCurrent, sizeof(usContinuousCurrent));
    SetParameterData(2, &usMaxOutputCurrent, sizeof(usMaxOutputCurrent));
    SetParameterData(3, &ubNbOfPolePairs, sizeof(ubNbOfPolePairs));
    SetParameterData(4, &usThermalTimeConstant, sizeof(usThermalTimeConstant));
}

void CCommand_VCS_Move::SetDefaultParameter_SetMotorType()
{
    WORD usMotorType(10);

    //Parameter
    SetParameterData(0, &usMotorType, sizeof(usMotorType));
}

void CCommand_VCS_Move::SetDefaultParameter_SetDcMotorParameter()
{
    WORD usContinuousCurrent(1);
    WORD usMaxOutputCurrent(1);
    WORD usThermalTimeConstant(40);

    //Parameter
    SetParameterData(0, &usContinuousCurrent, sizeof(usContinuousCurrent));
    SetParameterData(1, &usMaxOutputCurrent, sizeof(usMaxOutputCurrent));
    SetParameterData(2, &usThermalTimeConstant, sizeof(usThermalTimeConstant));
}

void CCommand_VCS_Move::SetDefaultParameter_SetEcMotorParameter()
{
    WORD usContinuousCurrent(1);
    WORD usMaxOutputCurrent(1);
    BYTE ubNbOfPolePairs(1);
    WORD usThermalTimeConstant(40);

    //Parameter
    SetParameterData(0, &usContinuousCurrent, sizeof(usContinuousCurrent));
    SetParameterData(1, &usMaxOutputCurrent, sizeof(usMaxOutputCurrent));
    SetParameterData(2, &usThermalTimeConstant, sizeof(usThermalTimeConstant));
    SetParameterData(3, &ubNbOfPolePairs, sizeof(ubNbOfPolePairs));
}

void CCommand_VCS_Move::SetDefaultParameter_SetVelocityRegulatorGain()
{
    WORD usP(100);
    WORD usI(100);

    //Parameter
    SetParameterData(0, &usP, sizeof(usP));
    SetParameterData(1, &usI, sizeof(usI));
}

void CCommand_VCS_Move::SetDefaultParameter_SetMaxFollowingError()
{
    DWORD ulMaxFollowingError(2000);

    //Parameter
    SetParameterData(0, &ulMaxFollowingError, sizeof(ulMaxFollowingError));
}

void CCommand_VCS_Move::SetDefaultParameter_SetMaxProfileVelocity()
{
    DWORD ulMaxProfileVelocity(25000);

    //Parameter
    SetParameterData(0, &ulMaxProfileVelocity, sizeof(ulMaxProfileVelocity));
}

void CCommand_VCS_Move::SetDefaultParameter_SetMaxAcceleration()
{
    DWORD ulMaxAcceleration(UINT_MAX);

    //Parameter
    SetParameterData(0, &ulMaxAcceleration, sizeof(ulMaxAcceleration));
}

void CCommand_VCS_Move::SetDefaultParameter_SetVelocityUnits()
{
    BYTE ubVelocityDimension(0xA4);
    char bVelocityNotation(0);

    //Parameter
    SetParameterData(0, &ubVelocityDimension, sizeof(ubVelocityDimension));
    SetParameterData(1, &bVelocityNotation, sizeof(bVelocityNotation));
}

void CCommand_VCS_Move::SetDefaultParameter_GetCurrentMust()
{
    short sCurrentMust(0);

    //Parameter

    //ReturnParameter
    SetReturnParameterData(0, &sCurrentMust, sizeof(sCurrentMust));
}

void CCommand_VCS_Move::SetDefaultParameter_SetCurrentMust()
{
    short sCurrentMust(0);

    //Parameter
    SetParameterData(0, &sCurrentMust, sizeof(sCurrentMust));
}

void CCommand_VCS_Move::SetDefaultParameter_ActivateAnalogCurrentSetpoint()
{
    WORD usAnalogInputNumber(0);
    float fScaling(0);
    short sOffset(0);

    //Parameter
    SetParameterData(0, &usAnalogInputNumber, sizeof(usAnalogInputNumber));
    SetParameterData(1, &fScaling, sizeof(fScaling));
    SetParameterData(2, &sOffset, sizeof(sOffset));
}

void CCommand_VCS_Move::SetDefaultParameter_DeactivateAnalogCurrentSetpoint()
{
    WORD usAnalogInputNumber(0);

    //Parameter
    SetParameterData(0, &usAnalogInputNumber, sizeof(usAnalogInputNumber));
}

void CCommand_VCS_Move::SetDefaultParameter_EnableAnalogCurrentSetpoint()
{

    //Parameter
}

void CCommand_VCS_Move::SetDefaultParameter_DisableAnalogCurrentSetpoint()
{

    //Parameter
}

void CCommand_VCS_Move::SetDefaultParameter_DigitalInputConfiguration()
{
    WORD usInputNb(0);
    WORD usConfiguration(0);
    BOOL oMask(0);
    BOOL oPolarity(0);
    BOOL oExecutionMask(0);

    //Parameter
    SetParameterData(0, &usInputNb, sizeof(usInputNb));
    SetParameterData(1, &usConfiguration, sizeof(usConfiguration));
    SetParameterData(2, &oMask, sizeof(oMask));
    SetParameterData(3, &oPolarity, sizeof(oPolarity));
    SetParameterData(4, &oExecutionMask, sizeof(oExecutionMask));
}

void CCommand_VCS_Move::SetDefaultParameter_DigitalOutputConfiguration()
{
    WORD usOutputNb(0);
    WORD usConfiguration(0);
    BOOL oState(0);
    BOOL oMask(0);
    BOOL oPolarity(0);

    //Parameter
    SetParameterData(0, &usOutputNb, sizeof(usOutputNb));
    SetParameterData(1, &usConfiguration, sizeof(usConfiguration));
    SetParameterData(2, &oState, sizeof(oState));
    SetParameterData(3, &oMask, sizeof(oMask));
    SetParameterData(4, &oPolarity, sizeof(oPolarity));
}

void CCommand_VCS_Move::SetDefaultParameter_AnalogInputConfiguration()
{
    WORD usInputNb(0);
    WORD usConfiguration(0);
    BOOL oExecutionMask(0);

    //Parameter
    SetParameterData(0, &usInputNb, sizeof(usInputNb));
    SetParameterData(1, &usConfiguration, sizeof(usConfiguration));
    SetParameterData(2, &oExecutionMask, sizeof(oExecutionMask));
}

void CCommand_VCS_Move::SetDefaultParameter_GetAllDigitalInputs()
{
    WORD usInputs(0);

    //ReturnParameter
    SetReturnParameterData(0, &usInputs, sizeof(usInputs));
}

void CCommand_VCS_Move::SetDefaultParameter_GetAllDigitalOutputs()
{
    WORD usOutputs(0);

    //ReturnParameter
    SetReturnParameterData(0, &usOutputs, sizeof(usOutputs));
}

void CCommand_VCS_Move::SetDefaultParameter_GetAnalogInput()
{
    WORD usNumber(0);
    WORD usAnalog(0);

    //Parameter
    SetParameterData(0, &usNumber, sizeof(usNumber));

    //ReturnParameter
    SetReturnParameterData(0, &usAnalog, sizeof(usAnalog));
}

void CCommand_VCS_Move::SetDefaultParameter_SetAllDigitalOutputs()
{
    WORD usOutputs(0);

    //Parameter
    SetParameterData(0, &usOutputs, sizeof(usOutputs));
}

void CCommand_VCS_Move::SetDefaultParameter_SetAnalogOutput()
{
    WORD usNumber(0);
    WORD usOutput(0);

    //Parameter
    SetParameterData(0, &usNumber, sizeof(usNumber));
    SetParameterData(1, &usOutput, sizeof(usOutput));
}

void CCommand_VCS_Move::SetDefaultParameter_GetCurrentIs()
{
    short sCurrentIs(0);

    //ReturnParameter
    SetReturnParameterData(0, &sCurrentIs, sizeof(sCurrentIs));
}

void CCommand_VCS_Move::SetDefaultParameter_GetMovementState()
{
    BOOL oTargetReached(0);

    //Parameter

    //ReturnParameter
    SetReturnParameterData(0, &oTargetReached, sizeof(oTargetReached));
}

void CCommand_VCS_Move::SetDefaultParameter_GetPositionIs()
{
    long lPositionIs(0);

    //Parameter

    //ReturnParameter
    SetReturnParameterData(0, &lPositionIs, sizeof(lPositionIs));
}

void CCommand_VCS_Move::SetDefaultParameter_GetVelocityIs()
{
    long lVelocityIs(0);

    //Parameter

    //ReturnParameter
    SetReturnParameterData(0, &lVelocityIs, sizeof(lVelocityIs));
}

void CCommand_VCS_Move::SetDefaultParameter_GetPositionMust()
{
    long lPositionMust(0);

    //Parameter

    //ReturnParameter
    SetReturnParameterData(0, &lPositionMust, sizeof(lPositionMust));
}

void CCommand_VCS_Move::SetDefaultParameter_SetPositionMust()
{
    long lPositionMust(0);

    //Parameter
    SetParameterData(0, &lPositionMust, sizeof(lPositionMust));
}

void CCommand_VCS_Move::SetDefaultParameter_ActivateAnalogPositionSetpoint()
{
    WORD usAnalogInputNumber(0);
    float fScaling(0);
    long lOffset(0);

    //Parameter
    SetParameterData(0, &usAnalogInputNumber, sizeof(usAnalogInputNumber));
    SetParameterData(1, &fScaling, sizeof(fScaling));
    SetParameterData(2, &lOffset, sizeof(lOffset));
}

void CCommand_VCS_Move::SetDefaultParameter_DeactivateAnalogPositionSetpoint()
{
    WORD usAnalogInputNumber(0);

    //Parameter
    SetParameterData(0, &usAnalogInputNumber, sizeof(usAnalogInputNumber));
}

void CCommand_VCS_Move::SetDefaultParameter_EnableAnalogPositionSetpoint()
{
    //Parameter
}

void CCommand_VCS_Move::SetDefaultParameter_DisableAnalogPositionSetpoint()
{
    //Parameter
}

void CCommand_VCS_Move::SetDefaultParameter_ClearFault()
{
    //Parameter
}

void CCommand_VCS_Move::SetDefaultParameter_GetState()
{
    WORD usState(0);

    //Parameter

    //ReturnParameter
    SetReturnParameterData(0, &usState, sizeof(usState));
}

void CCommand_VCS_Move::SetDefaultParameter_GetDisableState()
{
    BOOL oIsDisabled(0);

    //Parameter

    //ReturnParameter
    SetReturnParameterData(0, &oIsDisabled, sizeof(oIsDisabled));
}

void CCommand_VCS_Move::SetDefaultParameter_GetEnableState()
{
    BOOL oIsEnabled(0);

    //Parameter

    //ReturnParameter
    SetReturnParameterData(0, &oIsEnabled, sizeof(oIsEnabled));
}

void CCommand_VCS_Move::SetDefaultParameter_GetFaultState()
{
    BOOL oIsInFault(0);

    //Parameter

    //ReturnParameter
    SetReturnParameterData(0, &oIsInFault, sizeof(oIsInFault));
}

void CCommand_VCS_Move::SetDefaultParameter_GetOperationMode()
{
    __int8 bMode(0);

    //Parameter

    //ReturnParameter
    SetReturnParameterData(0, &bMode, sizeof(bMode));
}

void CCommand_VCS_Move::SetDefaultParameter_GetQuickStopState()
{
    BOOL oIsQuickStoped(0);

    //Parameter

    //ReturnParameter
    SetReturnParameterData(0, &oIsQuickStoped, sizeof(oIsQuickStoped));
}

void CCommand_VCS_Move::SetDefaultParameter_SetState()
{
    WORD usState(0);

    //Parameter
    SetParameterData(0, &usState, sizeof(usState));
}

void CCommand_VCS_Move::SetDefaultParameter_SetDisableState()
{
    //Parameter
}

void CCommand_VCS_Move::SetDefaultParameter_SetEnableState()
{
    //Parameter
}

void CCommand_VCS_Move::SetDefaultParameter_SetOperationMode()
{
    __int8 bMode(0);

    //Parameter
    SetParameterData(0, &bMode, sizeof(bMode));
}

void CCommand_VCS_Move::SetDefaultParameter_SetQuickStopState()
{
    //Parameter
}

void CCommand_VCS_Move::SetDefaultParameter_GetVelocityMust()
{
    long lVelocityMust(0);

    //Parameter

    //ReturnParameter
    SetReturnParameterData(0, &lVelocityMust, sizeof(lVelocityMust));
}

void CCommand_VCS_Move::SetDefaultParameter_SetVelocityMust()
{
    long lVelocityMust(0);

    //Parameter
    SetParameterData(0, &lVelocityMust, sizeof(lVelocityMust));
}

void CCommand_VCS_Move::SetDefaultParameter_ActivateAnalogVelocitySetpoint()
{
    WORD usAnalogInputNumber(0);
    float fScaling(0);
    long lOffset(0);

    //Parameter
    SetParameterData(0, &usAnalogInputNumber, sizeof(usAnalogInputNumber));
    SetParameterData(1, &fScaling, sizeof(fScaling));
    SetParameterData(2, &lOffset, sizeof(lOffset));
}

void CCommand_VCS_Move::SetDefaultParameter_DeactivateAnalogVelocitySetpoint()
{
    WORD usAnalogInputNumber(0);

    //Parameter
    SetParameterData(0, &usAnalogInputNumber, sizeof(usAnalogInputNumber));
}

void CCommand_VCS_Move::SetDefaultParameter_EnableAnalogVelocitySetpoint()
{
    //Parameter
}

void CCommand_VCS_Move::SetDefaultParameter_DisableAnalogVelocitySetpoint()
{
    //Parameter
}

void CCommand_VCS_Move::SetDefaultParameter_GetSerialNumber()
{
    unsigned __int64 ullSerialNb(0);

    //Parameter

    //ReturnParameter
    SetReturnParameterData(0, &ullSerialNb, sizeof(ullSerialNb));
}

void CCommand_VCS_Move::SetDefaultParameter_GetBaseSectorVersion()
{
    WORD usBaseSectorVersion(0);

    //Parameter

    //ReturnParameter
    SetReturnParameterData(0, &usBaseSectorVersion, sizeof(usBaseSectorVersion));
}
#endif //_MMC_VCS_MOVE
