// CommandGroupStandard_VCS_Move.cpp: Implementierung der Klasse CCommandGroupStandard_VCS_Move.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CommandGroupStandard_VCS_Move.h"
#ifdef _MMC_VCS_MOVE

#include "../../CommandSets/Move/CommandSetConfiguration_VCS_Move.h"
#include "../../CommandSets/Move/CommandSetConfigurationMotor_VCS_Move.h"
#include "../../CommandSets/Move/CommandSetConfigurationSensor_VCS_Move.h"
#include "../../CommandSets/Move/CommandSetCurrentMode_VCS_Move.h"
#include "../../CommandSets/Move/CommandSetInputsOutputs_VCS_Move.h"
#include "../../CommandSets/Move/CommandSetMotionInfo_VCS_Move.h"
#include "../../CommandSets/Move/CommandSetPositionMode_VCS_Move.h"
#include "../../CommandSets/Move/CommandSetStateMachine_VCS_Move.h"
#include "../../CommandSets/Move/CommandSetVelocityMode_VCS_Move.h"
#include "../../CommandSets/CanOpen/CommandSetObjectDictionary_VCS_CanOpen.h"
#include "../../CommandSets/CanOpen/CommandSetGeneralGateway_VCS_CanOpen.h"
#include "../../CommandSets/CanOpen/CommandSetLayerSettingServices_VCS_CanOpen.h"
#include "../../CommandSets/Common/CommandSetErrorHandling_VCS_Common.h"
#include "../../CommandSets/Common/CommandSetVersion_VCS_Common.h"
#include "../../CommandSets/DataRecorder/CommandSetDataRecording_VCS_DataRecorder.h"
#include "../BaseClasses/CommandGroupBase_VCS.h"

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

CCommandGroupStandard_VCS_Move::CCommandGroupStandard_VCS_Move()
{
    m_strCommandGroupName = COMMAND_GROUP_STANDARD;
    FillSetList();
}

CCommandGroupStandard_VCS_Move::~CCommandGroupStandard_VCS_Move()
{
    DeleteSetList();
}

void CCommandGroupStandard_VCS_Move::FillSetList()
{
    m_pCommandSetConfiguration              = new CCommandSetConfiguration_VCS_Move();
    m_pCommandSetConfigurationMotor         = new CCommandSetConfigurationMotor_VCS_Move();
    m_pCommandSetConfigurationSensor        = new CCommandSetConfigurationSensor_VCS_Move();
    m_pCommandSetCurrentMode                = new CCommandSetCurrentMode_VCS_Move();
    m_pCommandSetInputsOutputs       = 0;//       = new CCommandSetInputsOutputs_VCS_Move();
    m_pCommandSetMotionInfo          = 0;//       = new CCommandSetMotionInfo_VCS_Move();
    m_pCommandSetPositionMode        = 0;//       = new CCommandSetPositionMode_VCS_Move();
    m_pCommandSetStateMachine        = 0;//       = new CCommandSetStateMachine_VCS_Move();
    m_pCommandSetVelocityMode        = 0;//       = new CCommandSetVelocityMode_VCS_Move();

    m_pCommandSetObjectDictionary            = new CCommandSetObjectDictionary_VCS_CanOpen();
    m_pCommandSetGeneralGateway             = new CCommandSetGeneralGateway_VCS_CanOpen();

    m_pCommandSetErrorHandling                = new CCommandSetErrorHandling_VCS_Common();
    m_pCommandSetVersion                    = new CCommandSetVersion_VCS_Common();

    m_pCommandSetDataRecording        = 0;//      = new CCommandSetDataRecording_VCS_DataRecorder();
}

void CCommandGroupStandard_VCS_Move::DeleteSetList()
{
    if(m_pCommandSetConfiguration)
    {
        delete m_pCommandSetConfiguration;
        m_pCommandSetConfiguration = 0;
    }
    if(m_pCommandSetConfigurationMotor)
    {
        delete m_pCommandSetConfigurationMotor;
        m_pCommandSetConfigurationMotor = 0;
    }
    if(m_pCommandSetConfigurationSensor)
    {
        delete m_pCommandSetConfigurationSensor;
        m_pCommandSetConfigurationSensor = 0;
    }
    if(m_pCommandSetCurrentMode)
    {
        delete m_pCommandSetCurrentMode;
        m_pCommandSetCurrentMode = 0;
    }
    if(m_pCommandSetInputsOutputs)
    {
        delete m_pCommandSetInputsOutputs;
        m_pCommandSetInputsOutputs = 0;
    }
    if(m_pCommandSetMotionInfo)
    {
        delete m_pCommandSetMotionInfo;
        m_pCommandSetMotionInfo = 0;
    }
    if(m_pCommandSetPositionMode)
    {
        delete m_pCommandSetPositionMode;
        m_pCommandSetPositionMode = 0;
    }
    if(m_pCommandSetStateMachine)
    {
        delete m_pCommandSetStateMachine;
        m_pCommandSetStateMachine = 0;
    }
    if(m_pCommandSetVelocityMode)
    {
        delete m_pCommandSetVelocityMode;
        m_pCommandSetVelocityMode = 0;
    }
    if(m_pCommandSetGeneralGateway)
    {
        delete m_pCommandSetGeneralGateway;
        m_pCommandSetGeneralGateway = 0;
    }
    if(m_pCommandSetDataRecording)
    {
        delete m_pCommandSetDataRecording;
        m_pCommandSetDataRecording = 0;
    }
    if(m_pCommandSetObjectDictionary)
    {
        delete m_pCommandSetObjectDictionary;
        m_pCommandSetObjectDictionary = 0;
    }
    if(m_pCommandSetErrorHandling)
    {
        delete m_pCommandSetErrorHandling;
        m_pCommandSetErrorHandling = 0;
    }
    if(m_pCommandSetVersion)
    {
        delete m_pCommandSetVersion;
        m_pCommandSetVersion = 0;
    }
}

CXXMLFile::CElementPart* CCommandGroupStandard_VCS_Move::StoreToXMLFile(CXXMLFile* p_pFile, CXXMLFile::CElementPart* p_pParentElement)
{
    CXXMLFile::CElement* pElement = 0;

    if(p_pFile && p_pParentElement)
    {
        //CommandGroup Elements
        pElement = (CXXMLFile::CElement*)p_pFile->AddElement(p_pParentElement);
        p_pFile->SetText(pElement, "CommandGroup");
        pElement->AttributeToValue["Name"] = m_strCommandGroupName;

        //CommandSet Elements
        if(m_pCommandSetConfiguration && !m_pCommandSetConfiguration->StoreToXMLFile(p_pFile, pElement)) return pElement;
        if(m_pCommandSetConfigurationMotor && !m_pCommandSetConfigurationMotor->StoreToXMLFile(p_pFile, pElement)) return pElement;
        if(m_pCommandSetConfigurationSensor && !m_pCommandSetConfigurationSensor->StoreToXMLFile(p_pFile, pElement)) return pElement;
        if(m_pCommandSetCurrentMode && !m_pCommandSetCurrentMode->StoreToXMLFile(p_pFile, pElement)) return pElement;
        if(m_pCommandSetPositionMode && !m_pCommandSetPositionMode->StoreToXMLFile(p_pFile, pElement)) return pElement;
        if(m_pCommandSetVelocityMode && !m_pCommandSetVelocityMode->StoreToXMLFile(p_pFile, pElement)) return pElement;
        if(m_pCommandSetMotionInfo && !m_pCommandSetMotionInfo->StoreToXMLFile(p_pFile, pElement)) return pElement;
        if(m_pCommandSetInputsOutputs && !m_pCommandSetInputsOutputs->StoreToXMLFile(p_pFile, pElement)) return pElement;
        if(m_pCommandSetStateMachine && !m_pCommandSetStateMachine->StoreToXMLFile(p_pFile, pElement)) return pElement;

        if(m_pCommandSetObjectDictionary && !m_pCommandSetObjectDictionary->StoreToXMLFile(p_pFile, pElement)) return pElement;
        if(m_pCommandSetGeneralGateway && !m_pCommandSetGeneralGateway->StoreToXMLFile(p_pFile, pElement)) return pElement;

        if(m_pCommandSetErrorHandling && !m_pCommandSetErrorHandling->StoreToXMLFile(p_pFile, pElement)) return pElement;
        if(m_pCommandSetVersion && !m_pCommandSetVersion->StoreToXMLFile(p_pFile, pElement)) return pElement;

        if(m_pCommandSetDataRecording && !m_pCommandSetDataRecording->StoreToXMLFile(p_pFile, pElement)) return pElement;
    }

    return pElement;
}

void CCommandGroupStandard_VCS_Move::InitJournalManager(CJournalManagerBase *p_pJournalManager)
{
    if(m_pCommandSetConfiguration) m_pCommandSetConfiguration->InitJournalManager(p_pJournalManager);
    if(m_pCommandSetConfigurationMotor) m_pCommandSetConfigurationMotor->InitJournalManager(p_pJournalManager);
    if(m_pCommandSetConfigurationSensor) m_pCommandSetConfigurationSensor->InitJournalManager(p_pJournalManager);
    if(m_pCommandSetCurrentMode) m_pCommandSetCurrentMode->InitJournalManager(p_pJournalManager);
    if(m_pCommandSetInputsOutputs) m_pCommandSetInputsOutputs->InitJournalManager(p_pJournalManager);
    if(m_pCommandSetMotionInfo) m_pCommandSetMotionInfo->InitJournalManager(p_pJournalManager);
    if(m_pCommandSetPositionMode) m_pCommandSetPositionMode->InitJournalManager(p_pJournalManager);
    if(m_pCommandSetStateMachine) m_pCommandSetStateMachine->InitJournalManager(p_pJournalManager);
    if(m_pCommandSetVelocityMode) m_pCommandSetVelocityMode->InitJournalManager(p_pJournalManager);

    if(m_pCommandSetObjectDictionary) m_pCommandSetObjectDictionary->InitJournalManager(p_pJournalManager);
    if(m_pCommandSetGeneralGateway) m_pCommandSetGeneralGateway->InitJournalManager(p_pJournalManager);

    if(m_pCommandSetErrorHandling) m_pCommandSetErrorHandling->InitJournalManager(p_pJournalManager);
    if(m_pCommandSetVersion) m_pCommandSetVersion->InitJournalManager(p_pJournalManager);

    if(m_pCommandSetDataRecording) m_pCommandSetDataRecording->InitJournalManager(p_pJournalManager);
}

void CCommandGroupStandard_VCS_Move::ResetJournalManager()
{
    if(m_pCommandSetConfiguration) m_pCommandSetConfiguration->ResetJournalManager();
    if(m_pCommandSetConfigurationMotor) m_pCommandSetConfigurationMotor->ResetJournalManager();
    if(m_pCommandSetConfigurationSensor) m_pCommandSetConfigurationSensor->ResetJournalManager();
    if(m_pCommandSetCurrentMode) m_pCommandSetCurrentMode->ResetJournalManager();
    if(m_pCommandSetInputsOutputs) m_pCommandSetInputsOutputs->ResetJournalManager();
    if(m_pCommandSetMotionInfo) m_pCommandSetMotionInfo->ResetJournalManager();
    if(m_pCommandSetPositionMode) m_pCommandSetPositionMode->ResetJournalManager();
    if(m_pCommandSetStateMachine) m_pCommandSetStateMachine->ResetJournalManager();
    if(m_pCommandSetVelocityMode) m_pCommandSetVelocityMode->ResetJournalManager();

    if(m_pCommandSetObjectDictionary) m_pCommandSetObjectDictionary->ResetJournalManager();
    if(m_pCommandSetGeneralGateway) m_pCommandSetGeneralGateway->ResetJournalManager();

    if(m_pCommandSetErrorHandling) m_pCommandSetErrorHandling->ResetJournalManager();
    if(m_pCommandSetVersion) m_pCommandSetVersion->ResetJournalManager();

    if(m_pCommandSetDataRecording) m_pCommandSetDataRecording->ResetJournalManager();
}

BOOL CCommandGroupStandard_VCS_Move::InitGateway(CGateway *p_pGateway)
{
    if(m_pCommandSetConfiguration && !m_pCommandSetConfiguration->InitGateway(p_pGateway)) return 0;
    if(m_pCommandSetConfigurationMotor && !m_pCommandSetConfigurationMotor->InitGateway(p_pGateway)) return 0;
    if(m_pCommandSetConfigurationSensor && !m_pCommandSetConfigurationSensor->InitGateway(p_pGateway)) return 0;
    if(m_pCommandSetCurrentMode && !m_pCommandSetCurrentMode->InitGateway(p_pGateway)) return 0;
    if(m_pCommandSetInputsOutputs && !m_pCommandSetInputsOutputs->InitGateway(p_pGateway)) return 0;
    if(m_pCommandSetMotionInfo && !m_pCommandSetMotionInfo->InitGateway(p_pGateway)) return 0;
    if(m_pCommandSetPositionMode && !m_pCommandSetPositionMode->InitGateway(p_pGateway)) return 0;
    if(m_pCommandSetStateMachine && !m_pCommandSetStateMachine->InitGateway(p_pGateway)) return 0;
    if(m_pCommandSetVelocityMode && !m_pCommandSetVelocityMode->InitGateway(p_pGateway)) return 0;

    if(m_pCommandSetObjectDictionary && !m_pCommandSetObjectDictionary->InitGateway(p_pGateway)) return 0;
    if(m_pCommandSetGeneralGateway && !m_pCommandSetGeneralGateway->InitGateway(p_pGateway)) return 0;

    if(m_pCommandSetErrorHandling && !m_pCommandSetErrorHandling->InitGateway(p_pGateway)) return 0;
    if(m_pCommandSetVersion && !m_pCommandSetVersion->InitGateway(p_pGateway)) return 0;

    if(m_pCommandSetDataRecording && !m_pCommandSetDataRecording->InitGateway(p_pGateway)) return 0;

    return 1;
}
#endif //_MMC_VCS_MOVE
