// Port_HID.cpp: Implementierung der Klasse CPort_HID.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Port_HID.h"

#ifdef _MMC_I_HID

#include <CommunicationModel/CommonLayer/Classes/Commands/Interface/BaseClasses/Command_I.h>
#include <CommunicationModel/CommonLayer/Classes/Commands/Interface/Command_I_USB.h>
#include "../Gateway/HID/GatewayUsbToHidDrv.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

CPort_HID::CPort_HID()
{
    InitErrorHandling();

    m_strInterfacePortName = INTERFACE_PORT_HID;

    m_pCommand_WriteData = 0;
    m_pCommand_ReadData = 0;
    InitCommands();

    SetDefault();
}

CPort_HID::CPort_HID(CPort_HID& p_rObject):CPortBase(p_rObject)
{
    InitErrorHandling();

    m_strInterfacePortName = p_rObject.m_strInterfacePortName;
    p_rObject.ResetPortMembers();

    m_pCommand_WriteData = 0;
    m_pCommand_ReadData = 0;

    InitCommands();
    InitJournalManager(p_rObject.m_pJournalManager);
}

CPort_HID::~CPort_HID()
{
    DeleteCommands();
}

CPortBase* CPort_HID::Clone()
{
    CPortBase* pPortBase = new CPort_HID(*this);
    return pPortBase;
}

void CPort_HID::SetDefault()
{
    m_strPortName = "";
}

BOOL CPort_HID::operator==(const CPort_HID& p_rPort)
{
    return (m_strPortName.CompareNoCase(p_rPort.m_strPortName) == 0);
}

CPort_HID& CPort_HID::operator=(CPort_HID& p_rSetting)
{
    if(this != &p_rSetting)
    {
        m_strPortName = p_rSetting.m_strPortName;
    }
    return *this;
}

void CPort_HID::ResetPortMembers()
{
    m_strPortName = "";
}

BOOL CPort_HID::I_WriteData(HANDLE p_hTransactionHandle, void* p_pData, DWORD p_ulNumberOfBytesToWrite, DWORD* p_pulNumberOfBytesWritten, CErrorInfo* p_pErrorInfo)
{
    CLayerManagerBase* pLayerManager(0);
    HANDLE hHandle(0);
    BOOL oResult(0);

    if(m_pCommand_WriteData)
    {
        //Set Parameter Data
        m_pCommand_WriteData->ResetStatus();
        m_pCommand_WriteData->SetParameterData(0, p_pData, p_ulNumberOfBytesToWrite);

        //Execute Command
        oResult = m_pCommand_WriteData->Execute(pLayerManager, hHandle, p_hTransactionHandle);

        //Get ReturnParameter Data
        m_pCommand_WriteData->GetReturnParameterData(0, p_pulNumberOfBytesWritten, sizeof(*p_pulNumberOfBytesWritten));

        //Get ErrorCode
        m_pCommand_WriteData->GetErrorInfo(p_pErrorInfo);
    }

    return oResult;
}

BOOL CPort_HID::I_ReadData(HANDLE p_hTransactionHandle, void* p_pData, DWORD p_ulNumberOfBytesToRead, DWORD* p_pulNumberOfBytesRead, CErrorInfo* p_pErrorInfo)
{
    CLayerManagerBase* pLayerManager(0);
    HANDLE hHandle(0);
    BOOL oResult(0);
    DWORD ulDataLength(0);

    if(m_pCommand_ReadData)
    {
        //Set Parameter Data
        m_pCommand_ReadData->ResetStatus();
        m_pCommand_ReadData->SetParameterData(0, &p_ulNumberOfBytesToRead, sizeof(p_ulNumberOfBytesToRead));

        //Execute Command
        oResult = m_pCommand_ReadData->Execute(pLayerManager, hHandle, p_hTransactionHandle);

        //Limit Parameter Length
        ulDataLength = m_pCommand_ReadData->GetReturnParameterLength(0);
        if(ulDataLength > p_ulNumberOfBytesToRead) ulDataLength = p_ulNumberOfBytesToRead;

        //Get ReturnParameter Data
        m_pCommand_ReadData->GetReturnParameterData(0, p_pData, ulDataLength);
        if(p_pulNumberOfBytesRead) *p_pulNumberOfBytesRead = ulDataLength;

        //Get ErrorCode
        m_pCommand_ReadData->GetErrorInfo(p_pErrorInfo);
    }

    return oResult;
}

void CPort_HID::InitCommands()
{
    DeleteCommands();

    //Init Command WriteData
    m_pCommand_WriteData = new CCommand_I_USB();
    m_pCommand_WriteData->InitCommand(USB_WRITE_DATA);

    //Init Command ReadData
    m_pCommand_ReadData = new CCommand_I_USB();
    m_pCommand_ReadData->InitCommand(USB_READ_DATA);
}

BOOL CPort_HID::GetCommands(CStdString* p_pCommandInfo)
{
    CXXMLFile xmlFile;
    CXXMLFile::CElementPart* pElementPart;
    CXXMLFile::CElement* pElement;
    BOOL oResult(1);

    if(p_pCommandInfo)
    {
        //Root
        pElementPart = xmlFile.Root();
        if(!xmlFile.IsElement(pElementPart)) return 0;

        //CommandInfo Elements
        pElement = (CXXMLFile::CElement*)xmlFile.AddElement(pElementPart);
        xmlFile.SetText(pElement, "CommandInfo");

        //CommandGroup Elements
        pElement = (CXXMLFile::CElement*)xmlFile.AddElement(pElement);
        xmlFile.SetText(pElement, "CommandGroup");
        pElement->AttributeToValue["Name"]=m_strPortName;

        //Command Elements
        if(m_pCommand_ReadData && !m_pCommand_ReadData->StoreToXMLFile(&xmlFile, pElement, 1)) return 0;
        if(m_pCommand_WriteData && !m_pCommand_WriteData->StoreToXMLFile(&xmlFile, pElement, 1)) return 0;

        //Write to string
        xmlFile.WriteToString(p_pCommandInfo);
        return oResult;
    }

    return 0;
}

void CPort_HID::DeleteCommands()
{
    if(m_pCommand_ReadData)
    {
        delete m_pCommand_ReadData;
        m_pCommand_ReadData = 0;
    }

    if(m_pCommand_WriteData)
    {
        delete m_pCommand_WriteData;
        m_pCommand_WriteData = 0;
    }
}

void CPort_HID::InitJournalManager(CJournalManagerBase *p_pJournalManager)
{
    CPortBase::InitJournalManager(p_pJournalManager);
    if(m_pCommand_WriteData) m_pCommand_WriteData->InitJournalManager(p_pJournalManager);
    if(m_pCommand_ReadData) m_pCommand_ReadData->InitJournalManager(p_pJournalManager);
}

void CPort_HID::ResetJournalManager()
{
    CPortBase::ResetJournalManager();
    if(m_pCommand_WriteData) m_pCommand_WriteData->ResetJournalManager();
    if(m_pCommand_ReadData) m_pCommand_ReadData->ResetJournalManager();
}

void CPort_HID::InitCommands(CGatewayIToDrv* p_pGateway)
{
    if(m_pCommand_WriteData) m_pCommand_WriteData->InitGateway(p_pGateway);
    if(m_pCommand_ReadData) m_pCommand_ReadData->InitGateway(p_pGateway);
}

BOOL CPort_HID::InitGateway(CGatewayIToDrv* p_pGateway)
{
    BOOL oResult(0);

    if(CPortBase::InitGateway(p_pGateway))
    {
        InitParameterSet();
        oResult = 1;
    }

    return oResult;
}

BOOL CPort_HID::InitParameterSet()
{
    BOOL oResult(0);

    if(m_pGateway)
    {
        oResult = 1;
        if(oResult) oResult &= m_pGateway->ResetParameterSet();
    }

    return oResult;
}

BOOL CPort_HID::InitErrorHandling()
{
    CErrorProducer errorProducer;
    CStdString strClassName(_T("Port_HID"));

    if(m_pErrorHandling)
    {
        //Init ErrorProducer
        errorProducer.Init(INTERFACE_LAYER, strClassName);
        m_pErrorHandling->InitErrorProducer(&errorProducer);
        return 1;
    }

    return 0;
}
#endif //_MMC_I_HID
