// ErrorHandling.cpp: Implementierung der Klasse CErrorHandling.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <CommunicationModel/CommonLayer/ErrorHandling/ErrorHandling.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

CErrorHandling::CErrorHandling()
{
    m_pErrorProducer = NULL;
}

CErrorHandling::~CErrorHandling()
{
    DeleteErrorProducer();
}

void CErrorHandling::DeleteErrorProducer()
{
    if(m_pErrorProducer)
    {
        delete m_pErrorProducer;
        m_pErrorProducer = NULL;
    }
}

BOOL CErrorHandling::GetErrorDescription(DWORD dErrorCode, CStdString *pDescription)
{
    if(pDescription)
    {
        if(GetErrorDescription_GeneralError(dErrorCode, pDescription)) return TRUE;
        if(GetErrorDescription_I(dErrorCode, pDescription)) return TRUE;
        if(GetErrorDescription_PS(dErrorCode, pDescription)) return TRUE;
        if(GetErrorDescription_DCS(dErrorCode, pDescription)) return TRUE;
        if(GetErrorDescription_VCS(dErrorCode, pDescription)) return TRUE;

        if(pDescription) *pDescription = "Unknown Error";
    }

    return FALSE;
}

BOOL CErrorHandling::GetErrorDescription_I(DWORD dErrorCode, CStdString *pDescription)
{
    switch(dErrorCode)
    {
        case k_Error_I_OpeningInterface:    *pDescription = "Error opening interface"; return TRUE;
        case k_Error_I_ClosingInterface:    *pDescription = "Error closing interface"; return TRUE;
        case k_Error_I_InterfaceNotOpen:    *pDescription = "Interface is not open"; return TRUE;
        case k_Error_I_OpeningPort:         *pDescription = "Error opening port"; return TRUE;
        case k_Error_I_ClosingPort:         *pDescription = "Error closing port"; return TRUE;
        case k_Error_I_PortNotOpen:         *pDescription = "Port is not open"; return TRUE;
        case k_Error_I_ResetPort:           *pDescription = "Error resetting port"; return TRUE;
        case k_Error_I_SetPortSettings:     *pDescription = "Error configuring port settings"; return TRUE;
        case k_Error_I_SetPortMode:         *pDescription = "Error configuring port mode"; return TRUE;
    }

    if(GetErrorDescription_I_RS232(dErrorCode, pDescription)) return TRUE;
    if(GetErrorDescription_I_CAN(dErrorCode, pDescription)) return TRUE;
    if(GetErrorDescription_I_USB(dErrorCode, pDescription)) return TRUE;

    return FALSE;
}

BOOL CErrorHandling::GetErrorDescription_PS(DWORD dErrorCode, CStdString *pDescription)
{
    if(GetErrorDescription_PS_MaxonSerialV1(dErrorCode, pDescription)) return TRUE;
    if(GetErrorDescription_PS_CANopen(dErrorCode, pDescription)) return TRUE;
    if(GetErrorDescription_PS_InfoteamSerial(dErrorCode, pDescription)) return TRUE;
    if(GetErrorDescription_PS_MaxonSerialV2(dErrorCode, pDescription)) return TRUE;

    return FALSE;
}

BOOL CErrorHandling::GetErrorDescription_DCS(DWORD dErrorCode, CStdString *pDescription)
{
    if(GetErrorDescription_DCS_DeviceEpos(dErrorCode, pDescription)) return TRUE;
    if(GetErrorDescription_DCS_OldDeviceEpos(dErrorCode, pDescription)) return TRUE;

    return FALSE;
}

BOOL CErrorHandling::GetErrorDescription_VCS(DWORD dErrorCode, CStdString *pDescription)
{
    if(GetErrorDescription_VCS_VirtualDevice(dErrorCode, pDescription)) return TRUE;

    return FALSE;
}

BOOL CErrorHandling::GetErrorDescription_GeneralError(DWORD dErrorCode, CStdString *pDescription)
{
    switch(dErrorCode)
    {
        case k_NoError:                         *pDescription = (_T("No Error")); return TRUE;
        case k_Error_Internal:                  *pDescription = (_T("Internal Error")); return TRUE;
        case k_Error_NullPointer:               *pDescription = (_T("Null Pointer")); return TRUE;
        case k_Error_HandleNotValid:            *pDescription = (_T("Handle is not valid")); return TRUE;
        case k_Error_BadVirtualDeviceName:      *pDescription = (_T("Bad Virtual Device Name")); return TRUE;
        case k_Error_BadDeviceName:             *pDescription = (_T("Bad Device Name")); return TRUE;
        case k_Error_BadProtocolStackName:      *pDescription = (_T("Bad ProtocolStack Name")); return TRUE;
        case k_Error_BadInterfaceName:          *pDescription = (_T("Bad Interface Name")); return TRUE;
        case k_Error_BadPortName:               *pDescription = (_T("Bad Port Name")); return TRUE;
        case k_Error_LibraryNotLoaded:          *pDescription = (_T("Driver Library is not loaded")); return TRUE;
        case k_Error_ExecutingCommand:          *pDescription = (_T("Error executing Command")); return TRUE;
        case k_Error_Timeout:                   *pDescription = (_T("Timeout executing Command")); return TRUE;
        case k_Error_BadParameter:              *pDescription = (_T("Bad Parameter")); return TRUE;
        case k_Error_CommandAbortedByUser:      *pDescription = (_T("Command aborted by user!")); return TRUE;
        case k_Error_BufferTooSmall:            *pDescription = (_T("Buffer is too small!")); return TRUE;
        case k_Error_NoCommunicationFound:      *pDescription = (_T("No communication settings found!")); return TRUE;
        case k_Error_FunctionNotSupported:      *pDescription = (_T("Function not supported")); return TRUE;
        case k_Error_ParameterAlreadyUsed:      *pDescription = (_T("Parameter already used")); return TRUE;
        case k_Error_BadVirtualDeviceHandle:    *pDescription = (_T("Bad Virtual Device Handle")); return TRUE;
        case k_Error_BadDeviceHandle:           *pDescription = (_T("Bad Device Handle")); return TRUE;
        case k_Error_BadProtocolStackHandle:    *pDescription = (_T("Bad Protocol Stack Handle")); return TRUE;
        case k_Error_BadInterfaceHandle:        *pDescription = (_T("Bad Interface Handle")); return TRUE;
        case k_Error_BadPortHandle:             *pDescription = (_T("Bad Port Handle")); return TRUE;
        case k_Error_BadAddressParameter:       *pDescription = (_T("Address Parameters are not correct")); return TRUE;
        case k_Error_BadVariableInfoFile:       *pDescription = (_T("Variable Info File is not initialized")); return TRUE;
        case k_Error_VariableNameNotFound:      *pDescription = (_T("Variable Name not found")); return TRUE;
        default: return FALSE;
    }
}

BOOL CErrorHandling::GetErrorDescription_I_RS232(DWORD dErrorCode, CStdString *pDescription)
{
    switch(dErrorCode)
    {
        case k_Error_RS232_WriteData:           *pDescription = "Error writing RS232 Data"; return TRUE;
        case k_Error_RS232_ReadData:            *pDescription = "Error reading RS232 Data"; return TRUE;
        default: return FALSE;
    }
}

BOOL CErrorHandling::GetErrorDescription_I_USB(DWORD dErrorCode, CStdString *pDescription)
{
    switch(dErrorCode)
    {
        case k_Error_USB_WriteData:             *pDescription = "Error writing USB Data"; return TRUE;
        case k_Error_USB_ReadData:              *pDescription = "Error reading USB Data"; return TRUE;
        case k_Error_USB_Rescan:                *pDescription = "Error Rescanning USB Devices"; return TRUE;
        case k_Error_USB_Reload:                *pDescription = "Error Reloading USB Devices"; return TRUE;
        default: return FALSE;
    }
}

BOOL CErrorHandling::GetErrorDescription_I_CAN(DWORD dErrorCode, CStdString *pDescription)
{
    switch(dErrorCode)
    {
        case k_Error_CAN_ReceiveCanFrame:       *pDescription = "Error receiving CAN Frame"; return TRUE;
        case k_Error_CAN_TransmitCanFrame:      *pDescription = "Error transmitting CAN Frame"; return TRUE;
        default: return FALSE;
    }
}


BOOL CErrorHandling::GetErrorDescription_PS_MaxonSerialV1(DWORD dErrorCode, CStdString *pDescription)
{
    switch(dErrorCode)
    {
        case k_Error_MaxonSerialV1_NegAckReceived:      *pDescription = "Maxon Serial V1 Protocol - Negative Acknowledge received"; return TRUE;
        case k_Error_MaxonSerialV1_BadCrcReceived:      *pDescription = "Maxon Serial V1  Protocol - Bad CRC received"; return TRUE;
        case k_Error_MaxonSerialV1_BadDataSizeReceived: *pDescription = "Maxon Serial V1  Protocol - Bad Data received"; return TRUE;
        default: return FALSE;
    }
}

BOOL CErrorHandling::GetErrorDescription_PS_InfoteamSerial(DWORD dErrorCode, CStdString *pDescription)
{
    switch(dErrorCode)
    {
        case k_Error_InfoteamSerial_BadAckReceived:         *pDescription = "Infoteam Serial Protocol - Bad Acknowledge received"; return TRUE;
        case k_Error_InfoteamSerial_RepAckReceived:         *pDescription = "Infoteam Serial Protocol - Repeat Acknowledge received"; return TRUE;
        case k_Error_InfoteamSerial_BadCrcReceived:         *pDescription = "Infoteam Serial Protocol - Bad CRC received"; return TRUE;
        case k_Error_InfoteamSerial_BadDataSizeReceived:    *pDescription = "Infoteam Serial Protocol - Bad Data received"; return TRUE;
        case k_Error_InfoteamSerial_ChunkSizeTooHigh:       *pDescription = "Infoteam Serial Protocol - Chunk Size too hihg"; return TRUE;
        default: return FALSE;
    }
}

BOOL CErrorHandling::GetErrorDescription_PS_MaxonSerialV2(DWORD dErrorCode, CStdString *pDescription)
{
    switch(dErrorCode)
    {
        case k_Error_MaxonSerialV2_Stuffing:                *pDescription = "Maxon Serial V2 Protocol - Failed Stuffing Data"; return TRUE;
        case k_Error_MaxonSerialV2_Destuffing:              *pDescription = "Maxon Serial V2 Protocol - Failed Destuffing Data"; return TRUE;
        case k_Error_MaxonSerialV2_BadCrcReceived:          *pDescription = "Maxon Serial V2 Protocol - Bad CRC received"; return TRUE;
        case k_Error_MaxonSerialV2_BadDataSizeReceived:     *pDescription = "Maxon Serial V2 Protocol - Bad Data Size received"; return TRUE;
        case k_Error_MaxonSerialV2_BadDataSizeWritten:      *pDescription = "Maxon Serial V2 Protocol - Bad Data Size written"; return TRUE;
        default: return FALSE;
    }
}

BOOL CErrorHandling::GetErrorDescription_PS_CANopen(DWORD dErrorCode, CStdString *pDescription)
{
    switch(dErrorCode)
    {
        case k_Error_CANopen_SdoReceiveFrameNotReceived:    *pDescription = "CANopen Protocol - SDO Response Frame not received"; return TRUE;
        case k_Error_CANopen_RequestedCanFrameNotReceived:  *pDescription = "CANopen Protocol - Requested Can Frame not received"; return TRUE;
        case k_Error_CANopen_CanFrameNotReceived:           *pDescription = "CANopen Protocol - Can Frame not received"; return TRUE;
        default: return FALSE;
    }
}

BOOL CErrorHandling::GetErrorDescription_DCS_DeviceEpos(DWORD dErrorCode, CStdString *pDescription)
{
    switch(dErrorCode)
    {
		case k_Error_DeviceEpos_Toggle:									*pDescription = "Toggle Error"; return TRUE;
		case k_Error_DeviceEpos_SDOTimeOut:								*pDescription = "SDO Protocol Timeout"; return TRUE;
		case k_Error_DeviceEpos_ClientServer:							*pDescription = "Command Specifier not valid or unknown"; return TRUE;
		case k_Error_DeviceEpos_InvalidBlockSize:						*pDescription = "Invalid Block Size"; return TRUE;
		case k_Error_DeviceEpos_InvalidSequence:						*pDescription = "Invalid Sequence Number"; return TRUE;
		case k_Error_DeviceEpos_CrcErr:									*pDescription = "Crc Error"; return TRUE;
		case k_Error_DeviceEpos_OutOfMemory:							*pDescription = "Out of Memory"; return TRUE;
        case k_Error_DeviceEpos_Access:									*pDescription = "Access denied"; return TRUE;
        case k_Error_DeviceEpos_WriteOnly:								*pDescription = "Object is WriteOnly"; return TRUE;
        case k_Error_DeviceEpos_ReadOnly:								*pDescription = "Object is ReadOnly"; return TRUE;
		case k_Error_DeviceEpos_ObjectNotExist:							*pDescription = "Object does not exist"; return TRUE;
		case k_Error_DeviceEpos_PDOMapping:								*pDescription = "Error PDO Mapping"; return TRUE;
        case k_Error_DeviceEpos_PDOLength:								*pDescription = "Error PDO Length"; return TRUE;
        case k_Error_DeviceEpos_GeneralParameter:						*pDescription = "Parameter Error"; return TRUE;
        case k_Error_DeviceEpos_GeneralInternIncompatibility:			*pDescription = "Internal Incompatibility"; return TRUE;
        case k_Error_DeviceEpos_Hardware:								*pDescription = "Hardware Error"; return TRUE;
        case k_Error_DeviceEpos_ServiceParameter:						*pDescription = "Service Parameter Error"; return TRUE;
        case k_Error_DeviceEpos_ServiceParameterToHigh:					*pDescription = "Service Parameter is too high"; return TRUE;
        case k_Error_DeviceEpos_ServiceParameterToLow:					*pDescription = "Service Parameter is too low"; return TRUE;
        case k_Error_DeviceEpos_SubObject:								*pDescription = "SubObject does not exist"; return TRUE;
		case k_Error_DeviceEpos_ValueRange:								*pDescription = "Value Range Error"; return TRUE;
        case k_Error_DeviceEpos_ValueToHigh:							*pDescription = "Value is too high"; return TRUE;
        case k_Error_DeviceEpos_ValueToLow:								*pDescription = "Value is too low"; return TRUE;
        case k_Error_DeviceEpos_MaxLessMin:								*pDescription = "Max. Value is less than min. Value"; return TRUE;
        case k_Error_DeviceEpos_General:								*pDescription = "General Error"; return TRUE;
        case k_Error_DeviceEpos_TransferOrStore:						*pDescription = "Error transfering or storing data"; return TRUE;
        case k_Error_DeviceEpos_LocalControl:							*pDescription = "Error Local Control"; return TRUE;
        case k_Error_DeviceEpos_WrongDevice:							*pDescription = "Wrong Device State"; return TRUE;

		case k_Error_DeviceEpos_UnknownNetworkId:						*pDescription = "Network Id is unknown"; return TRUE;
		case k_Error_DeviceEpos_UnknownNodeId:							*pDescription = "Node Id is unknown"; return TRUE;

        case k_Error_DeviceEpos_CANId:									*pDescription = "Wrong CAN Id"; return TRUE;
		case k_Error_DeviceEpos_ServiceMode:							*pDescription = "Service Mode is needed for this operation"; return TRUE;
		case k_Error_DeviceEpos_Password:								*pDescription = "Wrong Password"; return TRUE;
		case k_Error_DeviceEpos_IllegalCommand:							*pDescription = "Illegal Command"; return TRUE;
        case k_Error_DeviceEpos_WrongNMTState:							*pDescription = "Wrong NMT State"; return TRUE;
		case k_Error_DeviceEsam2_SegmentedTransferRequired_InitDone:    *pDescription = "Segmented Transfer Required"; return TRUE;
		case k_Error_DeviceEsam2_DataHistoryBufferOverrun:				*pDescription = "Data History Buffer Overrun: Please reduce sampling rate or/and number of variables"; return TRUE;

		case k_Error_DeviceEpos_CommAborted:							*pDescription = "Communication Aborted"; return TRUE;
		case k_Error_DeviceEpos_CommOverflow:							*pDescription = "Communication Buffer Overflow"; return TRUE;
		case k_Error_DeviceEpos_SegmentedComError:						*pDescription = "Segmented Transfer Error"; return TRUE;
		case k_Error_DeviceEpos_WrongAxisNumber:						*pDescription = "Wrong Axis Number"; return TRUE;
        case k_Error_DeviceEpos_WrongCanDevice:							*pDescription = "Wrong Node Id"; return TRUE;
		case k_Error_DeviceEpos_WrongCanPort:							*pDescription = "Can Port is not valid"; return TRUE;
		case k_Error_DeviceEpos_WrongCallingParameter:					*pDescription = "Calling Parameter Error"; return TRUE;
		case k_Error_DeviceEpos_GeneralComError:						*pDescription = "General Communication Error"; return TRUE;
		case k_Error_DeviceEpos_Timeout:								*pDescription = "Communication Timeout"; return TRUE;

        default: return FALSE;
    }
}

BOOL CErrorHandling::GetErrorDescription_DCS_OldDeviceEpos(DWORD dErrorCode, CStdString *pDescription)
{
    switch(dErrorCode)
    {
        case k_Error_OldDeviceEpos_ToggleErr:               *pDescription = "Toggle Error"; return TRUE;
        case k_Error_OldDeviceEpos_SdoTimeOut:              *pDescription = "Timeout Error"; return TRUE;
        case k_Error_OldDeviceEpos_CcsErr:                  *pDescription = "Command Specifier Error"; return TRUE;
        case k_Error_OldDeviceEpos_InvalidBlockSize:        *pDescription = "Invalid Block Size"; return TRUE;
        case k_Error_OldDeviceEpos_InvalidSequenceNo:       *pDescription = "Invalid Sequence Number"; return TRUE;
        case k_Error_OldDeviceEpos_CrcErr:                  *pDescription = "Crc Error"; return TRUE;
        case k_Error_OldDeviceEpos_OutOfMemory:             *pDescription = "Out of Memory"; return TRUE;
        case k_Error_OldDeviceEpos_AccessErr:               *pDescription = "Access Error"; return TRUE;
        case k_Error_OldDeviceEpos_WriteOnly:               *pDescription = "Object is WriteOnly"; return TRUE;
        case k_Error_OldDeviceEpos_ReadOnly:                *pDescription = "Object is ReadOnly"; return TRUE;
        case k_Error_OldDeviceEpos_ObjNotExist:             *pDescription = "Object does not exist"; return TRUE;
        case k_Error_OldDeviceEpos_NoPdoObj:                *pDescription = "PDO Number Error"; return TRUE;
        case k_Error_OldDeviceEpos_PdoLengthErr:            *pDescription = "PDO Length Error"; return TRUE;
        case k_Error_OldDeviceEpos_GeneralParamErr:         *pDescription = "Parameter Error"; return TRUE;
        case k_Error_OldDeviceEpos_GeneralInternIncomp:     *pDescription = "Internal Incomp Error"; return TRUE;
        case k_Error_OldDeviceEpos_HWErr:                   *pDescription = "Hardware Error"; return TRUE;
        case k_Error_OldDeviceEpos_ServiceParamErr:         *pDescription = "Service Parameter Error"; return TRUE;
        case k_Error_OldDeviceEpos_ServiceParamTooHigh:     *pDescription = "Service Parameter too High"; return TRUE;
        case k_Error_OldDeviceEpos_ServiceParamTooLow:      *pDescription = "Service Parameter too Low"; return TRUE;
        case k_Error_OldDeviceEpos_SubIndxErr:              *pDescription = "SubIndex Error"; return TRUE;
        case k_Error_OldDeviceEpos_ValueRange:              *pDescription = "Value Range Error"; return TRUE;
        case k_Error_OldDeviceEpos_ValTooHigh:              *pDescription = "Value too High"; return TRUE;
        case k_Error_OldDeviceEpos_ValTooLow:               *pDescription = "Value too Low"; return TRUE;
        case k_Error_OldDeviceEpos_MaxLessMin:              *pDescription = "Max. less Min."; return TRUE;
        case k_Error_OldDeviceEpos_GeneralErr:              *pDescription = "General Error"; return TRUE;
        case k_Error_OldDeviceEpos_TransfOrStoreErr:        *pDescription = "Transfer or Store Error"; return TRUE;
        case k_Error_OldDeviceEpos_LocalControlErr:         *pDescription = "Local Control Error"; return TRUE;
        case k_Error_OldDeviceEpos_WrongDeviceState:        *pDescription = "Wrong Device Control State"; return TRUE;
        case k_Error_OldDeviceEpos_WrongNmtState:           *pDescription = "Wrong Nmt State"; return TRUE;
        case k_Error_OldDeviceEpos_IllegalCommand:          *pDescription = "Illegal Command"; return TRUE;
        case k_Error_OldDeviceEpos_ErrorPassword:           *pDescription = "Error Password"; return TRUE;
        case k_Error_OldDeviceEpos_ErrorLength:             *pDescription = "Error Length"; return TRUE;
        case k_Error_OldDeviceEpos_ErrorService:            *pDescription = "Error Service"; return TRUE;
        case k_Error_OldDeviceEpos_NoMoreSegments:          *pDescription = "No more segments"; return TRUE;
        case k_Error_OldDeviceEpos_SdoAbort:                *pDescription = "Sdo Abort"; return TRUE;
        case k_Error_OldDeviceEpos_ErrorCanId:              *pDescription = "Wrong CAN ID"; return TRUE;
        case k_Error_OldDeviceEpos_ErrorAdress:             *pDescription = "Error Address"; return TRUE;
        case k_Error_OldDeviceEpos_SubIndexDoesNotExist:    *pDescription = "SubIndex does not exist"; return TRUE;

        default: return FALSE;
    }
}

BOOL CErrorHandling::GetErrorDescription_VCS_VirtualDevice(DWORD dErrorCode, CStdString *pDescription)
{
    switch(dErrorCode)
    {
        case k_Error_VirtualDevice_BadObjectSizeExpected:    *pDescription = "Bad Object Size expected"; return TRUE;

        default: return FALSE;
    }
}

void CErrorHandling::InitErrorProducer(CErrorProducer *pErrorProducer)
{
    DeleteErrorProducer();
    if(pErrorProducer) m_pErrorProducer = pErrorProducer->Clone();
}

BOOL CErrorHandling::GetErrorProducerInfos(ELayer& p_rLayer, CStdString& p_rClassName, CStdString& p_rCommandName)
{
    BOOL oResult = FALSE;

    if(m_pErrorProducer)
    {
        p_rLayer = m_pErrorProducer->GetLayer();
        p_rClassName = m_pErrorProducer->GetClassName();
        p_rCommandName = m_pErrorProducer->GetCommandName();
        oResult = TRUE;
    }

    return oResult;
}

void CErrorHandling::GetError(DWORD dErrorCode, CErrorInfo* pErrorInfo)
{
    if(pErrorInfo)
    {
        pErrorInfo->Init(dErrorCode, m_pErrorProducer);
    }
}
