// PortBase.cpp: Implementierung der Klasse CPortBase.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include <CommunicationModel/CommonLayer/Classes/Commands/Interface/BaseClasses/Command_I.h>
#include "../../Gateway/BaseClasses/GatewayIToDrv.h"

#include "PortBase.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////
CPortBase::CPortBase()
{
    m_strInterfacePortName = "";
    m_strPortName = "";

    m_pJournalManager = NULL;
    m_pGateway = NULL;

    m_pErrorHandling = NULL;
    InitErrorHandling();
}

CPortBase::CPortBase(const CPortBase& rObject)
{
    //Names
    m_strInterfacePortName = rObject.m_strInterfacePortName;
    m_strPortName = rObject.m_strPortName;

    //JournalManager
    m_pJournalManager = rObject.m_pJournalManager;

    //Gateway
    if(rObject.m_pGateway) m_pGateway = (CGatewayIToDrv*)rObject.m_pGateway->Clone(); else m_pGateway = NULL;

    m_pErrorHandling = NULL;
    InitErrorHandling();
}

CPortBase::~CPortBase()
{
    DeleteGateway();
    DeleteErrorHandling();
}

//********************************************************************
BOOL CPortBase::InitErrorHandling()
{
    DeleteErrorHandling();
    m_pErrorHandling = new CErrorHandling();
    return TRUE;
}

//********************************************************************
BOOL CPortBase::DeleteErrorHandling()
{
    if(m_pErrorHandling)
    {
        delete m_pErrorHandling;
        m_pErrorHandling = NULL;
    }

    return TRUE;
}

CPortBase* CPortBase::Clone()
{
    return NULL;
}

BOOL CPortBase::IsEqual(CStdString p_PortName)
{
	BOOL oResult = FALSE;

	oResult = TRUE;
	if(oResult && (m_strPortName != p_PortName)) oResult = FALSE;
		
	return oResult;
}

//********************************************************************
BOOL CPortBase::InitGateway(CGatewayIToDrv* pGateway)
{
    DeleteGateway();
    if(pGateway)
    {
        m_pGateway = (CGatewayIToDrv*)pGateway->Clone();
        return TRUE;
    }

    return FALSE;
}

//********************************************************************
BOOL CPortBase::InitBaudrateSelection(CStdDWordArray& dBaudrateSel)
{
    BOOL oResult = FALSE;

    //Init Baudrate Selection of Gateway
    if(m_pGateway)
    {
        oResult = m_pGateway->InitBaudrateSelection(dBaudrateSel);
    }

    return oResult;
}

//********************************************************************
BOOL CPortBase::InitDefaultPortSettings(DWORD dBaudrate, DWORD dTimeout)
{
    BOOL oResult = FALSE;

    //Init Baudrate Selection of Gateway
    if(m_pGateway)
    {
        oResult = m_pGateway->InitDefaultPortSettings(dBaudrate, dTimeout);
    }

    return oResult;
}

//********************************************************************
BOOL CPortBase::IsPortNameSupported(CStdString strPortName)
{
    if(m_pGateway)
    {
        return m_pGateway->IsPortNameSupported(strPortName);
    }

    return FALSE;
}

//********************************************************************
void CPortBase::DeleteGateway()
{
    if(m_pGateway)
    {
        delete m_pGateway;
        m_pGateway = NULL;
    }
}

//Bsp.:Der InterfacePortName kann RS232, IXXAT, Vector sein
//********************************************************************
BOOL CPortBase::GetInterfacePortName(CStdString* pInterfacePortName)
{
    if(pInterfacePortName)
    {
        *pInterfacePortName = m_strInterfacePortName;
        return TRUE;
    }

    return FALSE;
}

//Bsp.:Der PortName kann COM1, COM2, CAN1... sein
//********************************************************************
BOOL CPortBase::GetPortName(CStdString* pPortName)
{
    if(pPortName)
    {
        *pPortName = m_strPortName;
        return TRUE;
    }

    return FALSE;
}

//********************************************************************
void CPortBase::InitJournalManager(CJournalManagerBase *pJournalManager)
{
    m_pJournalManager = pJournalManager;
}

//********************************************************************
void CPortBase::ResetJournalManager()
{
    m_pJournalManager = NULL;
}

//********************************************************************
BOOL CPortBase::InitJournalManager(HANDLE hHandle, CJournalManagerBase* pJournalManager)
{
    m_pJournalManager = pJournalManager;

    return FALSE;
}

//********************************************************************
BOOL CPortBase::ResetJournalManager(HANDLE hHandle)
{
    m_pJournalManager = NULL;

    return FALSE;
}

//********************************************************************
BOOL CPortBase::InitPort(WORD wBoardNumber, WORD wNbBoardWithOldDriver)
{
    if(m_pGateway)
    {
        if(m_pGateway->InitPort(wBoardNumber, wNbBoardWithOldDriver))
        {
            return InitInterfacePortName(wBoardNumber, wNbBoardWithOldDriver);
        }
    }

    return FALSE;
}

//********************************************************************
BOOL CPortBase::UpdatePort(tPortList& p_rOpenPortList)
{
    BOOL oResult = FALSE;

    if(m_pGateway)
    {
        oResult = m_pGateway->UpdatePort(p_rOpenPortList);
    }

    return oResult;
}

//********************************************************************
BOOL CPortBase::OpenPort(CStdString strPortName, CErrorInfo* pErrorInfo)
{
    if(m_pGateway)
    {
        if(m_pGateway->OpenPort(strPortName, pErrorInfo))
        {
            m_strPortName = strPortName;
            return TRUE;
        }
    }

    return FALSE;
}

//********************************************************************
BOOL CPortBase::ReopenPort(CErrorInfo* pErrorInfo)
{
    BOOL oResult = FALSE;

    if(m_pGateway)
    {
        //Reopen
        oResult = m_pGateway->ReopenPort(m_strPortName, pErrorInfo);
    }

    if(!oResult && m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
    return oResult;
}

//********************************************************************
BOOL CPortBase::ResetPort(CErrorInfo* pErrorInfo)
{
    if(m_pGateway)
    {
        return m_pGateway->ResetPort(pErrorInfo);
    }

    if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
    return FALSE;
}

//********************************************************************
BOOL CPortBase::ClosePort(CErrorInfo* pErrorInfo)
{
    if(m_pGateway)
    {
        if(m_pGateway->ClosePort(pErrorInfo))
        {
            DeleteGateway();
            return TRUE;
        }
        else
        {
            return FALSE;
        }
    }

    if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
    return FALSE;
}

//********************************************************************
BOOL CPortBase::GetPortSettings(DWORD* pdBaudrate, DWORD* pdTimeout, CErrorInfo* pErrorInfo)
{
    if(m_pGateway)
    {
        return m_pGateway->GetPortSettings(pdBaudrate, pdTimeout, pErrorInfo);
    }

    if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
    return FALSE;
}

//********************************************************************
BOOL CPortBase::SetPortSettings(DWORD dBaudrate, DWORD dTimeout, BOOL oChangeOnly, CErrorInfo* pErrorInfo)
{
    if(m_pGateway)
    {
        return m_pGateway->SetPortSettings(dBaudrate, dTimeout, oChangeOnly, pErrorInfo);
    }

    if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
    return FALSE;
}

//********************************************************************
BOOL CPortBase::GetDefaultPortSettings(DWORD* pdBaudrate, DWORD* pdTimeout, CErrorInfo* pErrorInfo)
{
    if(m_pGateway)
    {
        return m_pGateway->GetDefaultPortSettings(pdBaudrate, pdTimeout, pErrorInfo);
    }

    if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
    return FALSE;
}

//********************************************************************
BOOL CPortBase::SetDefaultPortSettings(DWORD dBaudrate, DWORD dTimeout, CErrorInfo* pErrorInfo)
{
    if(m_pGateway)
    {
        return m_pGateway->SetDefaultPortSettings(dBaudrate, dTimeout, pErrorInfo);
    }

    if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
    return FALSE;
}

//********************************************************************
BOOL CPortBase::GetPortMode(WORD* pwPortMode, CErrorInfo* pErrorInfo)
{
    if(m_pGateway)
    {
        return m_pGateway->GetPortMode(pwPortMode, pErrorInfo);
    }

    if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
    return FALSE;
}

//********************************************************************
BOOL CPortBase::SetPortMode(WORD wPortMode, CErrorInfo* pErrorInfo)
{
    if(m_pGateway)
    {
        return m_pGateway->SetPortMode(wPortMode, pErrorInfo);
    }

    if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
    return FALSE;
}

//********************************************************************
BOOL CPortBase::GetPortNameSelection(CStdStringArray* pPortSel, CErrorInfo* pErrorInfo)
{
    if(m_pGateway)
    {
        return m_pGateway->GetPortNameSelection(pPortSel, pErrorInfo);
    }

    if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
    return FALSE;
}

//********************************************************************
BOOL CPortBase::GetBaudrateSelection(CStdDWordArray* pdBaudrateSel, CErrorInfo* pErrorInfo)
{
    if(m_pGateway)
    {
        return m_pGateway->GetBaudrateSelection(pdBaudrateSel, pErrorInfo);
    }

    if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
    return FALSE;
}

//********************************************************************
BOOL CPortBase::GetPortModeSelection(CStdStringArray* pPortModeSel, CErrorInfo* pErrorInfo)
{
    if(m_pGateway)
    {
        return m_pGateway->GetPortModeSelection(pPortModeSel, pErrorInfo);
    }

    if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
    return FALSE;
}

//********************************************************************
BOOL CPortBase::InitInterfacePortName(WORD wBoardNumber, WORD wNbBoardWithOldDriver)
{
    if(m_pGateway)
    {
        return m_pGateway->InitInterfacePortName(&m_strInterfacePortName, wBoardNumber, wNbBoardWithOldDriver);
    }

    return FALSE;
}

//********************************************************************
BOOL CPortBase::ExecuteCommand(CCommandRoot* pCommand, HANDLE hTransactionHandle)
{
    BOOL oResult = FALSE;
    CLayerManagerBase* pLayerManager = NULL;
    HANDLE hHandle = 0;

    if(pCommand)
    {
        //Init References
        pCommand->InitGateway(m_pGateway);
        pCommand->InitJournalManager(m_pJournalManager);

        //Execute
        oResult = pCommand->Execute(pLayerManager, hHandle, hTransactionHandle);

        //Reset References
        pCommand->ResetGateway();
        pCommand->ResetJournalManager();
    }

    return oResult;
}

//********************************************************************
BOOL CPortBase::GetCommands(CStdString* pCommandInfo)
{
    return FALSE;
}

BOOL CPortBase::EnableTracing(CStdString p_FileName, CErrorInfo* pErrorInfo)
{
    if(m_pGateway)
    {
        return m_pGateway->EnableTracing(p_FileName, pErrorInfo);
    }

    if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
    return FALSE;
}

BOOL CPortBase::DisableTracing(CErrorInfo* pErrorInfo)
{
    if(m_pGateway)
    {
        return m_pGateway->DisableTracing(pErrorInfo);
    }

    if(m_pErrorHandling) m_pErrorHandling->GetError(k_Error_Internal, pErrorInfo);
    return FALSE;
}

BOOL CPortBase::AreParameterEqual(CPortBase* p_pPort)
{
	BOOL oResult = FALSE;

	if(p_pPort && m_pGateway)
	{
		oResult = m_pGateway->AreParameterEqual(p_pPort->m_pGateway);
	}

	return oResult;
}

BOOL CPortBase::SetParameter(CStdString p_Name, BYTE* p_pValue, DWORD p_ulSize)
{
	BOOL oResult = FALSE;

	if(m_pGateway)
	{
		oResult = m_pGateway->SetParameter(p_Name, p_pValue, p_ulSize);
	}

	return oResult;
}
	
BOOL CPortBase::SetParameter(CStdString p_Name, CStdString p_Value)
{
	BOOL oResult = FALSE;

	if(m_pGateway)
	{
		oResult = m_pGateway->SetParameter(p_Name, p_Value);
	}

	return oResult;
}

BOOL CPortBase::GetParameter(CStdString p_Name, BYTE* p_pValue, DWORD p_ulSize)
{
	BOOL oResult = FALSE;

	if(m_pGateway)
	{
		oResult = m_pGateway->GetParameter(p_Name, p_pValue, p_ulSize);
	}

	return oResult;
}
	
BOOL CPortBase::GetParameter(CStdString p_Name, CStdString& p_rValue)
{
	BOOL oResult = FALSE;

	if(m_pGateway)
	{
		oResult = m_pGateway->GetParameter(p_Name, p_rValue);
	}

	return oResult;
}

BOOL CPortBase::Lock(DWORD p_ulTimeout)
{
	BOOL oResult = FALSE;

	if(m_pGateway)
	{
		oResult = m_pGateway->Lock(p_ulTimeout);
	}
	
	return oResult;
}
    
BOOL CPortBase::Unlock()
{
	BOOL oResult = FALSE;

	if(m_pGateway)
	{
		oResult = m_pGateway->Unlock();
	}
	
	return oResult;
}
    
BOOL CPortBase::IsLocked()
{
	BOOL oResult = FALSE;

	if(m_pGateway)
	{
		oResult = m_pGateway->IsLocked();
	}
	
	return oResult;
}

