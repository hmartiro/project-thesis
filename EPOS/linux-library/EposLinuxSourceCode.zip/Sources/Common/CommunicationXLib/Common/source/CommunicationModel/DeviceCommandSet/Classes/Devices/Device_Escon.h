// Device_Escon.h: Schnittstelle f�r die Klasse CDevice_Escon.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_Device_Escon_H__4B4C3F21_32FD_4D64_8505_A52922BC0605__INCLUDED_)
#define AFX_Device_Escon_H__4B4C3F21_32FD_4D64_8505_A52922BC0605__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <CommunicationModel/Common/CommunicationModelDefinitions.h>
#ifdef _MMC_DCS_ESCON

#include "../CommandGroups/Escon/CommandGroupStandard_DCS_Escon.h"
#include "BaseClasses/DeviceBase.h"

class CProtocolStackManagerBase;

class CDevice_Escon : public CDeviceBase
{
public:
    //CommandInvoke
    BOOL GetCommands(CStdString* p_pCommandInfo);

    BOOL InitDevice(CErrorInfo* p_pErrorInfo = 0);
    BOOL InitDevice(CStdString p_ProtocolStackName, CErrorInfo* p_pErrorInfo = 0);
    BOOL InitDevice(CStdString p_ProtocolStackName, CStdString p_InterfaceName, CErrorInfo* p_pErrorInfo = 0);
    BOOL InitGateway(CStdString p_ProtocolStackName);

    CDevice_Escon();
    CDevice_Escon(const CDevice_Escon& p_rObject);
    virtual ~CDevice_Escon();
    virtual CDeviceBase* Clone();

//JournalManager
    virtual void InitJournalManager(CJournalManagerBase* p_pJournalManager);
    virtual void ResetJournalManager();

private:
    BOOL VerifyGateway(CStdString p_ProtocolStackName);
    BOOL InitErrorHandling();

    void DeleteGroupList();
    void FillGroupList();
    BOOL InitGroupList(CGatewayDCStoPS* p_pGateway);

    //ParameterSet
    BOOL InitParameterSet();

    //Default Settings
    BOOL InitDefaultProtocolStackSettings(CProtocolStackManagerBase* p_pProtocolStackManager, CStdString p_ProtocolStackName);
    BOOL InitDefaultProtocolStackSettings(CProtocolStackManagerBase* p_pProtocolStackManager, CStdString p_ProtocolStackName, CStdString p_InterfaceName);

private:
    CCommandGroupStandard_DCS_Escon* m_pCommandGroupStandard;
};
#endif //_MMC_DCS_ESCON
#endif // !defined(AFX_Device_Escon_H__4B4C3F21_32FD_4D64_8505_A52922BC0605__INCLUDED_)
