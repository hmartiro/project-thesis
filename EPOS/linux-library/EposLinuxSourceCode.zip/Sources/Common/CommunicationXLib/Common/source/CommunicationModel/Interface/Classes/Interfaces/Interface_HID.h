// Interface_HID.h: Schnittstelle f�r die Klasse CInterface_HID.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_Interface_HID_H__27D9CCA8_43A0_4813_8EF9_7B2298F7567B__INCLUDED_)
#define AFX_Interface_HID_H__27D9CCA8_43A0_4813_8EF9_7B2298F7567B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <MmcDefinitions.h>
#ifdef _MMC_I_HID

#include "BaseClasses/InterfaceBase.h"

class CHidDeviceInfoHandling;

class CInterface_HID : public CInterfaceBase
{    
public:
	void Init() {m_strClassType=_T("CInterface_HID");}
//Initialisation
    BOOL InitInterface(WORD p_usBoardNumber, WORD p_usNbBoardWithOldDriver);

    BOOL I_OpenInterface(CErrorInfo* p_pErrorInfo = 0);
    BOOL I_OpenInterfacePort(CPortBase* pPort, CStdString strPortName, CErrorInfo* p_pErrorInfo = 0);

    BOOL I_CloseInterface(CErrorInfo* p_pErrorInfo = 0);
    BOOL I_CloseInterfacePort(CPortBase* pPort, CErrorInfo* p_pErrorInfo = 0);

    BOOL I_GetInterfaceSettings(CPortBase* pPort, DWORD* pdBaudrate, DWORD* pdTimeout, CErrorInfo* p_pErrorInfo = 0);
    BOOL I_SetInterfaceSettings(CPortBase* pPort, DWORD dBaudrate, DWORD dTimeout, BOOL oChangeOnly, CErrorInfo* p_pErrorInfo = 0);

    BOOL I_GetInterfaceMode(WORD* pwModeIndex, CErrorInfo* p_pErrorInfo = 0);
    BOOL I_SetInterfaceMode(WORD p_usModeIndex, CErrorInfo* p_pErrorInfo = 0);

    BOOL I_ResetInterface(CPortBase* pPort, CErrorInfo* p_pErrorInfo = 0);

    CInterface_HID();
    CInterface_HID(const CInterface_HID& p_rObject);
    virtual ~CInterface_HID();
    CInterfaceBase* Clone();

//JournalManager
    virtual void InitJournalManager(CJournalManagerBase *p_pJournalManager);
    virtual void ResetJournalManager();

//UsbDeviceInfoHandling
    BOOL InitUsbDeviceInfoHandling(CHidDeviceInfoHandling* pUsbDeviceInfoHandling);

private:
    BOOL InitErrorHandling();
    BOOL InitGateway();

    //ParameterSet
    BOOL InitParameterSet();

private:
    //UsbDeviceInfoHandling
    CHidDeviceInfoHandling* m_pUsbDeviceInfoHandling;
};
#endif //_MMC_I_HID

#endif // !defined(AFX_Interface_HID_H__27D9CCA8_43A0_4813_8EF9_7B2298F7567B__INCLUDED_)
