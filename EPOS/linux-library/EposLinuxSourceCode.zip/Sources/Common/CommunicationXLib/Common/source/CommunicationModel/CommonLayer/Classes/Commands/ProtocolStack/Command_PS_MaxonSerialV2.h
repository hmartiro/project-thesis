// Command_PS_MaxonSerialV2.h: Schnittstelle f�r die Klasse CCommand_PS_MaxonSerialV2.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_Command_PS_MaxonSerialV2_H__9B23BC0A_DD33_499E_B6F6_116AF15BE465__INCLUDED_)
#define AFX_Command_PS_MaxonSerialV2_H__9B23BC0A_DD33_499E_B6F6_116AF15BE465__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <CommunicationModel/Common/CommunicationModelDefinitions.h>
#ifdef _MMC_PS_MAXON_SERIAL_V2

#include <CommunicationModel/CommonLayer/Classes/Commands/ProtocolStack/BaseClasses/Command_PS.h>
#include "Command_PS_MaxonSerialV2_Definitions.h"

class CCommand_PS_MaxonSerialV2 : public CCommand_PS
{
public:
	CCommand_PS_MaxonSerialV2();
	CCommand_PS_MaxonSerialV2(DWORD dCommandId);
	virtual ~CCommand_PS_MaxonSerialV2();

	BOOL InitCommand(DWORD dCommandId);

	CCommand_PS_MaxonSerialV2& operator=(CCommand_PS_MaxonSerialV2& other);
	CCommandRoot*CloneCommand();

private:
	void SetDefaultParameter_ProcessProtocol();
	void SetDefaultParameter_AbortProtocol();
};
#endif //_MMC_PS_MAXON_SERIAL_V2
#endif // !defined(AFX_Command_PS_MaxonSerialV2_H__9B23BC0A_DD33_499E_B6F6_116AF15BE465__INCLUDED_)
