// Interface_IXXAT.h: Schnittstelle f�r die Klasse CInterface_IXXAT.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INTERFACE_IXXAT_H__44692961_FDA4_45C0_8C83_89523F8F58C0__INCLUDED_)
#define AFX_INTERFACE_IXXAT_H__44692961_FDA4_45C0_8C83_89523F8F58C0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <MmcDefinitions.h>
#ifdef _MMC_I_IXXAT

#include "BaseClasses/InterfaceBase.h"

class CInterface_IXXAT : public CInterfaceBase
{
public:
	void Init() {m_strClassType="CInterface_IXXAT";}

	WORD GetNbOfAvailableBoards();

	//Initialisation
	BOOL InitInterface(WORD wBoardNumber,WORD wNbBoardWithOldDriver);

	BOOL I_OpenInterface(CErrorInfo* pErrorInfo = NULL);
	BOOL I_OpenInterfacePort(CPortBase* pPort,CStdString strPortName,CErrorInfo* pErrorInfo = NULL);

	BOOL I_CloseInterface(CErrorInfo* pErrorInfo = NULL);
	BOOL I_CloseInterfacePort(CPortBase* pPort,CErrorInfo* pErrorInfo = NULL);

	BOOL I_GetInterfaceSettings(CPortBase* pPort,DWORD* pdBaudrate,DWORD* pdTimeout,CErrorInfo* pErrorInfo = NULL);
	BOOL I_SetInterfaceSettings(CPortBase* pPort,DWORD dBaudrate,DWORD dTimeout,BOOL oChangeOnly,CErrorInfo* pErrorInfo = NULL);

	BOOL I_GetInterfaceMode(WORD* pwModeIndex,CErrorInfo* pErrorInfo = NULL);
	BOOL I_SetInterfaceMode(WORD wModeIndex,CErrorInfo* pErrorInfo = NULL);

	BOOL I_ResetInterface(CPortBase* pPort,CErrorInfo* pErrorInfo = NULL);

	CInterface_IXXAT();
	CInterface_IXXAT(const CInterface_IXXAT& rObject);
	virtual ~CInterface_IXXAT();
	CInterfaceBase* Clone();

//JournalManager
    virtual void InitJournalManager(CJournalManagerBase *pJournalManager);
    virtual void ResetJournalManager();

private:
	BOOL InitErrorHandling();
	BOOL InitGateway();

	//ParameterSet
	BOOL InitParameterSet();

};
#endif //_MMC_I_IXXAT

#endif // !defined(AFX_INTERFACE_IXXAT_H__44692961_FDA4_45C0_8C83_89523F8F58C0__INCLUDED_)
