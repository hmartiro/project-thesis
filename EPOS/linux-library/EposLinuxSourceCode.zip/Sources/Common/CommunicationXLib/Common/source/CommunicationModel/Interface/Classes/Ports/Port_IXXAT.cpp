// Port_IXXAT.cpp: Implementierung der Klasse CPort_IXXAT.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "Port_IXXAT.h"

#ifdef _MMC_I_IXXAT
#include <CommunicationModel/CommonLayer/Classes/Commands/Interface/BaseClasses/Command_I.h>
#include "../../../CommonLayer/Classes/Commands/Interface/Command_I_CAN.h"

#include "../Gateway/IXXAT/GatewayIXXATtoVCIV2.h"
#include "../Gateway/IXXAT/GatewayIXXATtoVCIV3.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////
CPort_IXXAT::CPort_IXXAT()
{
    InitErrorHandling();

    if(!InitInterfacePortName()) m_strInterfacePortName = INTERFACE_PORT_IXXAT;

    m_pCommand_TransmitCanFrame = NULL;
    m_pCommand_ReceiveCanFrame = NULL;
    m_pCommand_ReceiveFilteredCanFrame = NULL;
    InitCommands();

    m_pJournalManager = NULL;
    SetDefault();
}

CPort_IXXAT::CPort_IXXAT(CPort_IXXAT& rObject):CPortBase(rObject)
{
    InitErrorHandling();

    m_strInterfacePortName = rObject.m_strInterfacePortName;

    rObject.ResetPortMembers();

    m_pCommand_TransmitCanFrame = NULL;
    m_pCommand_ReceiveCanFrame = NULL;
    m_pCommand_ReceiveFilteredCanFrame = NULL;
    InitCommands();

    InitJournalManager(rObject.m_pJournalManager);
}

CPort_IXXAT::~CPort_IXXAT()
{
    DeleteCommands();
}

CPortBase* CPort_IXXAT::Clone()
{
    CPortBase* pPortBase = new CPort_IXXAT(*this);
    return pPortBase;
}

//********************************************************************
void CPort_IXXAT::SetDefault()
{
    m_strPortName = "";
}

//********************************************************************
void CPort_IXXAT::ResetPortMembers()
{
    m_strPortName = "";
}

//********************************************************************
BOOL CPort_IXXAT::I_TransmitCanFrame(HANDLE hTransactionHandle, DWORD dCobId, BOOL oRtr, BYTE uDlc, void* pDataBuffer, DWORD dDataBufferLength, CErrorInfo* pErrorInfo)
{
    const DWORD k_MaxDataLength = 8;

    BOOL oResult = FALSE;
    CLayerManagerBase* pLayerManager = NULL;
    DWORD dDataLength;
    HANDLE hHandle = 0;

    if(m_pCommand_TransmitCanFrame)
    {
        //Limit DataLength
        dDataLength = uDlc;
        if(dDataLength > k_MaxDataLength) dDataLength = k_MaxDataLength;
        if(dDataLength > dDataBufferLength) dDataLength = dDataBufferLength;

        //Set Parameter Data
        m_pCommand_TransmitCanFrame->ResetStatus();
        m_pCommand_TransmitCanFrame->SetParameterData(0, &dCobId, sizeof(dCobId));
        m_pCommand_TransmitCanFrame->SetParameterData(1, &oRtr, sizeof(oRtr));
        m_pCommand_TransmitCanFrame->SetParameterData(2, &uDlc, sizeof(uDlc));
        m_pCommand_TransmitCanFrame->SetParameterData(3, pDataBuffer, dDataLength);

        //Execute Command
        oResult = m_pCommand_TransmitCanFrame->Execute(pLayerManager, hHandle, hTransactionHandle);

        //Get ReturnParameter Data

        //Get ErrorCode
        m_pCommand_TransmitCanFrame->GetErrorInfo(pErrorInfo);
    }

    return oResult;
}

//********************************************************************
BOOL CPort_IXXAT::I_ReceiveCanFrame(HANDLE hTransactionHandle, DWORD* pdCobId, BOOL* poRtr, BYTE* puDlc, void* pDataBuffer, DWORD dDataBufferLength, CErrorInfo* pErrorInfo)
{
    const DWORD k_MaxDataLength = 8;

    BOOL oResult = FALSE;
    CLayerManagerBase* pLayerManager = NULL;
    DWORD dDataLength;
    HANDLE hHandle = 0;

    if(m_pCommand_ReceiveCanFrame)
    {
        //Limit dataLength
        if(puDlc) dDataLength = *puDlc; else dDataLength = k_MaxDataLength;
        if(dDataLength > k_MaxDataLength) dDataLength = k_MaxDataLength;
        if(dDataLength > dDataBufferLength) dDataLength = dDataBufferLength;

        //Set Parameter Data
        m_pCommand_ReceiveCanFrame->ResetStatus();

        //Execute Command
        oResult = m_pCommand_ReceiveCanFrame->Execute(pLayerManager, hHandle, hTransactionHandle);

        //Get ReturnParameter Data
        m_pCommand_ReceiveCanFrame->GetReturnParameterData(0, pdCobId, sizeof(*pdCobId));
        m_pCommand_ReceiveCanFrame->GetReturnParameterData(1, poRtr, sizeof(*poRtr));
        m_pCommand_ReceiveCanFrame->GetReturnParameterData(2, puDlc, sizeof(*puDlc));
        m_pCommand_ReceiveCanFrame->GetReturnParameterData(3, pDataBuffer, dDataLength);

        //Get ErrorCode
        m_pCommand_ReceiveCanFrame->GetErrorInfo(pErrorInfo);
    }

    return oResult;
}

//********************************************************************
BOOL CPort_IXXAT::I_ReceiveFilteredCanFrame(HANDLE hTransactionHandle, DWORD dCobIdFilter, BOOL oRtrFilter, DWORD* pdCobId, BOOL* poRtr, BYTE* puDlc, void* pDataBuffer, DWORD dDataBufferLength, CErrorInfo* pErrorInfo)
{
    const DWORD k_MaxDataLength = 8;

    BOOL oResult = FALSE;
    CLayerManagerBase* pLayerManager = NULL;
    DWORD dDataLength;
    HANDLE hHandle = 0;

    if(m_pCommand_ReceiveFilteredCanFrame)
    {
        //Limit dataLength
        if(puDlc) dDataLength = *puDlc; else dDataLength = k_MaxDataLength;
        if(dDataLength > k_MaxDataLength) dDataLength = k_MaxDataLength;
        if(dDataLength > dDataBufferLength) dDataLength = dDataBufferLength;

        //Set Parameter Data
        m_pCommand_ReceiveFilteredCanFrame->ResetStatus();
        m_pCommand_ReceiveFilteredCanFrame->SetParameterData(0, &dCobIdFilter, sizeof(dCobIdFilter));
        m_pCommand_ReceiveFilteredCanFrame->SetParameterData(1, &oRtrFilter, sizeof(oRtrFilter));

        //Execute Command
        oResult = m_pCommand_ReceiveFilteredCanFrame->Execute(pLayerManager, hHandle, hTransactionHandle);

        //Get ReturnParameter Data
        m_pCommand_ReceiveFilteredCanFrame->GetReturnParameterData(0, pdCobId, sizeof(*pdCobId));
        m_pCommand_ReceiveFilteredCanFrame->GetReturnParameterData(1, poRtr, sizeof(*poRtr));
        m_pCommand_ReceiveFilteredCanFrame->GetReturnParameterData(2, puDlc, sizeof(*puDlc));
        m_pCommand_ReceiveFilteredCanFrame->GetReturnParameterData(3, pDataBuffer, dDataLength);

        //Get ErrorCode
        m_pCommand_ReceiveFilteredCanFrame->GetErrorInfo(pErrorInfo);
    }

    return oResult;
}

//********************************************************************
void CPort_IXXAT::InitCommands()
{
    DeleteCommands();

    //Init Command TransmitCanFrame
    m_pCommand_TransmitCanFrame = new CCommand_I_CAN();
    m_pCommand_TransmitCanFrame->InitCommand(CAN_TRANSMIT_CAN_FRAME);

    //Init Command ReceiveCanFrame
    m_pCommand_ReceiveCanFrame = new CCommand_I_CAN();
    m_pCommand_ReceiveCanFrame->InitCommand(CAN_RECEIVE_FILTERED_CAN_FRAME);

    //Init Command ReceiveFilteredCanFrame
    m_pCommand_ReceiveFilteredCanFrame = new CCommand_I_CAN();
    m_pCommand_ReceiveFilteredCanFrame->InitCommand(CAN_RECEIVE_FILTERED_CAN_FRAME);
}

//********************************************************************
BOOL CPort_IXXAT::GetCommands(CStdString* pCommandInfo)
{
    CXXMLFile xmlFile;
    CXXMLFile::CElementPart* pElementPart;
    CXXMLFile::CElement* pElement;
    BOOL oResult = TRUE;

    if(pCommandInfo)
    {
        //Root
        pElementPart = xmlFile.Root();
        if(!xmlFile.IsElement(pElementPart)) return FALSE;

        //CommandInfo Elements
        pElement = (CXXMLFile::CElement*)xmlFile.AddElement(pElementPart);
        xmlFile.SetText(pElement, "CommandInfo");

        //CommandGroup Elements
        pElement = (CXXMLFile::CElement*)xmlFile.AddElement(pElement);
        xmlFile.SetText(pElement, "CommandGroup");
        pElement->SetAt("Name", m_strPortName);

        //Command Elements
        if(m_pCommand_TransmitCanFrame && !m_pCommand_TransmitCanFrame->StoreToXMLFile(&xmlFile, pElement, TRUE)) return FALSE;
        if(m_pCommand_ReceiveCanFrame && !m_pCommand_ReceiveCanFrame->StoreToXMLFile(&xmlFile, pElement, TRUE)) return FALSE;
        if(m_pCommand_ReceiveFilteredCanFrame && !m_pCommand_ReceiveFilteredCanFrame->StoreToXMLFile(&xmlFile, pElement, TRUE)) return FALSE;

        //Write to string
        xmlFile.WriteToString(pCommandInfo);
        return oResult;
    }

    return FALSE;
}

//********************************************************************
void CPort_IXXAT::DeleteCommands()
{
    if(m_pCommand_TransmitCanFrame)
    {
        delete m_pCommand_TransmitCanFrame;
        m_pCommand_TransmitCanFrame = NULL;
    }

    if(m_pCommand_ReceiveCanFrame)
    {
        delete m_pCommand_ReceiveCanFrame;
        m_pCommand_ReceiveCanFrame = NULL;
    }

    if(m_pCommand_ReceiveFilteredCanFrame)
    {
        delete m_pCommand_ReceiveFilteredCanFrame;
        m_pCommand_ReceiveFilteredCanFrame = NULL;
    }
}

//********************************************************************
void CPort_IXXAT::InitJournalManager(CJournalManagerBase *pJournalManager)
{
    CPortBase::InitJournalManager(pJournalManager);
    if(m_pCommand_TransmitCanFrame) m_pCommand_TransmitCanFrame->InitJournalManager(pJournalManager);
    if(m_pCommand_ReceiveCanFrame) m_pCommand_ReceiveCanFrame->InitJournalManager(pJournalManager);
    if(m_pCommand_ReceiveFilteredCanFrame) m_pCommand_ReceiveFilteredCanFrame->InitJournalManager(pJournalManager);
}

//********************************************************************
void CPort_IXXAT::ResetJournalManager()
{
    CPortBase::ResetJournalManager();
    if(m_pCommand_TransmitCanFrame) m_pCommand_TransmitCanFrame->ResetJournalManager();
    if(m_pCommand_ReceiveCanFrame) m_pCommand_ReceiveCanFrame->ResetJournalManager();
    if(m_pCommand_ReceiveFilteredCanFrame) m_pCommand_ReceiveFilteredCanFrame->ResetJournalManager();
}

//********************************************************************
void CPort_IXXAT::InitCommands(CGatewayIToDrv* pGateway)
{
    if(m_pCommand_TransmitCanFrame) m_pCommand_TransmitCanFrame->InitGateway(pGateway);
    if(m_pCommand_ReceiveCanFrame) m_pCommand_ReceiveCanFrame->InitGateway(pGateway);
    if(m_pCommand_ReceiveFilteredCanFrame) m_pCommand_ReceiveFilteredCanFrame->InitGateway(pGateway);
}

BOOL CPort_IXXAT::InitGateway(CGatewayIToDrv* pGateway)
{
	BOOL oResult = FALSE;

	if(CPortBase::InitGateway(pGateway))
	{
		InitParameterSet();
		oResult = TRUE;
	}

	return oResult;
}

BOOL CPort_IXXAT::InitParameterSet()
{
	BOOL oResult = FALSE;

	if(m_pGateway)
	{
		oResult = TRUE;
		if(oResult) oResult &= m_pGateway->ResetParameterSet();
	}
    
    return oResult;
}

//********************************************************************
BOOL CPort_IXXAT::InitErrorHandling()
{
    CErrorProducer errorProducer;
    CStdString strClassName = "Port_IXXAT";

    if(m_pErrorHandling)
    {
        //Init ErrorProducer
        errorProducer.Init(INTERFACE_LAYER, strClassName);
        m_pErrorHandling->InitErrorProducer(&errorProducer);
        return TRUE;
    }

    return FALSE;
}
#endif //_MMC_I_IXXAT
