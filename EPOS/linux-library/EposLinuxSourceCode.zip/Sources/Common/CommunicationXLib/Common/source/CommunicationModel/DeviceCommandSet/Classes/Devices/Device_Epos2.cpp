// Device_Epos2.cpp: Implementierung der Klasse CDevice_Epos2.
//
//////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "Device_Epos2.h"
#ifdef _MMC_DCS_EPOS2
#include <cctype> // for toupper
#include <algorithm>

#include <CommunicationModel/CommonLayer/Classes/Commands/DeviceCommandSet/DcsEpos2Def.h>
#include "../Gateway/Epos2/GatewayEpos2ToCANopen.h"
#include "../Gateway/Epos2/GatewayEpos2ToMaxonSerialV1.h"
#include "../Gateway/Epos2/GatewayEpos2ToMaxonSerialV2.h"
#include <CommunicationModel/ProtocolStack/ProtocolStackManager.h>
#include <CommunicationModel/ProtocolStack/ProtocolStackManagerBase.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////
CDevice_Epos2::CDevice_Epos2()
{
    InitErrorHandling();

    FillGroupList();
    m_strDeviceName = DEVICE_EPOS2;
    m_pJournalManager = NULL;
}

CDevice_Epos2::CDevice_Epos2(const CDevice_Epos2& rObject):CDeviceBase(rObject)
{
    InitErrorHandling();

    FillGroupList();
    m_strDeviceName = rObject.m_strDeviceName;

    InitJournalManager(rObject.m_pJournalManager);
    InitGroupList(m_pGateway);
}

CDeviceBase* CDevice_Epos2::Clone()
{
    CDevice_Epos2* pDevice;

    pDevice = new CDevice_Epos2(*this);
    return pDevice;
}

CDevice_Epos2::~CDevice_Epos2()
{
    DeleteGroupList();
}

BOOL CDevice_Epos2::InitDevice(CErrorInfo* pErrorInfo)
{
    BOOL oResult = FALSE;

    //Klassenstruktur f�r Protocolstack EposRS232 aufbauen
    if(!InitDevice(PROTOCOL_MAXON_SERIAL_V1, pErrorInfo))
    {
        oResult = FALSE;
    }

    //Klassenstruktur f�r Protocolstack Epos2USB aufbauen
    if(!InitDevice(PROTOCOL_MAXON_SERIAL_V2, pErrorInfo))
    {
        oResult = FALSE;
    }

    //Klassenstruktur f�r Protocolstack CANopen aufbauen
    if(!InitDevice(PROTOCOL_CAN_OPEN, pErrorInfo))
    {
        oResult = FALSE;
    }

    return oResult;
}

BOOL CDevice_Epos2::InitDevice(CStdString strProtocolStack, CErrorInfo* pErrorInfo)
{
    CProtocolStackManagerBase* pManager = NULL;
    BOOL oNewCreated = FALSE;
    BOOL oResult = FALSE;

    if(strProtocolStack.size()==0)
    {
        //Don't create a protocol stack
        oResult = TRUE;
    }
    else
    {
        //Is Manager already existing
        if(!FindCorrectManager(strProtocolStack, &pManager) && !GetFirstManager(&pManager))
        {
            //Create new Manager
            pManager = (CProtocolStackManagerBase*) new CProtocolStackManager(m_lInstanceValue);
            oNewCreated = TRUE;
        }

        //Klassenstruktur f�r Device aufbauen
        if((VerifyGateway(strProtocolStack)) && (pManager->PS_InitProtocolStack(strProtocolStack, pErrorInfo)))
        {
		    //Default Settings
			CDeviceBase::InitDefaultProtocolStackSettings(pManager, strProtocolStack);
			
            if(oNewCreated) m_ProtocolStackManagerList.push_back(pManager);
            oResult = TRUE;
        }
        else
        {
            if(oNewCreated) delete pManager;
            oResult = FALSE;
        }
    }

    return oResult;
}

BOOL CDevice_Epos2::InitDevice(CStdString strProtocolStack, CStdString strInterfaceName, CErrorInfo* pErrorInfo)
{
    CProtocolStackManagerBase* pManager = NULL;
    BOOL oNewCreated = FALSE;
    BOOL oResult = FALSE;

    if(strProtocolStack.size()==0)
    {
        //Don't create a protocol stack
        oResult = TRUE;
    }
    else
    {
        //Is Manager already existing
        if(!FindCorrectManager(strProtocolStack, &pManager) && !GetFirstManager(&pManager))
        {
            //Create new Manager
            pManager = (CProtocolStackManagerBase*) new CProtocolStackManager(m_lInstanceValue);
            oNewCreated = TRUE;
        }

        //Klassenstruktur f�r Device aufbauen
        if((VerifyGateway(strProtocolStack)) && (pManager->PS_InitProtocolStack(strProtocolStack, strInterfaceName, pErrorInfo)))
        {
		    //Default Settings
			InitDefaultProtocolStackSettings(pManager, strProtocolStack, strInterfaceName);
			
            if(oNewCreated) m_ProtocolStackManagerList.push_back(pManager);
            oResult = TRUE;
        }
        else
        {
            if(oNewCreated) delete pManager;
            oResult = FALSE;
        }
    }

    return oResult;
}

BOOL CDevice_Epos2::InitDefaultProtocolStackSettings(CProtocolStackManagerBase* p_pProtocolStackManager, CStdString p_ProtocolStackName, CStdString p_InterfaceName)
{
	BOOL oResult(FALSE);

	if(p_pProtocolStackManager)
	{
		if(p_ProtocolStackName == PROTOCOL_CAN_OPEN)
		{
			//CANopen 
			oResult = p_pProtocolStackManager->PS_InitDefaultProtocolStackSettings(p_ProtocolStackName, p_InterfaceName, DEFAULT_TRANSFER_RATE_CAN_OPEN, DEFAULT_TIMEOUT); 
		}
		else if(p_InterfaceName == INTERFACE_RS232)
		{
			//RS232
			oResult = p_pProtocolStackManager->PS_InitDefaultProtocolStackSettings(p_ProtocolStackName, p_InterfaceName, DEFAULT_TRANSFER_RATE_RS232, DEFAULT_TIMEOUT); 
		}
		else if(p_InterfaceName == INTERFACE_USB)
		{
			//USB
			oResult = p_pProtocolStackManager->PS_InitDefaultProtocolStackSettings(p_ProtocolStackName, p_InterfaceName, DEFAULT_TRANSFER_RATE_USB, DEFAULT_TIMEOUT); 
		}
	}

	return oResult;
}

void CDevice_Epos2::FillGroupList()
{
    m_pCommandGroupStandard = new CCommandGroupStandard_DCS_Epos2();
}

BOOL CDevice_Epos2::InitGateway(CStdString strProtocolStackName)
{
    DeleteGateway();

    std::transform( strProtocolStackName.begin(),
        				strProtocolStackName.end(),
        				strProtocolStackName.begin(),
    					(int(*)(int)) toupper);

    //�berpr�fen welcher Gateway initialisiert werden soll!
    if(strProtocolStackName==PROTOCOL_CAN_OPEN)
    {
        m_pGateway = new CGatewayEpos2ToCANopen();
        if(m_pGateway->InitGateway())
        {
            InitParameterSet();
			InitGroupList(m_pGateway);
            return TRUE;
        }
        else
        {
            DeleteGateway();
            return FALSE;
        }
    }

    if(strProtocolStackName==PROTOCOL_MAXON_SERIAL_V1)
    {
#ifdef _MMC_PS_MAXON_SERIAL_V1
        m_pGateway = new CGatewayEpos2ToMaxonSerialV1();
        if(m_pGateway->InitGateway())
        {
            InitParameterSet();
			InitGroupList(m_pGateway);
            return TRUE;
        }
        else
        {
            DeleteGateway();
            return FALSE;
        }
#endif //_MMC_PS_MAXON_SERIAL_V1
    }

    if(strProtocolStackName==PROTOCOL_MAXON_SERIAL_V2)
    {
#ifdef _MMC_PS_MAXON_SERIAL_V2
        m_pGateway = new CGatewayEpos2ToMaxonSerialV2();
        if(m_pGateway->InitGateway())
        {
            InitParameterSet();
			InitGroupList(m_pGateway);
            return TRUE;
        }
        else
        {
            DeleteGateway();
            return FALSE;
        }
#endif //_MMC_PS_MAXON_SERIAL_V2
    }

    return FALSE;
}

BOOL CDevice_Epos2::InitParameterSet()
{
	const BYTE DEFAULT_NODE_ID = 1;

	BOOL oResult = FALSE;

	if(m_pGateway)
	{
		oResult = TRUE;
		if(oResult) oResult &= m_pGateway->ResetParameterSet();
		if(oResult) oResult &= m_pGateway->AddParameter(_T("NodeId"),(BYTE*)&DEFAULT_NODE_ID,sizeof(DEFAULT_NODE_ID));
	}
    
    return oResult;
}

BOOL CDevice_Epos2::InitGroupList(CGatewayDCStoPS* pGateway)
{
    if(m_pCommandGroupStandard && !m_pCommandGroupStandard->InitGateway(pGateway)) return FALSE;
    return TRUE;
}

BOOL CDevice_Epos2::VerifyGateway(CStdString strProtocolStackName)
{
    //�berpr�fen welcher ProtocolStack benutzt werden darf

	std::transform( strProtocolStackName.begin(),
	        				strProtocolStackName.end(),
	        				strProtocolStackName.begin(),
	    					(int(*)(int)) toupper);

    //GatewayEpos2ToCANopen
    if(strProtocolStackName==PROTOCOL_CAN_OPEN)
    {
        return TRUE;
    }
#ifdef _MMC_PS_MAXON_SERIAL_V1
    //GatewayEpos2ToMaxonSerialV1
    if(strProtocolStackName==PROTOCOL_MAXON_SERIAL_V1)
    {
        return TRUE;
    }
#endif //_MMC_PS_MAXON_SERIAL_V1
#ifdef _MMC_PS_MAXON_SERIAL_V2
    //GatewayEpos2ToMaxonSerialV2
    if(strProtocolStackName==PROTOCOL_MAXON_SERIAL_V2)
    {
        return TRUE;
    }
#endif //_MMC_PS_MAXON_SERIAL_V2
    return FALSE;
}

void CDevice_Epos2::DeleteGroupList()
{
    if(m_pCommandGroupStandard)
    {
        delete m_pCommandGroupStandard;
        m_pCommandGroupStandard = NULL;
    }
}

void CDevice_Epos2::InitJournalManager(CJournalManagerBase* pJournalManager)
{
    CDeviceBase::InitJournalManager(pJournalManager);
    if(m_pCommandGroupStandard) m_pCommandGroupStandard->InitJournalManager(pJournalManager);
}

void CDevice_Epos2::ResetJournalManager()
{
    CDeviceBase::ResetJournalManager();
    if(m_pCommandGroupStandard) m_pCommandGroupStandard->ResetJournalManager();
}

BOOL CDevice_Epos2::GetCommands(CStdString* pCommandInfo)
{
    CXXMLFile xmlFile;
    CXXMLFile::CElementPart* pElementPart;
    CXXMLFile::CElement* pElement;
    BOOL oResult = TRUE;

    if(pCommandInfo)
    {
        //Root
        pElementPart = xmlFile.Root();
        if(!xmlFile.IsElement(pElementPart)) return FALSE;

        //CommandInfo Elements
        pElement = (CXXMLFile::CElement*)xmlFile.AddElement(pElementPart);
        xmlFile.SetText(pElement, "CommandInfo");

        //CommandGroup Elements
        if(m_pCommandGroupStandard)
        {
            if(!m_pCommandGroupStandard->StoreToXMLFile(&xmlFile, pElement)) oResult = FALSE;
        }

        //Write to string
        xmlFile.WriteToString(pCommandInfo);
        return oResult;
    }

    return FALSE;
}

BOOL CDevice_Epos2::InitErrorHandling()
{
    CErrorProducer errorProducer;
    CStdString strClassName = "Device_Epos2";

    if(m_pErrorHandling)
    {
        //Init ErrorProducer
        errorProducer.Init(DEVICE_COMMAND_SET_LAYER, strClassName);
        m_pErrorHandling->InitErrorProducer(&errorProducer);
        return TRUE;
    }

    return FALSE;
}
#endif //_MMC_DCS_EPOS2
