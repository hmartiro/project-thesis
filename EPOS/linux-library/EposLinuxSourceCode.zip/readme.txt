﻿"EPOS Software for Linux" developer guide

Base library version: 4.8.2.0

Directory structure overview:

Sources			- EPOS Software source code
libEposCmd.so	- compiled EPOS2/RS-232 shared library (target: ARM)
releaseInfo.txt	- maxon motor ag source code management information

Sources

------> Common

----------> SystemXLib
--------------> Common
------------------> include		(public header files)
--------------> Linux
------------------> source		(library source code)
------------------>.project		(eclipse project files)
------------------>.cproject	(eclipse project files)

important note: please check the MmcDefinitions.h file located in the "include" directory

----------> SystemXLib
--------------> Common
------------------> include
------------------> MmcDefinitions.h

you can define there the supported interfaces (to reduce the library size)

/*#define _MMC_I_HID
#define _MMC_I_IXXAT
#define _MMC_I_NI*/
#define _MMC_I_RS232
/*#define _MMC_I_USB
#define _MMC_I_VECTOR*/

in the attached binary just _MMC_I_RS232 is used 

----------> CommonXLib
--------------> Common
------------------> include		(public header files)
--------------> Linux
------------------> source		(library source code)
------------------>.project		(eclipse project files)
------------------>.cproject	(eclipse project files)

----------> CommunicationXLib
--------------> Common
------------------> include		(public header files)
--------------> Linux
------------------> source		(library source code)
------------------>.project		(eclipse project files)
------------------>.cproject	(eclipse project files)

important note: please check the CommunicationModelDefinitions.h located in the "include" directory

----------> CommunicationXLib \Common\
--------------> Common
------------------> include
----------------------> CommunicationModel
--------------------------> Common
--------------------------> CommunicationModelDefinitions.h

you can define there used hardware/protocol combinations (to reduce the library size)

/*hardware variants*/
//#define _MMC_HW_ALL
#define _MMC_HW_EPOS2_RS232

/*hardware variants definition*/
#ifdef _MMC_HW_ALL
	#define _MMC_VCS_DRIVE
	#define _MMC_VCS_DRIVE2
	#define _MMC_VCS_MOVE
	#define _MMC_VCS_PLC
	#define _MMC_VCS_PLC2

	#define _MMC_PS_INFOTEAM_SERIAL
	#define _MMC_PS_MAXON_SERIAL_V1
	#define _MMC_PS_MAXON_SERIAL_V2

	#define _MMC_DCS_EPOS
	#define _MMC_DCS_EPOS2
	#define _MMC_DCS_ESAM
	#define _MMC_DCS_ESAM2
	#define _MMC_DCS_ESCON
#endif //_MMC_HW_ALL

#ifdef _MMC_HW_EPOS2_RS232
	#define _MMC_VCS_DRIVE2
	#define _MMC_PS_MAXON_SERIAL_V1
	#define _MMC_PS_MAXON_SERIAL_V2
	#define _MMC_DCS_EPOS2
#endif

in the attached binary just _MMC_HW_EPOS2_RS232 definition is used.

------> Epos

----------> EposCmd
-------------->Examples
------------------>Eclipse C++ QT
---------------------->source
-------------------------->Example Eclipse C++ QT
------------------------------>.project		(eclipse project files)
------------------------------>.cproject	(eclipse project files)
-------------->.project		(eclipse project files)
-------------->.cproject	(eclipse project files)

How-to compile the linux shared library using Eclipse Helios SR2 + CDT

1. Make sure that, the "include" public header files are visible for all projects (-I compiler option)
2. Compile SystemXLib, CommonXLib and CommunicationXLib

	recommended build order:

		SystemXLib
			->CommonXLib
				->CommunicationXLib
			
	command line:
	eclipse -nosplash -application org.eclipse.cdt.managedbuilder.core.headlessbuild -build SystemXLib
	eclipse -nosplash -application org.eclipse.cdt.managedbuilder.core.headlessbuild -build CommonXLib
	eclipse -nosplash -application org.eclipse.cdt.managedbuilder.core.headlessbuild -build CommunicationXLib

3. Make sure that, the output libraries are available for the EposCmd linker (-L linker option)
4. Compile EposCmd project

command line:
eclipse -nosplash -application org.eclipse.cdt.managedbuilder.core.headlessbuild -build EposCmd

6. Optionally you can build our Example project (Example Eclipse C++ QT) to test target library (QT 4.7 required).

We don't support any hardware/software specific targets. You are free to modify the source code or the build methods according to your needs, but of course any constructive feedback, comments, advices, wrath and laudations are welcomed.

THIS LIBRARY IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY FOR THIS LIBRARY, TO THE EXTENT PERMITTED BY APPLICABLE LAW. EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES PROVIDE THE PROGRAM AS IS WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE RISK AS TO THE QUALITY AND PERFORMANCE OF THIS LIBRARY IS WITH YOU. SHOULD THIS LIBRARY PROVE DEFECTIVE OR INSUFFICIENT, YOU ASSUME THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION

Copyright (c) 2010-2011 maxonmotor ag

http://www.maxonmotor.com/
http://support.maxonmotor.com